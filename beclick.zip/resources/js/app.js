require('./bootstrap');

import 'jquery-datetimepicker/build/jquery.datetimepicker.min'
