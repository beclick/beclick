<?php $__env->startSection('title', 'Админка – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-5">
        <h3>Пользователи</h3>
        <hr>
        <div class="row justify-content-between align-items-start">
            <div class="col-lg-3">
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-white text-black-50 text-center pt-4 pb-3">
                        <h5><strong>Сортировка</strong></h5>
                    </div>
                    <div class="card-body">
                        <form novalidate method="get" action="<?php echo e(route('admin.home')); ?>">
                            <div class="form-group">
                                <select class="custom-select custom-select-lg rounded-0" name="moderate">
                                    <option value="1" <?php if($request->moderate == 1): ?> selected <?php endif; ?>>
                                        На модерации
                                    </option>
                                    <option value="2" <?php if($request->moderate == 2): ?> selected <?php endif; ?>>
                                        Акредитованные
                                    </option>
                                    <option value="3" <?php if($request->moderate == 3): ?> selected <?php endif; ?>>
                                        Отклоненные
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg rounded-0" name="search_inn"
                                       <?php if(isset($request->search_inn)): ?> value="<?php echo e($request->search_inn); ?>"
                                       <?php endif; ?> placeholder="Поиск по ИНН">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg rounded-0" name="search_name"
                                       <?php if(isset($request->search_name)): ?> value="<?php echo e($request->search_name); ?>"
                                       <?php endif; ?> placeholder="Поиск по фамилии">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-block btn-lg btn-primary rounded-0" type="submit">Найти</button>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(route('auction')); ?>" class="btn btn-block btn-lg btn-primary rounded-0">Сбросить</a>
                            </div>
                            <hr>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg">
                <?php if(!$profiles->isEmpty()): ?>
                    <?php $__currentLoopData = $profiles[$page]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card rounded-0 shadow">
                            <div class="card-header bg-white text-black-50 p-0">
                                <div class="row text-dark m-4">
                                    <div class="col-lg">
                                        <h5>
                                            <a href="<?php echo e(route('admin.home', ['profile' => $profile->id])); ?>"><?php if($profile->user_type == 0): ?> <?php echo e($profile->title); ?> <?php elseif($profile->user_type == 1): ?> <?php echo e('ИП ' . $profile->full_name); ?> <?php elseif($profile->user_type == 2): ?> <?php echo e('ФЛ ' . $profile->full_name); ?> <?php endif; ?></a>
                                        </h5>
                                    </div>
                                    <div class="col-lg-auto">
                                        <h5 class="text-info">
                                            <?php if($profile->user_role == 0): ?>
                                                Организатор торгов
                                            <?php elseif($profile->user_role == 1): ?>
                                                Участник торгов
                                            <?php endif; ?>
                                        </h5>
                                    </div>
                                </div>
                                <div class="list-group list-group-horizontal-lg rounded-0">
                                    <a class="list-group-item list-group-item-secondary rounded-0 active" href="#all"
                                       data-toggle="tab"><h5>Информация</h5></a>
                                    <a class="list-group-item list-group-item-secondary rounded-0" href="#docs"
                                       data-toggle="tab"><h5>
                                            Документы</h5></a>
                                    <a class="list-group-item list-group-item-secondary rounded-0" href="#events"
                                       data-toggle="tab"><h5>
                                            История</h5></a>
                                    <?php if($profile->confirmed == 1): ?>
                                        <div class="p-0 col list-group-item rounded-0">
                                            <a class="h-100 btn btn-block btn-lg btn-outline-danger rounded-0"
                                               data-toggle="modal"
                                               data-target="#noconfirm<?php echo e($profile->id); ?>">Отклонить</a>
                                        </div>
                                        <div class="p-0 col list-group-item rounded-0">
                                            <a class="h-100 btn btn-block btn-lg btn-outline-success rounded-0"
                                               data-toggle="modal"
                                               data-target="#confirm<?php echo e($profile->id); ?>">Подтвердить</a>
                                        </div>
                                    <?php elseif($profile->confirmed == 2): ?>
                                        <div class="p-0 col list-group-item rounded-0">
                                            <a class="h-100 btn btn-block btn-lg btn-success rounded-0">Подтвержден</a>
                                        </div>
                                    <?php elseif($profile->confirmed == 0): ?>
                                        <div class="p-0 col list-group-item rounded-0">
                                            <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">Отклонен</a>
                                        </div>
                                    <?php endif; ?>
                                </div>
                                <div class="modal fade" id="noconfirm<?php echo e($profile->id); ?>" tabindex="-1" role="dialog">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content rounded-0">
                                            <div class="modal-header rounded-0">
                                                <h5 class="modal-title">Укажите причину отказа</h5>
                                            </div>
                                            <div class="modal-body">
                                                <form novalidate method="POST" action="<?php echo e(route('admin.confirm')); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="form-group">
                                                    <textarea class="form-control form-control-lg rounded-0" required
                                                              type="text" name="text"
                                                              placeholder="Причины для отказа"></textarea>
                                                        <input name="id" value="<?php echo e($profile->id); ?>" hidden>
                                                    </div>
                                                    <button type="submit"
                                                            class="btn btn-block btn-lg btn-danger rounded-0">
                                                        Отказ
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="modal fade" id="confirm<?php echo e($profile->id); ?>" tabindex="-1" role="dialog">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content rounded-0">
                                            <div class="modal-header rounded-0">
                                                <h5 class="modal-title">Аккредитовать пользователя?</h5>
                                            </div>
                                            <div class="modal-footer">
                                                <a class="btn btn-block btn-lg btn-success rounded-0"
                                                   href="<?php echo e(route('admin.confirm', ['id' => $profile->id])); ?>">Аккредитовать</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="tab-content">
                                    <div class="tab-pane fade active show" id="all">
                                        <?php if($profile->user_type == 0): ?>
                                            <h5 class="row">
                                                <p class="col-lg-4 text-black-50">Полное название организации:</p>
                                                <p class="col"><?php echo e($profile->full_title); ?></p>
                                            </h5>
                                            <h5 class="row">
                                                <p class="col-lg-4 text-black-50">Юридический адрес:</p>
                                                <p class="col"><?php echo e($profile->ur_address); ?></p>
                                            </h5>
                                        <?php else: ?>
                                            <h5 class="row">
                                                <p class="col-lg-4 text-black-50">ФИО:</p>
                                                <p class="col"><?php echo e($profile->full_name); ?></p>
                                            </h5>
                                            <h5 class="row">
                                                <p class="col-lg-4 text-black-50">Паспорт:</p>
                                                <p class="col"><?php echo e($profile->passport); ?></p>
                                            </h5>
                                        <?php endif; ?>
                                        <h5 class="row">
                                            <p class="col-lg-4 text-black-50">Фактический адрес:</p>
                                            <p class="col"><?php echo e($profile->address); ?></p>
                                        </h5>
                                        <h5 class="row">
                                            <p class="col-lg-4 text-black-50">ИНН:</p>
                                            <p class="col"><?php echo e($profile->inn); ?></p>
                                        </h5>
                                        <h5 class="row">
                                            <p class="col-lg-4 text-black-50">Контактный телефон:</p>
                                            <p class="col"><?php echo e($profile->phone); ?></p>
                                        </h5>
                                        <?php if(isset($profile->email)): ?>
                                            <h5 class="row">
                                                <p class="col-lg-4 text-black-50">Адрес электронной почты:</p>
                                                <p class="col"><?php echo e($profile->email); ?></p>
                                            </h5>
                                        <?php endif; ?>
                                        <h5 class="row">
                                            <p class="col-lg-4 text-black-50">Финансы:</p>
                                            <p class="col">
                                                Баланс: <?php echo e(number_format($profile->balance / 100, 2, '.', '')); ?> ₽ |
                                                Блок: <?php echo e(number_format($profile->blocked / 100, 2, '.', '')); ?> ₽</p>
                                        </h5>
                                    </div>
                                    <div class="tab-pane fade" id="docs">
                                        <?php $__currentLoopData = $profile->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <strong>
                                                <div class="row">
                                                    <div class="col">
                                                        <a target="_blank" class="col-lg-7" target="_blank"
                                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                                            <?php echo e($doc->file_name); ?>

                                                        </a>
                                                    </div>
                                                    <div class="col-auto">
                                                        <?php if($doc->sign): ?>
                                                            ПОДПИСАН ЭП
                                                        <?php else: ?>
                                                            НЕ ПОДПИСАНО
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </strong>
                                            <hr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="tab-pane fade" id="events">
                                        <?php $__currentLoopData = $profile->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <strong>
                                                <div class="row">
                                                    <div class="col">
                                                        <?php echo e($event->event); ?>

                                                    </div>
                                                    <div class="col-auto">
                                                        <?php echo e(\Illuminate\Support\Carbon::parse($event->created_at)->format('d.m.Y H:i')); ?>

                                                    </div>
                                                </div>
                                            </strong>
                                            <hr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="row container justify-content-center">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <?php if($page >= 3): ?>
                                <li class="page-item">
                                    <a class="page-link"
                                       href="<?php echo e(route('admin.home', ['moderate' => $request->moderate, 'search_inn' => $request->search_inn, 'search_name' => $request->search_name, 'page' => $page])); ?>"
                                       aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php for($i = 0; $i < $profiles->count(); $i++): ?>
                                <?php if($i >= $page - 2 and $i <= $page + 2): ?>
                                    <li class="page-item <?php if($page == $i): ?> active <?php endif; ?>"><a
                                            class="page-link"
                                            href="<?php echo e(route('admin.home', ['moderate' => $request->moderate, 'search_inn' => $request->search_inn, 'search_name' => $request->search_name, 'page' => $i + 1])); ?>"><?php echo e($i + 1); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <?php if($page < $profiles->count() - 2): ?>
                                <li class="page-item">
                                    <a class="page-link"
                                       href="<?php echo e(route('admin.home', ['moderate' => $request->moderate, 'search_inn' => $request->search_inn, 'search_name' => $request->search_name, 'page' => $page + 2])); ?>"
                                       aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/admin/home.blade.php ENDPATH**/ ?>