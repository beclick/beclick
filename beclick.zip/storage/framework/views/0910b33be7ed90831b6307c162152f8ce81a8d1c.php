<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/png">

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>

    <script src="<?php echo e(asset('js/cryptopro/polyfills/promise.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cryptopro/polyfills/find.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cryptopro/crypto-pro.js')); ?>"></script>
    <script src="<?php echo e(asset('js/cryptopro/polyfills/atob-btoa.js')); ?>"></script>

    <script src="https://api-maps.yandex.ru/2.1/?apikey=ea8643e4-7831-487e-84db-d609b4488c2e&lang=ru_RU"
            type="text/javascript"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
<div class="pt-5 min-vh-100">
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow align-items-center fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                <svg width="200" height="40" viewBox="0 0 1491 296" fill="none" xmlns="http://www.w3.org/2000/svg"
                     class="img-svg replaced-svg">
                    <path
                        d="M429.949 112.684V163.823H408.38V155.474C401.655 162.432 392.9 165.911 382.115 165.911C373.07 165.911 365.823 163.533 360.373 158.779C355.038 154.025 352.371 147.821 352.371 140.167C352.371 132.398 355.27 126.31 361.068 121.903C366.982 117.381 374.926 115.12 384.898 115.12H406.467V111.293C406.467 106.423 405.075 102.712 402.292 100.161C399.625 97.4936 395.683 96.1601 390.464 96.1601C386.174 96.1601 382.289 97.0878 378.81 98.9431C375.332 100.799 371.621 103.813 367.678 107.988L355.502 93.5509C365.475 81.7229 377.999 75.8089 393.074 75.8089C404.438 75.8089 413.425 79.0558 420.034 85.5496C426.644 91.9275 429.949 100.972 429.949 112.684ZM406.467 131.644V130.6H388.029C380.028 130.6 376.027 133.499 376.027 139.298C376.027 142.197 377.129 144.516 379.332 146.255C381.651 147.879 384.666 148.69 388.377 148.69C393.595 148.69 397.886 147.125 401.249 143.994C404.728 140.747 406.467 136.63 406.467 131.644ZM531.517 88.6806C539.519 97.1457 543.519 107.814 543.519 120.686C543.519 133.557 539.519 144.342 531.517 153.039C523.632 161.62 513.717 165.911 501.773 165.911C490.989 165.911 482.408 162.432 476.03 155.474V195.133H452.548V77.7223H474.117V88.5066C480.031 80.0415 489.249 75.8089 501.773 75.8089C513.717 75.8089 523.632 80.0995 531.517 88.6806ZM519.689 120.86C519.689 113.786 517.602 108.046 513.427 103.64C509.253 99.233 503.919 97.0298 497.425 97.0298C491.163 97.0298 485.945 99.1171 481.77 103.292C477.711 107.466 475.682 113.264 475.682 120.686C475.682 128.107 477.711 133.963 481.77 138.254C485.945 142.428 491.163 144.516 497.425 144.516C503.803 144.516 509.079 142.312 513.253 137.906C517.544 133.499 519.689 127.817 519.689 120.86ZM641.084 128.687H580.726C582.118 134.137 584.901 138.37 589.075 141.385C593.366 144.284 598.642 145.733 604.904 145.733C613.369 145.733 621.371 142.834 628.908 137.036L638.649 153.039C628.328 161.62 616.848 165.911 604.208 165.911C590.989 166.142 579.741 161.852 570.464 153.039C561.303 144.11 556.838 133.384 557.07 120.86C556.838 108.452 561.187 97.7835 570.116 88.8545C579.045 79.9255 589.713 75.577 602.121 75.8089C613.949 75.8089 623.632 79.6356 631.169 87.2891C638.823 94.9425 642.649 104.451 642.649 115.815C642.649 119.99 642.128 124.281 641.084 128.687ZM580.726 112.163H619.863C619.747 106.944 617.892 102.77 614.297 99.6389C610.818 96.392 606.47 94.7685 601.251 94.7685C596.265 94.7685 591.917 96.334 588.206 99.465C584.495 102.596 582.002 106.828 580.726 112.163ZM656.101 120.686C656.101 108.162 660.566 97.5516 669.495 88.8545C678.424 80.1575 689.324 75.8089 702.196 75.8089C719.126 75.8089 731.592 82.8825 739.593 97.0298L723.243 109.727C717.445 101.378 710.545 97.2037 702.544 97.2037C695.934 97.2037 690.484 99.465 686.193 103.987C682.019 108.394 679.931 113.96 679.931 120.686C679.931 127.527 682.019 133.21 686.193 137.732C690.484 142.139 695.934 144.342 702.544 144.342C710.545 144.342 717.445 140.225 723.243 131.992L739.593 144.516C735.766 151.241 730.606 156.518 724.112 160.344C717.735 164.055 710.429 165.911 702.196 165.911C689.556 166.142 678.656 161.794 669.495 152.865C660.334 143.82 655.869 133.094 656.101 120.686ZM774.165 163.823V97.5516H747.726V77.7223H824.087V97.5516H797.474V163.823H774.165ZM855.361 163.823V97.5516H828.922V77.7223H905.282V97.5516H878.669V163.823H855.361ZM914.465 120.686C914.233 108.394 918.698 97.7835 927.859 88.8545C937.02 79.9255 947.92 75.577 960.56 75.8089C973.2 75.577 984.1 79.9255 993.261 88.8545C1002.54 97.7835 1007.06 108.394 1006.83 120.686C1007.06 132.978 1002.54 143.646 993.261 152.691C983.984 161.62 973.026 165.969 960.386 165.737C947.746 165.969 936.846 161.62 927.685 152.691C918.64 143.646 914.233 132.978 914.465 120.686ZM976.388 137.558C980.679 133.152 982.824 127.585 982.824 120.86C982.824 114.134 980.679 108.51 976.388 103.987C972.214 99.465 966.938 97.2037 960.56 97.2037C954.066 97.2037 948.732 99.465 944.557 103.987C940.383 108.394 938.295 114.018 938.295 120.86C938.295 127.585 940.383 133.152 944.557 137.558C948.732 141.965 954.066 144.168 960.56 144.168C966.938 144.168 972.214 141.965 976.388 137.558ZM1104.13 88.6806C1112.13 97.1457 1116.13 107.814 1116.13 120.686C1116.13 133.557 1112.13 144.342 1104.13 153.039C1096.25 161.62 1086.33 165.911 1074.39 165.911C1063.6 165.911 1055.02 162.432 1048.64 155.474V195.133H1025.16V77.7223H1046.73V88.5066C1052.64 80.0415 1061.86 75.8089 1074.39 75.8089C1086.33 75.8089 1096.25 80.0995 1104.13 88.6806ZM1092.3 120.86C1092.3 113.786 1090.22 108.046 1086.04 103.64C1081.87 99.233 1076.53 97.0298 1070.04 97.0298C1063.78 97.0298 1058.56 99.1171 1054.38 103.292C1050.32 107.466 1048.3 113.264 1048.3 120.686C1048.3 128.107 1050.32 133.963 1054.38 138.254C1058.56 142.428 1063.78 144.516 1070.04 144.516C1076.42 144.516 1081.69 142.312 1085.87 137.906C1090.16 133.499 1092.3 127.817 1092.3 120.86ZM1135.08 163.823V77.7223H1198.39V97.5516H1158.38V163.823H1135.08ZM1195.96 149.734C1195.96 145.212 1197.53 141.385 1200.66 138.254C1203.79 135.123 1207.68 133.557 1212.31 133.557C1216.84 133.557 1220.61 135.123 1223.62 138.254C1226.75 141.385 1228.32 145.212 1228.32 149.734C1228.32 154.372 1226.81 158.257 1223.79 161.388C1220.78 164.403 1216.95 165.911 1212.31 165.911C1207.68 165.911 1203.79 164.403 1200.66 161.388C1197.53 158.257 1195.96 154.372 1195.96 149.734ZM1327.16 88.6806C1335.16 97.1457 1339.16 107.814 1339.16 120.686C1339.16 133.557 1335.16 144.342 1327.16 153.039C1319.28 161.62 1309.36 165.911 1297.42 165.911C1286.63 165.911 1278.05 162.432 1271.68 155.474V195.133H1248.19V77.7223H1269.76V88.5066C1275.68 80.0415 1284.9 75.8089 1297.42 75.8089C1309.36 75.8089 1319.28 80.0995 1327.16 88.6806ZM1315.33 120.86C1315.33 113.786 1313.25 108.046 1309.07 103.64C1304.9 99.233 1299.56 97.0298 1293.07 97.0298C1286.81 97.0298 1281.59 99.1171 1277.42 103.292C1273.36 107.466 1271.33 113.264 1271.33 120.686C1271.33 128.107 1273.36 133.963 1277.42 138.254C1281.59 142.428 1286.81 144.516 1293.07 144.516C1299.45 144.516 1304.72 142.312 1308.9 137.906C1313.19 133.499 1315.33 127.817 1315.33 120.86ZM1424.9 165.389V195.133H1401.59V165.389C1387.1 164.461 1375.33 160.112 1366.28 152.343C1357.24 144.458 1352.72 133.905 1352.72 120.686C1352.72 107.118 1357.18 96.45 1366.11 88.6806C1375.15 80.7953 1386.98 76.5047 1401.59 75.8089V33.3672H1424.9V75.8089C1439.4 76.7366 1451.17 81.2011 1460.21 89.2024C1469.26 97.0878 1473.78 107.582 1473.78 120.686C1473.78 134.137 1469.26 144.806 1460.21 152.691C1451.28 160.46 1439.51 164.693 1424.9 165.389ZM1402.12 145.559V95.8122C1393.88 96.276 1387.45 98.6532 1382.81 102.944C1378.29 107.234 1376.02 113.206 1376.02 120.86C1376.02 128.165 1378.34 133.963 1382.98 138.254C1387.62 142.544 1394 144.98 1402.12 145.559ZM1450.47 120.338C1450.47 113.032 1448.09 107.176 1443.34 102.77C1438.7 98.3633 1432.38 96.0441 1424.38 95.8122V145.559C1432.61 145.096 1438.99 142.718 1443.51 138.428C1448.15 134.021 1450.47 127.991 1450.47 120.338Z"
                        fill="#444444"></path>
                    <path d="M0.720215 82.1746L254.767 51.1934V137.941L0.720215 168.922V82.1746Z" fill="#DB3A61"></path>
                    <path d="M29.5049 106.359L283.551 75.3779V162.126L29.5049 193.107V106.359Z"
                          fill="url(#paint0_linear)"></path>
                    <defs>
                        <linearGradient id="paint0_linear" x1="30" y1="134" x2="284" y2="134"
                                        gradientUnits="userSpaceOnUse">
                            <stop stop-color="#3A5EDB"></stop>
                            <stop offset="1" stop-color="#698BFF"></stop>
                        </linearGradient>
                    </defs>
                </svg>
            </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false"
                    aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link text-truncate"
                                            href="<?php echo e(route('home')); ?>"><strong>Лоты</strong></a></li>
                    <li class="nav-item"><a class="nav-link text-truncate"
                                            href="<?php echo e(route('auction')); ?>"><strong>Аукционы</strong></a></li>
                    <li class="nav-item"><a class="nav-link text-truncate"
                                            href="<?php echo e(route('sign')); ?>"><strong>Настроить ЭП</strong></a></li>
                    <li class="nav-item"><a class="nav-link text-truncate"
                                            href="<?php echo e(route('regulations')); ?>"><strong>Регламент</strong></a></li>
                    <li class="nav-item"><a class="nav-link text-truncate"
                                            href="<?php echo e(route('rates')); ?>"><strong>Тарифы</strong></a></li>
                    <li class="nav-item"><a class="nav-link text-truncate"
                                            href="<?php echo e(route('faq')); ?>"><strong>Вопрос-ответ</strong></a></li>
                    <li class="nav-item"><a class="nav-link text-truncate"
                                            href="<?php echo e(route('contacts')); ?>"><strong>Контакты</strong></a>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto d-lg-flex">
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>"><h5>Вход</h5></a>
                        </li>
                        <li class="nav-item d-none d-lg-flex"><span class="nav-link">или</span></li>
                        <?php if(Route::has('register')): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('register')); ?>"><h5>Регистрация</h5></a>
                            </li>
                        <?php endif; ?>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link text-truncate" href="<?php echo e(route('personal')); ?>">
                                <h5 class="mb-0">
                                    <strong>
                                        <?php if(isset($my_profile)): ?>
                                            <?php if($my_profile->user_type == 0): ?>
                                                <?php echo e($my_profile->title); ?>

                                            <?php else: ?>
                                                <?php echo e($my_profile->full_name); ?>

                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </strong>
                                </h5>
                                <?php if($my_profile->user_role == 0): ?>
                                    Организатор торгов
                                <?php else: ?>
                                    Участник торгов
                                <?php endif; ?>
                            </a>
                        </li>
                    <?php endif; ?>
                    <li class="dropdown-divider"></li>
                </ul>
                <?php if(auth()->guard()->check()): ?>
                    <ul class="navbar-nav ml-auto d-lg-none">
                        <li class="nav-item">
                            <a class="nav-link"><strong><?php echo e(\Illuminate\Support\Carbon::now()->format('d.m.Y')); ?></strong>
                                <strong class="clock"><?php echo e(\Illuminate\Support\Carbon::now()->format('H:i:s')); ?></strong></a>
                        </li>
                        <?php if(isset($my_profile) and $my_profile->confirmed == 2): ?>
                            <?php if($my_profile->user_role == 0): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('auction', ['my_auc' => 1])); ?>">Мои аукционы</a>
                                </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('bidding')); ?>">Мои торги <?php if($count_biddings > 0): ?>
                                        (<?php echo e($count_biddings); ?>)<?php endif; ?></a>
                            </li>
                            <?php if($my_profile->user_role == 0): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('bargaining')); ?>">Заявки на
                                        участие <?php if($count_filings > 0): ?>(<?php echo e($count_filings); ?>)<?php endif; ?></a>
                                </li>
                            <?php elseif($my_profile->user_role == 1): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('filing')); ?>">Заявки на
                                        участие <?php if($count_filings > 0): ?>(<?php echo e($count_filings); ?>)<?php endif; ?></a>
                                </li>
                            <?php endif; ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('finance')); ?>">Финансы</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('personal')); ?>">Профиль</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('messages')); ?>">Уведомления <?php if($count_messages > 0): ?>
                                        (<?php echo e($count_messages); ?>)<?php endif; ?></a>
                            </li>
                        <?php else: ?>
                            <?php if(isset(Auth::user()->cert) and isset(Auth::user()->cert_name)): ?>
                                <li class="nav-item">
                                    <a class="nav-link"
                                       href="<?php echo e(route('accreditation')); ?>">Пройти аккредитацию</a>
                                </li>
                            <?php else: ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('sign')); ?>">Выполнить проверку ЭЦП</a>
                                </li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><strong>Выход</strong></a>
                        </li>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <?php if(auth()->guard()->check()): ?>
        <ul class="nav justify-content-end d-none d-lg-flex bg-white pb-1" style="padding-top: 2.3rem;">
            <li class="nav-item">
                <a class="nav-link"><strong><?php echo e(\Illuminate\Support\Carbon::now()->format('d.m.Y')); ?></strong> <strong
                        class="clock"><?php echo e(\Illuminate\Support\Carbon::now()->format('H:i:s')); ?></strong></a>
            </li>
            <?php if(isset($my_profile) and $my_profile->confirmed == 2): ?>
                <?php if($my_profile->user_role == 0): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('auction', ['my_auc' => 1])); ?>">Мои аукционы</a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('bidding')); ?>">Мои торги <?php if($count_biddings > 0): ?>
                            (<?php echo e($count_biddings); ?>)<?php endif; ?></a>
                </li>
                <?php if($my_profile->user_role == 0): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('bargaining')); ?>">Заявки на участие <?php if($count_filings > 0): ?>
                                (<?php echo e($count_filings); ?>)<?php endif; ?></a>
                    </li>
                <?php elseif($my_profile->user_role == 1): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('filing')); ?>">Заявки на участие <?php if($count_filings > 0): ?>
                                (<?php echo e($count_filings); ?>)<?php endif; ?></a>
                    </li>
                <?php endif; ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('finance')); ?>">Финансы</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('personal')); ?>">Профиль</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('messages')); ?>">Уведомления <?php if($count_messages > 0): ?>
                            (<?php echo e($count_messages); ?>)</span><?php endif; ?></a>
                </li>
            <?php else: ?>
                <?php if(isset(Auth::user()->cert) and isset(Auth::user()->cert_name)): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('accreditation')); ?>">Пройти аккредитацию</a>
                    </li>
                <?php else: ?>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('sign')); ?>">Выполнить проверку ЭЦП</a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><strong>Выход</strong></a>
            </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </ul>
    <?php endif; ?>

    <main class="py-5">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <?php if(isset($alert) and $alert != null): ?>
        <div class="modal fade" id="alert" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content rounded-0">
                    <div class="modal-body">
                        <div class="col modal-title text-center p-3">
                            <h5><?php echo e($alert); ?></h5>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-block btn-success btn-lg rounded-0" data-dismiss="modal">
                            Понятно
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <script>
            $(document).ready(function () {
                $('#alert').modal('show')
            });
        </script>
    <?php endif; ?>

    <script>
        $(document).ready(function () {
            let h = parseInt('<?php echo e(\Illuminate\Support\Carbon::now()->format('H')); ?>'),
                m = parseInt('<?php echo e(\Illuminate\Support\Carbon::now()->format('i')); ?>'),
                s = parseInt('<?php echo e(\Illuminate\Support\Carbon::now()->format('s')); ?>');
            const timer = setInterval(function () {
                let str_clock = ('0' + h).slice(-2) + ':' + ('0' + m).slice(-2) + ':' + ('0' + s).slice(-2);
                $('.clock').text(str_clock);
                ++s;
                if (s === 60) {
                    s = 0;
                    m = m + 1;
                }
                if (m === 60) {
                    m = 0;
                    h = h + 1;
                }
                if (h === 24) {
                    h = 0;
                }
            }, 1000);
        });
    </script>

</div>


<footer class="d-flex justify-content-between align-items-center bg-white pt-3">
    <div class="container">
        <div class="row">
            <div class="text-center col-md-auto">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <svg width="200" height="40" viewBox="0 0 1491 330" fill="none" xmlns="http://www.w3.org/2000/svg"
                         class="img-svg replaced-svg">
                        <path
                            d="M429.949 112.684V163.823H408.38V155.474C401.655 162.432 392.9 165.911 382.115 165.911C373.07 165.911 365.823 163.533 360.373 158.779C355.038 154.025 352.371 147.821 352.371 140.167C352.371 132.398 355.27 126.31 361.068 121.903C366.982 117.381 374.926 115.12 384.898 115.12H406.467V111.293C406.467 106.423 405.075 102.712 402.292 100.161C399.625 97.4936 395.683 96.1601 390.464 96.1601C386.174 96.1601 382.289 97.0878 378.81 98.9431C375.332 100.799 371.621 103.813 367.678 107.988L355.502 93.5509C365.475 81.7229 377.999 75.8089 393.074 75.8089C404.438 75.8089 413.425 79.0558 420.034 85.5496C426.644 91.9275 429.949 100.972 429.949 112.684ZM406.467 131.644V130.6H388.029C380.028 130.6 376.027 133.499 376.027 139.298C376.027 142.197 377.129 144.516 379.332 146.255C381.651 147.879 384.666 148.69 388.377 148.69C393.595 148.69 397.886 147.125 401.249 143.994C404.728 140.747 406.467 136.63 406.467 131.644ZM531.517 88.6806C539.519 97.1457 543.519 107.814 543.519 120.686C543.519 133.557 539.519 144.342 531.517 153.039C523.632 161.62 513.717 165.911 501.773 165.911C490.989 165.911 482.408 162.432 476.03 155.474V195.133H452.548V77.7223H474.117V88.5066C480.031 80.0415 489.249 75.8089 501.773 75.8089C513.717 75.8089 523.632 80.0995 531.517 88.6806ZM519.689 120.86C519.689 113.786 517.602 108.046 513.427 103.64C509.253 99.233 503.919 97.0298 497.425 97.0298C491.163 97.0298 485.945 99.1171 481.77 103.292C477.711 107.466 475.682 113.264 475.682 120.686C475.682 128.107 477.711 133.963 481.77 138.254C485.945 142.428 491.163 144.516 497.425 144.516C503.803 144.516 509.079 142.312 513.253 137.906C517.544 133.499 519.689 127.817 519.689 120.86ZM641.084 128.687H580.726C582.118 134.137 584.901 138.37 589.075 141.385C593.366 144.284 598.642 145.733 604.904 145.733C613.369 145.733 621.371 142.834 628.908 137.036L638.649 153.039C628.328 161.62 616.848 165.911 604.208 165.911C590.989 166.142 579.741 161.852 570.464 153.039C561.303 144.11 556.838 133.384 557.07 120.86C556.838 108.452 561.187 97.7835 570.116 88.8545C579.045 79.9255 589.713 75.577 602.121 75.8089C613.949 75.8089 623.632 79.6356 631.169 87.2891C638.823 94.9425 642.649 104.451 642.649 115.815C642.649 119.99 642.128 124.281 641.084 128.687ZM580.726 112.163H619.863C619.747 106.944 617.892 102.77 614.297 99.6389C610.818 96.392 606.47 94.7685 601.251 94.7685C596.265 94.7685 591.917 96.334 588.206 99.465C584.495 102.596 582.002 106.828 580.726 112.163ZM656.101 120.686C656.101 108.162 660.566 97.5516 669.495 88.8545C678.424 80.1575 689.324 75.8089 702.196 75.8089C719.126 75.8089 731.592 82.8825 739.593 97.0298L723.243 109.727C717.445 101.378 710.545 97.2037 702.544 97.2037C695.934 97.2037 690.484 99.465 686.193 103.987C682.019 108.394 679.931 113.96 679.931 120.686C679.931 127.527 682.019 133.21 686.193 137.732C690.484 142.139 695.934 144.342 702.544 144.342C710.545 144.342 717.445 140.225 723.243 131.992L739.593 144.516C735.766 151.241 730.606 156.518 724.112 160.344C717.735 164.055 710.429 165.911 702.196 165.911C689.556 166.142 678.656 161.794 669.495 152.865C660.334 143.82 655.869 133.094 656.101 120.686ZM774.165 163.823V97.5516H747.726V77.7223H824.087V97.5516H797.474V163.823H774.165ZM855.361 163.823V97.5516H828.922V77.7223H905.282V97.5516H878.669V163.823H855.361ZM914.465 120.686C914.233 108.394 918.698 97.7835 927.859 88.8545C937.02 79.9255 947.92 75.577 960.56 75.8089C973.2 75.577 984.1 79.9255 993.261 88.8545C1002.54 97.7835 1007.06 108.394 1006.83 120.686C1007.06 132.978 1002.54 143.646 993.261 152.691C983.984 161.62 973.026 165.969 960.386 165.737C947.746 165.969 936.846 161.62 927.685 152.691C918.64 143.646 914.233 132.978 914.465 120.686ZM976.388 137.558C980.679 133.152 982.824 127.585 982.824 120.86C982.824 114.134 980.679 108.51 976.388 103.987C972.214 99.465 966.938 97.2037 960.56 97.2037C954.066 97.2037 948.732 99.465 944.557 103.987C940.383 108.394 938.295 114.018 938.295 120.86C938.295 127.585 940.383 133.152 944.557 137.558C948.732 141.965 954.066 144.168 960.56 144.168C966.938 144.168 972.214 141.965 976.388 137.558ZM1104.13 88.6806C1112.13 97.1457 1116.13 107.814 1116.13 120.686C1116.13 133.557 1112.13 144.342 1104.13 153.039C1096.25 161.62 1086.33 165.911 1074.39 165.911C1063.6 165.911 1055.02 162.432 1048.64 155.474V195.133H1025.16V77.7223H1046.73V88.5066C1052.64 80.0415 1061.86 75.8089 1074.39 75.8089C1086.33 75.8089 1096.25 80.0995 1104.13 88.6806ZM1092.3 120.86C1092.3 113.786 1090.22 108.046 1086.04 103.64C1081.87 99.233 1076.53 97.0298 1070.04 97.0298C1063.78 97.0298 1058.56 99.1171 1054.38 103.292C1050.32 107.466 1048.3 113.264 1048.3 120.686C1048.3 128.107 1050.32 133.963 1054.38 138.254C1058.56 142.428 1063.78 144.516 1070.04 144.516C1076.42 144.516 1081.69 142.312 1085.87 137.906C1090.16 133.499 1092.3 127.817 1092.3 120.86ZM1135.08 163.823V77.7223H1198.39V97.5516H1158.38V163.823H1135.08ZM1195.96 149.734C1195.96 145.212 1197.53 141.385 1200.66 138.254C1203.79 135.123 1207.68 133.557 1212.31 133.557C1216.84 133.557 1220.61 135.123 1223.62 138.254C1226.75 141.385 1228.32 145.212 1228.32 149.734C1228.32 154.372 1226.81 158.257 1223.79 161.388C1220.78 164.403 1216.95 165.911 1212.31 165.911C1207.68 165.911 1203.79 164.403 1200.66 161.388C1197.53 158.257 1195.96 154.372 1195.96 149.734ZM1327.16 88.6806C1335.16 97.1457 1339.16 107.814 1339.16 120.686C1339.16 133.557 1335.16 144.342 1327.16 153.039C1319.28 161.62 1309.36 165.911 1297.42 165.911C1286.63 165.911 1278.05 162.432 1271.68 155.474V195.133H1248.19V77.7223H1269.76V88.5066C1275.68 80.0415 1284.9 75.8089 1297.42 75.8089C1309.36 75.8089 1319.28 80.0995 1327.16 88.6806ZM1315.33 120.86C1315.33 113.786 1313.25 108.046 1309.07 103.64C1304.9 99.233 1299.56 97.0298 1293.07 97.0298C1286.81 97.0298 1281.59 99.1171 1277.42 103.292C1273.36 107.466 1271.33 113.264 1271.33 120.686C1271.33 128.107 1273.36 133.963 1277.42 138.254C1281.59 142.428 1286.81 144.516 1293.07 144.516C1299.45 144.516 1304.72 142.312 1308.9 137.906C1313.19 133.499 1315.33 127.817 1315.33 120.86ZM1424.9 165.389V195.133H1401.59V165.389C1387.1 164.461 1375.33 160.112 1366.28 152.343C1357.24 144.458 1352.72 133.905 1352.72 120.686C1352.72 107.118 1357.18 96.45 1366.11 88.6806C1375.15 80.7953 1386.98 76.5047 1401.59 75.8089V33.3672H1424.9V75.8089C1439.4 76.7366 1451.17 81.2011 1460.21 89.2024C1469.26 97.0878 1473.78 107.582 1473.78 120.686C1473.78 134.137 1469.26 144.806 1460.21 152.691C1451.28 160.46 1439.51 164.693 1424.9 165.389ZM1402.12 145.559V95.8122C1393.88 96.276 1387.45 98.6532 1382.81 102.944C1378.29 107.234 1376.02 113.206 1376.02 120.86C1376.02 128.165 1378.34 133.963 1382.98 138.254C1387.62 142.544 1394 144.98 1402.12 145.559ZM1450.47 120.338C1450.47 113.032 1448.09 107.176 1443.34 102.77C1438.7 98.3633 1432.38 96.0441 1424.38 95.8122V145.559C1432.61 145.096 1438.99 142.718 1443.51 138.428C1448.15 134.021 1450.47 127.991 1450.47 120.338Z"
                            fill="#444444"></path>
                        <path d="M0.720215 82.1746L254.767 51.1934V137.941L0.720215 168.922V82.1746Z"
                              fill="#DB3A61"></path>
                        <path d="M29.5049 106.359L283.551 75.3779V162.126L29.5049 193.107V106.359Z"
                              fill="url(#paint0_linear)"></path>
                        <defs>
                            <linearGradient id="paint0_linear" x1="30" y1="134" x2="284" y2="134"
                                            gradientUnits="userSpaceOnUse">
                                <stop stop-color="#3A5EDB"></stop>
                                <stop offset="1" stop-color="#698BFF"></stop>
                            </linearGradient>
                        </defs>
                    </svg>
                </a>
            </div>
            <div class="col-md text-center">
                Оператором торговой площадки является компания ООО «Арестторг» Все права защищены. 2020. <a
                    href="https://docs.google.com/document/d/1tv7audgv_nlxm4-96gbpOxkz5eT-Tk5j33aMY54cyuE/edit#"
                    target="_blank">Публичная оферта</a>
            </div>
        </div>
    </div>
</footer>

</body>
</html>
<?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/layouts/app.blade.php ENDPATH**/ ?>