<?php $__env->startSection('title', 'Верификация пользователя – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="alert alert-light rounded-0 shadow">
            <h3>Ссылка для подтверждения почты не действительна</h3>
            <h5>Ссылка для подтверждения почты действительна 60 минут с момента отправки</h5>
            <h5><a href="<?php echo e(route('accreditation')); ?>">Продолжить регистрацию</a></h5>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/errors/403.blade.php ENDPATH**/ ?>