<?php $__env->startSection('title', 'Вывод средств – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Вывод средств</h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50 p-0">
                <div class="row text-dark m-4">
                    <div class="col-lg">
                        <h5><?php if($my_profile->user_type == 0): ?> <?php echo e($my_profile->title); ?> <?php elseif($my_profile->user_type == 1): ?> <?php echo e('ИП ' . $my_profile->full_name); ?> <?php elseif($my_profile->user_type == 2): ?> <?php echo e('ФЛ ' . $my_profile->full_name); ?> <?php endif; ?></h5>
                    </div>
                    <div class="col-lg-auto">
                        <h5 class="text-info">
                            <?php if($my_profile->user_role == 0): ?>
                                Организатор торгов
                            <?php elseif($my_profile->user_role == 1): ?>
                                Участник торгов
                            <?php endif; ?>
                        </h5>
                    </div>
                </div>
                <div class="list-group list-group-horizontal-lg rounded-0">
                    <a class="card-link list-group-item list-group-item-secondary rounded-0 active" href="#all"
                       data-toggle="tab"><h5>Заявка на вывод</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#docs" data-toggle="tab"><h5>
                            Активные</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#events" data-toggle="tab"><h5>
                            Выполненные</h5></a>
                    <a class="col list-group-item rounded-0 text-right text-dark" href="<?php echo e(route('finance')); ?>">
                        <h5>Баланс: <?php echo e(number_format($my_profile->balance / 100, 2, '.', '')); ?> ₽ |
                            Блок: <?php echo e(number_format($my_profile->blocked / 100, 2, '.', '')); ?> ₽
                        </h5>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane fade active show" id="all">
                        <form method="POST" action="<?php echo e(route('withdrawal')); ?>">
                            <?php echo csrf_field(); ?>
                            <h5 class="row">
                                <p class="col-lg-4">Сумма для вывода:</p>
                                <div class="col">
                                    <div class="input-group">
                                        <input name="summ" type="number"
                                               class="form-control form-control-lg rounded-0" required="required">
                                        <div class="input-group-append">
                                            <div class="input-group-text rounded-0">Руб</div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="input-group">
                                        <input name="kopp" type="number"
                                               class="form-control form-control-lg rounded-0" required="required">
                                        <div class="input-group-append">
                                            <div class="input-group-text rounded-0">Коп</div>
                                        </div>
                                    </div>
                                </div>
                            </h5>
                            <hr>
                            <h5 class="row">
                                <p class="col-lg-4">Реквизиты для вывода:</p>
                                <div class="col">
                                    <textarea name="requisites" cols="40" rows="5"
                                              class="form-control form-control-lg rounded-0"
                                              required></textarea>
                                </div>
                            </h5>
                            <hr>
                            <div class="row">
                                <div class="col">
                                    <button name="submit" type="submit"
                                            class="btn btn-block btn-lg btn-primary rounded-0">Подать заявку на вывод
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="tab-pane fade" id="docs">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Номер заявки</th>
                                <th scope="col">Дата время заявки</th>
                                <th scope="col">ИНН</th>
                                <th scope="col">Реквизиты</th>
                                <th scope="col">Сумма</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $withd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $with): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($with->status == 0): ?>
                                    <tr>
                                        <th scope="row"><?php echo e($with->id); ?></th>
                                        <td><?php echo e($with->created_at); ?></td>
                                        <td><?php echo e($my_profile->inn); ?></td>
                                        <td><?php echo e($with->requisites); ?></td>
                                        <td><?php echo e(number_format($with->summ / 100, 2, '.', '')); ?> ₽</td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade" id="events">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Номер заявки</th>
                                <th scope="col">Дата время заявки</th>
                                <th scope="col">ИНН</th>
                                <th scope="col">Реквизиты</th>
                                <th scope="col">Сумма</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $withd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $with): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($with->status == 1): ?>
                                    <tr>
                                        <th scope="row"><?php echo e($with->id); ?></th>
                                        <td><?php echo e($with->created_at); ?></td>
                                        <td><?php echo e($my_profile->inn); ?></td>
                                        <td><?php echo e($with->requisites); ?></td>
                                        <td><?php echo e(number_format($with->summ / 100, 2, '.', '')); ?> ₽</td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/withdrawal.blade.php ENDPATH**/ ?>