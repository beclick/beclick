<?php $__env->startSection('title', 'Вход в админку – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row bg-danger">
                <div class="col-auto">
                    <h6>Аукцион: <?php echo e($lot->auction->id); ?> </h6>
                    <h6>Лот: <?php echo e($lot->num_lot); ?> </h6>
                    <h6>Победитель ID: <?php echo e($lot->rates->max()->profile->id); ?> </h6>
                    <h6>Победитель ФИО: <?php echo e($lot->rates->max()->profile->full_name); ?> </h6>
                </div>
            </div>
            <?php $__currentLoopData = $lot->filings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row bg-warning">
                    <div class="col-auto">
                        <h6>Участник ID: <?php echo e($filing->profile->id); ?> </h6>
                        <h6><?php if(isset($filing->profile->full_name)): ?> Участник ФИО: <?php echo e($filing->profile->full_name); ?> <?php else: ?>
                                Участник название: <?php echo e($filing->profile->title); ?> <?php endif; ?> </h6>
                    </div>
                </div>
                <?php $__currentLoopData = $filing->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="row">
                        <div class="col-auto">
                            <h6><a target="_blank" href="<?php echo e(asset('storage/' . $doc->path)); ?>"><?php echo e($doc->file_name); ?></a>
                            </h6>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/admin/filings.blade.php ENDPATH**/ ?>