<?php $__env->startSection('title', 'Заявки на участие – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-5">
        <h3>Ваши заявки</h3>
        <hr>
        <?php $__currentLoopData = $filings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($filing->auction->status == 1): ?>
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-white text-black-50 p-0">
                        <div class="row text-dark m-4">
                            <h4><?php echo e($filing->lot->name); ?></h4>
                        </div>
                        <div class="list-group list-group-horizontal-lg rounded-0">
                            <a class="list-group-item list-group-item-secondary rounded-0 active" href="#all<?php echo e($filing->id); ?>"
                               data-toggle="tab"><h5>Информация</h5></a>
                            <a class="list-group-item list-group-item-secondary rounded-0" href="#docs<?php echo e($filing->id); ?>"
                               data-toggle="tab"><h5>
                                    Документы</h5></a>
                            <div class="p-0 col list-group-item rounded-0">
                                <?php if($filing->lot->status == 0): ?>
                                    <?php if($filing->status == 0 and strtotime(date('Y-m-d H:i')) < strtotime($filing->lot->end_request)): ?>
                                        <form class="h-100" method="POST" action="<?php echo e(route('filing')); ?>">
                                            <?php echo csrf_field(); ?>
                                            <input name="confirm" value="false" hidden>
                                            <input name="filing" value="<?php echo e($filing->id); ?>" hidden>
                                            <button type="button"
                                                    class="ecp_button h-100 btn btn-block btn-lg btn-danger rounded-0">
                                                Отменить
                                                заявку
                                            </button>
                                        </form>
                                    <?php elseif($filing->status == 1 and strtotime($filing->lot->start_auction) <= strtotime(date('Y-m-d H:i'))): ?>
                                        <?php if(!$filing->lot->protocol->isEmpty()): ?>
                                            <a target="_blank" class="h-100 btn btn-block btn-lg btn-success rounded-0"
                                               href="<?php echo e(route('auction_hall', ['lot' => $filing->lot->id])); ?>">Перейти
                                                к
                                                торгам</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                <?php elseif($filing->lot->status == 1): ?>
                                    <?php if(!$filing->lot->protocol->isEmpty()): ?>
                                        <a target="_blank" class="h-100 btn btn-block btn-lg btn-success rounded-0"
                                           href="<?php echo e(route('auction_hall', ['lot' => $filing->lot->id])); ?>">Посмотреть
                                            результаты</a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="all<?php echo e($filing->id); ?>">
                                <h5 class="row">
                                    <p class="col-lg-3 text-black-50">Номер заявки:</p>
                                    <p class="col"><?php echo e($filing->id); ?></p>
                                </h5>
                                <h5 class="row">
                                    <p class="col-lg-3 text-black-50">Аукцион:</p>
                                    <p class="col"><?php echo e($filing->auction->name); ?></p>
                                </h5>
                                <h5 class="row">
                                    <p class="col-lg-3 text-black-50">Организатор:</p>
                                    <p class="col"><?php echo e($filing->auction->organiser); ?></p>
                                </h5>
                                <h5 class="row">
                                    <p class="col-lg-3 text-black-50">Дата подачи:&nbsp;</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($filing->created_at)->format('d.m.Y H:i')); ?></p>
                                </h5>
                            </div>
                            <div class="tab-pane fade" id="docs<?php echo e($filing->id); ?>">
                                <?php $__currentLoopData = $filing->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <strong>
                                        <div class="row">
                                            <div class="col">
                                                <a target="_blank" class="col-lg-7" target="_blank"
                                                   href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                                    <?php echo e($doc->file_name); ?>

                                                </a>
                                            </div>
                                            <div class="col-auto">
                                                <?php if($doc->sign): ?>
                                                    ПОДПИСАН ЭП
                                                <?php else: ?>
                                                    НЕ ПОДПИСАН
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </strong>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo $__env->make('layouts.ecp-modal', ['title' => 'Подтверждаю отмену заявки на участие в торгах по лоту, согласно регламента ЭТП.', 'submit' => 'Продолжить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/my-filing.blade.php ENDPATH**/ ?>