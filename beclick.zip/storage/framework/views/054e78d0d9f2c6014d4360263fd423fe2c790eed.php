<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">

    <title>Добро пожаловать – Арестторг.рф</title>


    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
<main>
    <section class="container-fluid reg-main d-flex flex-column align-items-center justify-content-center">
        <br>
        <h5 class="reg-main__title">с 22:00 06.10.2020 до 22:00 07.10.2020 по Московскому времени, сайт ЭТП арестторг.рф будет недоступен в связи с плановыми работами. Приносим свои извинения за неудобства.</h5>
    </section>
</main>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/welcome.blade.php ENDPATH**/ ?>