<?php $__env->startSection('title', 'Новый лот – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Аукцион номер <?php echo e($auction->id); ?> | <?php if(empty($lot)): ?> Новый лот <?php else: ?> Редактировать лот <?php endif; ?></h3>
        <hr>
        <form method="POST" action="<?php echo e(route('creation-lot')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <input name="auction" value="<?php echo e($auction->id); ?>" hidden>
            <h5>Категория лота</h5>
            <div class="form-row">
                <div class="form-group col">
                    <select class="custom-select custom-select-lg rounded-0" name="category" required>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option <?php if(isset($lot) and $lot->category_id == $category->id): ?> selected
                                    <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <hr>
            <h5>Общая информация</h5>
            <div class="form-row">
                <div class="form-group col">
                    <input <?php if(isset($lot)): ?> value="<?php echo e($lot->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>"
                           <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="text" name="name" placeholder="Название лота" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <input <?php if(isset($lot)): ?> value="<?php echo e($lot->debtor); ?>" <?php else: ?> value="<?php echo e(old('debtor')); ?>"
                           <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['debtor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="text" name="debtor"
                           placeholder="<?php if($auction->type == 1): ?> Имущество должника (ФИО) <?php elseif($auction->type == 2): ?> Владелец имущества <?php endif; ?>"
                           required>
                    <?php $__errorArgs = ['debtor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <input <?php if(isset($lot)): ?> value="<?php echo e($lot->place); ?>" <?php else: ?> value="<?php echo e(old('place')); ?>"
                           <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="text" name="place" placeholder="Местоположение имущества" required>
                    <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <input <?php if(isset($lot)): ?> value="<?php echo e($lot->kadastr); ?>" <?php else: ?> value="<?php echo e(old('kadastr')); ?>"
                           <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['kadastr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                           type="text" name="kadastr" placeholder="Кадастровый номер">
                    <?php $__errorArgs = ['kadastr'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-row">
                <div class="col text-center">
                    <input id="suggest" class="form-control form-control-lg rounded-0" type="text"
                           placeholder="Адрес имущества на карте" name="address"
                           value="<?php if(isset($lot->address)): ?> <?php echo e($lot->address); ?> <?php endif; ?>">
                    <input id="coord" type="hidden" name="coord"
                           value="<?php if(isset($lot->coord)): ?> <?php echo e($lot->coord); ?> <?php endif; ?>">
                </div>
            </div>
            <div class="row">
                <div id="map" class="col" style="height:400px"></div>
            </div>
            <br>
            <div class="row">
                <div class="col-lg text-center">
                    <h5>Начальная цена продажи</h5>
                    <div class="form-row">
                        <div class="form-group col">
                            <div class="input-group">
                                <input <?php if(isset($lot)): ?> value="<?php echo e(substr($lot->start_price, 0, strlen($lot->start_price) - 2)); ?>"
                                       <?php else: ?> value="<?php echo e(old('start_price_rub')); ?>"
                                       <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['start_price_rub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required type="number" name="start_price_rub">
                                <div class="input-group-append">
                                    <div class="input-group-text rounded-0">
                                        Руб
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['start_price_rub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col">
                            <div class="input-group">
                                <input <?php if(isset($lot)): ?> value="<?php echo e(substr($lot->start_price, -2)); ?>"
                                       <?php elseif(old('start_price_kop')): ?> value="<?php echo e(old('start_price_kop')); ?>" <?php else: ?> value="00"
                                       <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['start_price_kop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required type="number" name="start_price_kop">
                                <div class="input-group-append">
                                    <div class="input-group-text rounded-0">
                                        Коп
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['start_price_kop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg text-center">
                    <h5>Сумма задатка</h5>
                    <div class="form-row">
                        <div class="form-group col">
                            <div class="input-group">
                                <input <?php if(isset($lot)): ?> value="<?php echo e(substr($lot->deposit_price, 0, strlen($lot->deposit_price) - 2)); ?>"
                                       <?php else: ?> value="<?php echo e(old('deposit_price_rub')); ?>"
                                       <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['deposit_price_rub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required type="number" name="deposit_price_rub">
                                <div class="input-group-append">
                                    <div class="input-group-text rounded-0">
                                        Руб
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['deposit_price_rub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col">
                            <div class="input-group">
                                <input <?php if(isset($lot)): ?> value="<?php echo e(substr($lot->deposit_price, -2)); ?>"
                                       <?php elseif(old('deposit_price_kop')): ?> value="<?php echo e(old('deposit_price_kop')); ?>" <?php else: ?> value="00"
                                       <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['deposit_price_kop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required type="number" name="deposit_price_kop">
                                <div class="input-group-append">
                                    <div class="input-group-text rounded-0">
                                        Коп
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['deposit_price_kop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg text-center">
                    <h5>Шаг аукциона</h5>
                    <div class="form-row">
                        <div class="form-group col">
                            <div class="input-group">
                                <input <?php if(isset($lot)): ?> value="<?php echo e(substr($lot->step_price, 0, strlen($lot->step_price) - 2)); ?>"
                                       <?php else: ?> value="<?php echo e(old('step_price_rub')); ?>"
                                       <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['step_price_rub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required type="number" name="step_price_rub">
                                <div class="input-group-append">
                                    <div class="input-group-text rounded-0">
                                        Руб
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['step_price_rub'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col">
                            <div class="input-group">
                                <input <?php if(isset($lot)): ?> value="<?php echo e(substr($lot->step_price, -2)); ?>"
                                       <?php elseif(old('step_price_kop')): ?> value="<?php echo e(old('step_price_kop')); ?>" <?php else: ?> value="00"
                                       <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['step_price_kop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       required type="number" name="step_price_kop">
                                <div class="input-group-append">
                                    <div class="input-group-text rounded-0">
                                        Коп
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['step_price_kop'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <h5>Порядок и сроки участия</h5>
            <div class="form-row">
                <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['order1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              required placeholder="Основные характеристики и описание имущества"
                              name="order1"><?php if(isset($lot)): ?> <?php echo e($lot->order1); ?> <?php elseif(old('order1')): ?> <?php echo e(old('order1')); ?> <?php endif; ?></textarea>
                    <?php $__errorArgs = ['order1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['order2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              required placeholder="Порядок ознакомления с имуществом"
                              name="order2"><?php if(isset($lot)): ?> <?php echo e($lot->order2); ?> <?php elseif(old('order2')): ?> <?php echo e(old('order2')); ?> <?php endif; ?></textarea>
                    <?php $__errorArgs = ['order2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['order3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              required
                              placeholder="Порядок оформления участия в торгах, перечень представляемых участниками торгов документов и требования к их оформлению"
                              name="order3"><?php if(isset($lot)): ?> <?php echo e($lot->order3); ?> <?php elseif(old('order3')): ?> <?php echo e(old('order3')); ?> <?php endif; ?></textarea>
                    <?php $__errorArgs = ['order3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <?php if(isset($lot)): ?> <input name="lot" value="<?php echo e($lot->id); ?>" hidden>  <?php endif; ?>
            <button type="button" class="ecp_button btn btn-success btn-lg btn-block rounded-0">Подписать и добавить
                лот
            </button>
        </form>

        <?php echo $__env->make('layouts.ecp-modal', ['file' => 'true', 'title' => 'Подтверждаю свое согласие на размещение лота на ЭТП, согласно регламенту ЭТП.', 'submit' => 'Разместить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
            ymaps.ready(function () {
                var placemark,
                    suggestView = new ymaps.SuggestView('suggest'),
                    map = new ymaps.Map('map', {
                        center: [55, 34],
                        zoom: 10,
                        controls: ['geolocationControl']
                    }, {
                        searchControlProvider: 'yandex#map'
                    });

                    <?php if(isset($lot->coord)): ?>
                var coords = [<?php echo e($lot->coord); ?>];
                setPlacemark(coords);
                <?php endif; ?>

                map.events.add('click', function (e) {
                    var coords = e.get('coords');

                    setPlacemark(coords);
                    getAddress(coords);
                });

                suggestView.events.add('select', function (event) {
                    var value = event.get('item').value;
                    ymaps.geocode(value)
                        .then(function (res) {
                            var firstGeoObject = res.geoObjects.get(0),
                                coords = firstGeoObject.geometry.getCoordinates();

                            setPlacemark(coords);
                            getAddress(coords);
                        });
                });

                function setPlacemark(coords) {
                    if (placemark) {
                        placemark.geometry.setCoordinates(coords);
                    } else {
                        placemark = new ymaps.Placemark(coords, {
                            iconCaption: 'определение адреса...'
                        }, {
                            preset: 'islands#blueHomeCircleIcon'
                        });
                        map.geoObjects.add(placemark);
                    }
                    map.setCenter(coords);
                    $('#coord').val(coords);
                }

                function getAddress(coords) {
                    placemark.properties.set('iconCaption', 'поиск...');
                    ymaps.geocode(coords).then(function (res) {
                        var firstGeoObject = res.geoObjects.get(0),
                            hint;
                        if (firstGeoObject) {
                            var address = firstGeoObject.getAddressLine();
                            placemark.properties
                                .set({
                                    iconCaption: address
                                });
                            $('#suggest').val(address);
                        }
                    });
                }
            });
        </script>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/creation-lot.blade.php ENDPATH**/ ?>