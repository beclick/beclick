<?php $__env->startSection('title', 'Мои проекты'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                Мои проекты <i class="fa fa-angle-left"></i> <a href="#">Главная</a>
            </div>
            <h1>Мои проекты</h1>
        </div>
        <div class="projects-top-menu">
            <ul>
                <li><a class="a1 active">открытые</a></li>
                <li><a class="a2">архив</a></li>
            </ul>
        </div>
    </div>
    <div class="projects-page flex2 p2">
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count no2">
                    Нет откликов
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count no2">
                    Нет откликов
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
    </div>
    <div class="projects-page p1 active flex2">
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count">
                    <span>+2</span> 24 <a href="#">Отклики</a>
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count no2">
                    Нет откликов
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count no">
                    Не отправлено
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count">
                    <span>+2</span> 24 <a href="#">Отклики</a>
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count no2">
                    Нет откликов
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count no">
                    Не отправлено
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count">
                    <span>+2</span> 24 <a href="#">Отклики</a>
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
        <div class="item">
            <div class="main-info">
                <div class="flex">
                    <div class="date">
                        ID 1872 <span>22.12.2020 15:22</span>
                    </div>
                    <div class="views">
                        97
                    </div>
                </div>
                <a href="#" class="name">Возведение статуи бобрам в центре города</a>
                <p>Описание проекта в паре предложений для Исполнителя</p>
            </div>
            <div class="button flex">
                <div class="count no2">
                    Нет откликов
                </div>
                <div>
                    <a href="#" class="trash"></a>
                    <button><span></span> Разослать</button>
                </div>
            </div>
        </div>
    </div><?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/home.blade.php ENDPATH**/ ?>