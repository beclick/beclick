<?php $__env->startSection('title', 'Админка – Beclick'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-3">
        <h3>Пользователи</h3>
        <hr>
        <div class="alert alert-success rounded row text-right">
            <div class="col-auto">
                <strong>Всего: </strong><?php echo e($profiles->count()); ?>

            </div>
            <div class="col-auto">
                <strong>Активных: </strong><?php echo e($profiles->whereNotNull('subscription')->count()); ?>

            </div>
        </div>
        <hr>
        <?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-info rounded row text-right">
                <div class="col-auto">
                    <strong>ID: </strong><?php echo e($profile->id); ?>

                </div>
                <div class="col-auto">
                    <strong>REG: </strong><?php echo e($profile->created_at); ?>

                </div>
                <div class="col">
                    <strong>MAIL: </strong><a
                        href="mailto:<?php echo e($profile->user->email); ?>"><?php echo e($profile->user->email); ?></a>
                </div>
                <div class="col-auto">
                    <a href="<?php echo e(route('admin.home', ['id' => $profile->id])); ?>"><strong>PROFILE</strong></a>
                </div>
                <div class="col-auto">
                    <?php if($profile->advert == 0): ?>
                        <strong class="text-danger">ADVERT</strong>
                    <?php elseif($profile->advert == 1): ?>
                        <strong class="text-success">ADVERT</strong>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/home.blade.php ENDPATH**/ ?>