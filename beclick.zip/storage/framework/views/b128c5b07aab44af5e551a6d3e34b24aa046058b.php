<?php $__env->startSection('title', 'Профиль – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Персональные данные</h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50 p-0">
                <div class="row text-dark m-4">
                    <div class="col-lg">
                        <h5><?php if($my_profile->user_type == 0): ?> <?php echo e($my_profile->title); ?> <?php elseif($my_profile->user_type == 1): ?> <?php echo e('ИП ' . $my_profile->full_name); ?> <?php elseif($my_profile->user_type == 2): ?> <?php echo e('ФЛ ' . $my_profile->full_name); ?> <?php endif; ?></h5>
                    </div>
                    <div class="col-lg-auto">
                        <h5 class="text-info">
                            <?php if($my_profile->user_role == 0): ?>
                                Организатор торгов
                            <?php elseif($my_profile->user_role == 1): ?>
                                Участник торгов
                            <?php endif; ?>
                        </h5>
                    </div>
                </div>
                <div class="list-group list-group-horizontal-lg rounded-0">
                    <a class="list-group-item list-group-item-secondary rounded-0 active" href="#all"
                       data-toggle="tab"><h5>Информация</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#docs" data-toggle="tab"><h5>
                            Документы</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#events" data-toggle="tab"><h5>
                            История</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#sett" data-toggle="tab"><h5>
                            Настройки</h5></a>
                    <a class="col list-group-item rounded-0 text-right text-dark" href="<?php echo e(route('finance')); ?>">
                        <h5>Баланс: <?php echo e(number_format($my_profile->balance / 100, 2, '.', '')); ?> ₽ |
                            Блок: <?php echo e(number_format($my_profile->blocked / 100, 2, '.', '')); ?> ₽
                        </h5>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane fade active show" id="all">
                        <?php if($my_profile->user_type == 0): ?>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Полное название организации:</p>
                                <p class="col"><?php echo e($my_profile->full_title); ?></p>
                            </h5>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Юридический адрес:</p>
                                <p class="col"><?php echo e($my_profile->ur_address); ?></p>
                            </h5>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Фактический адрес:</p>
                                <p class="col"><?php echo e($my_profile->address); ?></p>
                            </h5>
                        <?php else: ?>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">ФИО:</p>
                                <p class="col"><?php echo e($my_profile->full_name); ?></p>
                            </h5>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Паспорт:</p>
                                <p class="col"><?php echo e($my_profile->passport); ?></p>
                            </h5>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Адрес регистрации:</p>
                                <p class="col"><?php echo e($my_profile->address); ?></p>
                            </h5>
                        <?php endif; ?>
                        <h5 class="row">
                            <p class="col-lg-4 text-black-50">ИНН:</p>
                            <p class="col"><?php echo e($my_profile->inn); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-4 text-black-50">Контактный телефон:</p>
                            <p class="col"><?php echo e($my_profile->phone); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-4 text-black-50">Адрес электронной почты:</p>
                            <p class="col"><?php echo e($my_profile->user->email); ?></p>
                        </h5>
                    </div>
                    <div class="tab-pane fade" id="docs">
                        <?php $__currentLoopData = $my_profile->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАНО
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="events">
                        <?php $__currentLoopData = $my_profile->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <?php echo e($event->event); ?>

                                    </div>
                                    <div class="col-auto">
                                        <?php echo e(\Illuminate\Support\Carbon::parse($event->created_at)->format('d.m.Y H:i')); ?>

                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="sett">
                        <h5 class="row">
                            <div class="col-lg-4">
                                <a class="btn btn-block btn-lg btn-outline-info rounded-0"
                                   href="<?php echo e(route('accreditation')); ?>">Редактировать
                                    профиль</a>
                            </div>
                            <div class="col-lg-4">
                                <a class="btn btn-block btn-lg btn-outline-info rounded-0" href="" data-toggle="modal"
                                   data-target="#personal-modal">Сменить пароль</a>
                            </div>
                            <div class="col-lg-4">
                                <a class="btn btn-block btn-lg btn-outline-info rounded-0" href="<?php echo e(route('personal', ['role_change' => $my_profile->id])); ?>">
                                    <?php if($my_profile->user_role == 0): ?>
                                        Зайти как участник торгов
                                    <?php elseif($my_profile->user_role == 1): ?>
                                        Зайти как организатор торгов
                                    <?php endif; ?>
                                </a>
                            </div>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="personal-modal" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content rounded-0">
                <div class="modal-header rounded-0">
                    <h5 class="modal-title">Смена пароля</h5>
                </div>
                <div class="modal-body">
                    <div class="form-group container">
                        <form novalidate method="POST" action="<?php echo e(route('personal')); ?>">
                            <?php echo csrf_field(); ?>
                            <input class="form-control form-control-lg rounded-0" type="password" name="old_pass"
                                   placeholder="Старый пароль" required>
                            <br>
                            <input class="form-control form-control-lg rounded-0" type="password" name="new_pass"
                                   placeholder="Новый пароль" required>
                            <br>
                            <input class="form-control form-control-lg rounded-0" type="password" name="con_pass"
                                   placeholder="Подтвердите пароль" required>
                            <br>
                            <button class="btn btn-success btn-lg btn-block rounded-0">Сменить пароль</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/personal.blade.php ENDPATH**/ ?>