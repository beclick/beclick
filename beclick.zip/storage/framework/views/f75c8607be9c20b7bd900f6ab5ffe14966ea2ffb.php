<?php $__env->startSection('title', 'Аукционы – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Аукционы</h3>
        <hr>
        <div class="row justify-content-between align-items-start">
            <div class="col-lg-3">
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-white text-black-50 text-center pt-4 pb-3">
                        <h5><strong>Сортировка</strong></h5>
                    </div>
                    <div class="card-body">
                        <form novalidate method="get" action="<?php echo e(route('auction')); ?>">
                            <?php if(isset($my_profile) and $my_profile->user_role == 0): ?>
                                <div class="form-group">
                                    <select class="custom-select custom-select-lg rounded-0" name="my_auc">
                                        <option value="null" <?php if($request->my_auc == 'null'): ?> selected <?php endif; ?>>
                                            Все аукционы
                                        </option>
                                        <option value="1" <?php if($request->my_auc == 1): ?> selected <?php endif; ?>>
                                            Мои аукционы
                                        </option>
                                    </select>
                                </div>
                            <?php endif; ?>
                                <div class="form-group">
                                    <select class="custom-select custom-select-lg rounded-0" name="type">
                                        <option value="null">Тип аукциона</option>
                                        <option value="1" <?php if($request->type == 1): ?> selected <?php endif; ?>>
                                            Имущество должников
                                        </option>
                                        <option value="2" <?php if($request->type == 2): ?> selected <?php endif; ?>>
                                            Муниципальное имущество
                                        </option>
                                    </select>
                                </div>
                            <div class="form-group">
                                <select class="custom-select custom-select-lg rounded-0" name="status">
                                    <option value="null">Статус аукциона</option>
                                    <?php if(isset($my_profile) and $my_profile->user_role == 0): ?>
                                        <option value="1" <?php if($request->status == 1): ?> selected <?php endif; ?>>
                                            Не опубликован
                                        </option>
                                    <?php endif; ?>
                                    <option value="2" <?php if($request->status == 2): ?> selected <?php endif; ?>>
                                        Опубликован
                                    </option>
                                    <option value="3" <?php if($request->status == 3): ?> selected <?php endif; ?>>
                                        Идет прием заявок
                                    </option>
                                    <option value="4" <?php if($request->status == 4): ?> selected <?php endif; ?>>
                                        Прием заявок завершен
                                    </option>
                                    <option value="5" <?php if($request->status == 5): ?> selected <?php endif; ?>>
                                        Идут торги
                                    </option>
                                    <option value="6" <?php if($request->status == 6): ?> selected <?php endif; ?>>
                                        Торги состоялись
                                    </option>
                                    <option value="7" <?php if($request->status == 7): ?> selected <?php endif; ?>>
                                        Торги не состоялись
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-block btn-lg btn-primary rounded-0" type="submit">Найти</button>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(route('auction')); ?>" class="btn btn-block btn-lg btn-primary rounded-0">Сбросить</a>
                            </div>
                            <hr>
                            <?php if(isset($my_profile) and $my_profile->user_role == 0): ?>
                                <div class="form-group">
                                    <a href="<?php echo e(route('creation-auction')); ?>"
                                       class="btn btn-block btn-lg btn-success rounded-0">Создать аукцион</a>
                                </div>
                            <?php endif; ?>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg">
                <?php if(!$auctions->isEmpty()): ?>
                    <?php $__currentLoopData = $auctions[$page]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card rounded-0 shadow">
                            <div class="card-header bg-light text-black-50">
                                <h5><strong><a class="card-link text-dark"
                                               href="<?php echo e(route('auction', ['auction' => $auction->id])); ?>"><?php echo e($auction->name); ?></a></strong>
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg">
                                        <h5 class="text-black-50">Номер аукциона</h5>
                                        <h3><a class="card-link text-dark"
                                               href="<?php echo e(route('auction', ['auction' => $auction->id])); ?>"><?php echo e($auction->id); ?></a>
                                        </h3>
                                    </div>
                                    <div class="col-lg">
                                        <h5 class="text-black-50">Начало торгов</h5>
                                        <h3><?php echo e(\Illuminate\Support\Carbon::parse($auction->start_auction)->format('d.m.Y H:i')); ?></h3>
                                    </div>
                                    <div class="col-lg-4">
                                        <?php if($auction->status == 0): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-secondary rounded-0">
                                                Не опубликован
                                            </a>
                                        <?php elseif($auction->status == 1): ?>
                                            <?php if(strtotime(date('Y-m-d H:i:s')) <= strtotime($auction->start_request)): ?>
                                                <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                    Опубликован
                                                </a>
                                            <?php elseif(strtotime($auction->start_request) <= strtotime(date('Y-m-d H:i:s')) and strtotime(date('Y-m-d H:i:s')) < strtotime($auction->end_request)): ?>
                                                <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                    Идёт приём заявок
                                                </a>
                                            <?php elseif(strtotime($auction->start_auction) <= strtotime(date('Y-m-d H:i:s'))): ?>
                                                <a class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                    Идут торги
                                                </a>
                                            <?php elseif(strtotime($auction->start_auction) <= strtotime(date('Y-m-d H:i:s')) + 900): ?>
                                                <a class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                    Торги начнутся
                                                    через <?php echo e(floor((strtotime($auction->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 60) - (floor((strtotime($auction->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600) * 60)); ?>

                                                    минут
                                                </a>
                                            <?php elseif(strtotime($auction->end_request) <= strtotime(date('Y-m-d H:i:s')) and strtotime(date('Y-m-d H:i:s')) < strtotime($auction->start_auction)): ?>
                                                <a class="h-100 btn btn-block btn-lg btn-warning rounded-0">
                                                    Приём заявок завершен
                                                </a>
                                            <?php endif; ?>
                                        <?php elseif($auction->status == 2): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                Торги состоялись
                                            </a>
                                        <?php elseif($auction->status == 3): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">
                                                Торги не состоялись
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <hr>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Тип аукциона:</p>
                                    <p class="col">
                                        <?php if($auction->type == 1): ?> Имущество должников <?php elseif($auction->type == 2): ?> Муниципальное имущество <?php endif; ?>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Дата начала приема заявок:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($auction->start_request)->format('d.m.Y H:i')); ?></p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Дата завершения приема заявок:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($auction->end_request)->format('d.m.Y H:i')); ?></p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Дата начала аукциона:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($auction->start_auction)->format('d.m.Y H:i')); ?></p>
                                </h5>
                            </div>
                        </div>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="row container justify-content-center">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <?php if($page >= 3): ?>
                                <li class="page-item">
                                    <a class="page-link"
                                       href="<?php echo e(route('auction', ['my_auc' => $request->my_auc, 'status' => $request->status, 'page' => $page])); ?>"
                                       aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php for($i = 0; $i < $auctions->count(); $i++): ?>
                                <?php if($i >= $page - 2 and $i <= $page + 2): ?>
                                    <li class="page-item <?php if($page == $i): ?> active <?php endif; ?>"><a
                                            class="page-link"
                                            href="<?php echo e(route('auction', ['my_auc' => $request->my_auc, 'status' => $request->status, 'page' => $i + 1])); ?>"><?php echo e($i + 1); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <?php if($page < $auctions->count() - 2): ?>
                                <li class="page-item">
                                    <a class="page-link"
                                       href="<?php echo e(route('auction', ['my_auc' => $request->my_auc, 'status' => $request->status, 'page' => $page + 2])); ?>"
                                       aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/auctions.blade.php ENDPATH**/ ?>