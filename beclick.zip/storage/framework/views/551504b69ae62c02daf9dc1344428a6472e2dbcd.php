<?php if(isset($types)): ?>
    <br>
    <h5 class="text-success">Типы проектов</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="0">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="get val" request="quest" val="<?php echo e($type->id); ?>"><?php echo e($type->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(isset($quests)): ?>
    <br>
    <h5 class="text-success">вопросы проекта</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt_quest btn btn-block btn-sm btn-secondary" sub="<?php echo e($type); ?>">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $quests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd_quest btn btn-sm btn-secondary">U</a>
                <label class="val" val="<?php echo e($quest->id); ?>" var="<?php echo e($quest->variants); ?>"><?php echo e($quest->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
                <?php if($quest->type_question == 1): ?>
                    <input type="text" class="form-control form-control-sm" value="<?php echo e($quest->variants); ?>" autocomplete="off">
                <?php elseif($quest->type_question == 2): ?>
                    <select autocomplete="off" class="custom-select custom-select-sm">
                        <?php if(isset($quest->variants)): ?>
                            <?php $__currentLoopData = explode('|', $quest->variants); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($variant); ?>"><?php echo e($variant); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                <?php elseif($quest->type_question == 3): ?>
                    <?php if(isset($quest->variants)): ?>
                        <?php $__currentLoopData = explode('|', $quest->variants); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="chss<?php echo e($loop->iteration); ?>">
                                <label class="custom-control-label" for="chss<?php echo e($loop->iteration); ?>"><?php echo e($variant); ?></label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/types.blade.php ENDPATH**/ ?>