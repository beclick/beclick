<?php $__env->startSection('title', 'Тарифы – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
   
   <section class="sign">
   	<section class="sign-container">
  

<div class="container">
	<br>
	<br>
                	<h4 style="margin-bottom: 30px;">Тарифы использование площадки Арестторг.рф</h4>
                <br>



<iframe src="https://docs.google.com/document/d/e/2PACX-1vRl5mHt1c_HgqJMPFIZIlSZyGlh1R1e8a3Gt1Z4hk4VnFyAfh6bqapiRnqrcKAEWO3wufZTqu0b3OGP/pub?embedded=true" style="border:1px #ffffff none;" name="doc" scrolling="yes" frameborder="1" marginheight="0px" marginwidth="0px" height="800px" width="100%" allowfullscreen></iframe>

            </div>

   </section>
   </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/docs/rates.blade.php ENDPATH**/ ?>