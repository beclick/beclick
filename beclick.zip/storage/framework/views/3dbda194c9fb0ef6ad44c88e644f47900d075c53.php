<?php $__env->startSection('title', 'Просмотр аукциона – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Аукцион номер <?php echo e($auction->id); ?></h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50 p-0">
                <div class="row text-dark m-4">
                    <h4><?php echo e($auction->name); ?></h4>
                </div>
                <div class="list-group list-group-horizontal-lg rounded-0">
                    <a class="list-group-item list-group-item-secondary rounded-0 active" href="#all"
                       data-toggle="tab"><h5>Информация аукциона</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#lots" data-toggle="tab"><h5>
                            Лоты аукциона</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#docs" data-toggle="tab"><h5>
                            Документы аукциона</h5></a>
                    <div class="p-0 col list-group-item rounded-0">
                        <?php if($auction->status == 0): ?>
                            <a class="h-100 btn btn-block btn-lg btn-secondary rounded-0">Аукцион не опубликован</a>
                        <?php elseif($auction->status == 1): ?>
                            <a class="h-100 btn btn-block btn-lg btn-success rounded-0">Аукцион опубликован</a>
                        <?php elseif($auction->status == 2): ?>
                            <a class="h-100 btn btn-block btn-lg btn-success rounded-0">Аукцион состоялся</a>
                        <?php elseif($auction->status == 3): ?>
                            <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">Аукцион не состоялся</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane fade active show" id="all">
                        <?php if(isset($my_profile) and $my_profile->id == $auction->profile->id and $my_profile->user_role == 0): ?>
                            <div class="row">
                                <?php if($auction->status == 0): ?>
                                    <div class="col-lg">
                                        <a class="btn btn-block btn-lg btn-success rounded-0"
                                           href="<?php echo e(route('creation-auction', ['public_auction' => $auction->id])); ?>">Опубликовать
                                            аукцион</a>
                                    </div>
                                    <div class="col-lg">
                                        <a class="btn btn-block btn-lg btn-danger rounded-0"
                                           href="<?php echo e(route('creation-auction', ['auction' => $auction->id])); ?>">Редактировать
                                            аукцион</a>
                                    </div>
                                <?php elseif($auction->status == 1 and strtotime($auction->start_request) > strtotime(date('Y-m-d H:i'))): ?>
                                    <div class="col-lg">
                                        <a class="btn btn-block btn-lg btn-danger rounded-0"
                                           href="<?php echo e(route('creation-auction', ['public_auction' => $auction->id])); ?>">Снять
                                            с публикации</a>
                                    </div>
                                <?php elseif($auction->protocol->isEmpty() and $auction->status == 2 ): ?>
                                    <div class="col-lg">
                                        <form method="POST" action="<?php echo e(route('auction')); ?>"
                                              enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input name="auction" value="<?php echo e($auction->id); ?>" hidden>
                                            <button type="button"
                                                    class="ecp_button btn btn-block btn-lg btn-info rounded-0">
                                                Прикрепить протокол и подписать ЭЦП
                                            </button>
                                        </form>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Тип аукциона</p>
                            <p class="col">
                                <?php if($auction->type == 1): ?> Имущество должников <?php elseif($auction->type == 2): ?>
                                    Муниципальное имущество <?php endif; ?>
                            </p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Организатор</p>
                            <p class="col"><?php echo e($auction->organiser); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Основание проведения торгов</p>
                            <p class="col"><?php echo e($auction->base); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Место проведения торгов</p>
                            <p class="col"><?php echo e($auction->place_auc); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Место подведения результатов торгов</p>
                            <p class="col"><?php echo e($auction->place); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Статус торгов</p>
                            <p class="col">
                                <?php if($auction->status == 0): ?>
                                    <strong class="text-black-50">Не активный</strong>
                                <?php elseif($auction->status == 1): ?>
                                    <?php if(strtotime(date('Y-m-d H:i')) <= strtotime($auction->start_request)): ?>
                                        <strong class="text-success">Объявлен</strong>
                                    <?php elseif(strtotime($auction->start_request) <= strtotime(date('Y-m-d H:i')) and strtotime(date('Y-m-d H:i')) < strtotime($auction->end_request)): ?>
                                        <strong class="text-info">Идёт приём заявок</strong>
                                    <?php elseif(strtotime($auction->end_request) <= strtotime(date('Y-m-d H:i')) and strtotime(date('Y-m-d H:i')) < strtotime($auction->start_auction)): ?>
                                        <strong class="text-warning">Приём заявок завершен</strong>
                                    <?php elseif(strtotime($auction->start_auction) <= strtotime(date('Y-m-d H:i'))): ?>
                                        <strong class="text-success">Идут торги</strong>
                                    <?php endif; ?>
                                <?php elseif($auction->status == 2): ?>
                                    <strong class="text-success">Cостоялся</strong>
                                <?php elseif($auction->status == 3): ?>
                                    <strong class="text-danger">Не состоялся</strong>
                                <?php endif; ?>
                            </p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Начало приема заявок</p>
                            <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($auction->start_request)->format('d.m.Y H:i')); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Окончание приема заявок</p>
                            <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($auction->end_request)->format('d.m.Y H:i')); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Начало торгов</p>
                            <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($auction->start_auction)->format('d.m.Y H:i')); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Подведение результатов торгов</p>
                            <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($auction->end_auction)->format('d.m.Y')); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Порядок оформления участия в торгах, перечень
                                представляемых участниками торгов документов и требования к их оформлению</p>
                            <p class="col"><?php echo e($auction->order1); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Cроки и порядок внесения и возврата задатка,
                                реквизиты счетов, на которые вносится задаток</p>
                            <p class="col"><?php echo e($auction->order2); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Определение победителей</p>
                            <p class="col">Участники электронного аукциона подают предложения о
                                цене
                                имущества путем повышения начальной цены продажи имущества, на величину
                                установленного извещением
                                о проведении торгов шага аукциона. Победителем аукциона признается участник,
                                предложивший
                                наиболее высокую ценуза продаваемое имущество.</p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Место, срок и порядок подписания
                                протокола о результатах торгов</p>
                            <p class="col"><?php echo e($auction->order3); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-3 text-black-50">Порядок и срок заключения договора
                                купли-продажи</p>
                            <p class="col"><?php echo e($auction->order4); ?></p>
                        </h5>
                    </div>
                    <div class="tab-pane fade" id="lots">
                        <?php if(isset($my_profile) and $my_profile->user_role == 0 and $auction->status == 0 and $auction->profile_id == $my_profile->id): ?>
                            <a class="btn btn-block btn-lg btn-primary rounded-0"
                               href="<?php echo e(route('creation-lot', ['auction' => $auction->id])); ?>">
                                Создать новый лот
                            </a>
                            <hr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $auction->lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h5><a href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->name); ?></a></h5>
                            <br>
                            <div class="row">
                                <div class="col-lg">
                                    <h5 class="text-black-50">Номер лота</h5>
                                    <h3><?php echo e($lot->num_lot); ?></h3>
                                </div>
                                <br>
                                <div class="col-lg">
                                    <h5 class="text-black-50">Начальная цена</h5>
                                    <h3><?php echo e(number_format($lot->start_price / 100, 2, '.', '')); ?> ₽</h3>
                                </div>
                                <div class="col-lg">
                                    <h5 class="text-black-50">Задаток</h5>
                                    <h3><?php echo e(number_format($lot->deposit_price / 100, 2, '.', '')); ?> ₽</h3>
                                </div>
                                <div class="col-lg">
                                    <?php if($lot->status == 1): ?>
                                        <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?>
                                            <a href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                               class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                Торги по лоту состоялись, посмотреть результаты
                                            </a>
                                        <?php else: ?>
                                            <a class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                Торги по лоту состоялись
                                            </a>
                                        <?php endif; ?>
                                    <?php elseif($lot->status == 2): ?>
                                        <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">
                                            Торги по лоту не состоялись
                                        </a>
                                    <?php elseif($lot->status == 3): ?>
                                        <a class="h-100 btn btn-block btn-lg btn-warning rounded-0">
                                            Приостановлен
                                        </a>
                                    <?php elseif($lot->status == 4): ?>
                                        <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">
                                            Аннулирован
                                        </a>
                                    <?php elseif($lot->auction->status > 0): ?>
                                        <?php if(strtotime(date('Y-m-d H:i:s')) <= strtotime($lot->start_request)): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                Объявлен
                                            </a>
                                        <?php elseif(strtotime($lot->start_request) <= strtotime(date('Y-m-d H:i:s')) and strtotime(date('Y-m-d H:i:s')) < strtotime($lot->end_request)): ?>
                                            <?php if(isset($my_profile) and $my_profile->user_role == 1): ?>
                                                <a href="<?php echo e(route('filing', ['lot' => $lot->id])); ?>"
                                                   class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                    Подать заявку
                                                </a>
                                            <?php else: ?>
                                                <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                    Идёт приём заявок
                                                </a>
                                            <?php endif; ?>
                                        <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s'))): ?>
                                            <a <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                               <?php endif; ?> class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                Идут торги
                                            </a>
                                        <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s')) + 900): ?>
                                            <a <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                               <?php endif; ?> class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                Торги начнутся
                                                через <?php echo e(floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 60) - (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600) * 60)); ?>

                                                минут
                                            </a>
                                        <?php elseif(strtotime($lot->end_request) <= strtotime(date('Y-m-d H:i:s')) and strtotime(date('Y-m-d H:i:s')) < strtotime($lot->start_auction)): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-warning rounded-0">
                                                Приём заявок завершен
                                            </a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="docs">
                        <?php if(isset($my_profile) and $my_profile->user_role == 0 and $auction->profile_id == $my_profile->id): ?>
                            <div class="row">
                                <div class="col-lg">
                                    <form method="POST" action="<?php echo e(route('creation-auction')); ?>"
                                          enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input name="docs_auc" value="<?php echo e($auction->id); ?>" hidden>
                                        <button type="button"
                                                class="ecp_button btn btn-block btn-lg btn-info rounded-0">
                                            Добавить документы
                                        </button>
                                    </form>
                                </div>
                            </div>
                            <hr>
                        <?php endif; ?>
                        <?php $__currentLoopData = $auction->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАН
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $auction->protocol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАН
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.ecp-modal', ['file' => 'true', 'title' => 'Подтверждаю свое согласие на публикацию результатов торгов на ЭТП, согласно регламенту ЭТП.', 'submit' => 'Опубликовать'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/auction.blade.php ENDPATH**/ ?>