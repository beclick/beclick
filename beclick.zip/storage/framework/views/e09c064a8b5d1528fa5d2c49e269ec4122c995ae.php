<?php if(isset($categories)): ?>
    <br>
    <h5 class="text-success">Категории</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="0">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="get val" request="subcat" val="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(isset($subcategories)): ?>
    <br>
    <h5 class="text-success">Подкатегории</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="<?php echo e($category); ?>">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="val" val="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/categories.blade.php ENDPATH**/ ?>