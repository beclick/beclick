<?php $__env->startSection('title', 'Лоты – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Активные торги</h3>
        <hr>
        <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(!$lot->protocol->isEmpty() and isset($my_profile) and $my_profile->user_role == 0): ?>
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-light text-black-50">
                        <h5><strong><a class="card-link text-dark"
                                       href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->name); ?></a></strong>
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg">
                                <h5 class="text-black-50">Номер аукциона</h5>
                                <h3><a class="card-link text-dark"
                                       href="<?php echo e(route('auction', ['auction' => $lot->auction->id])); ?>"><?php echo e($lot->auction->id); ?></a>
                                </h3>
                            </div>
                            <div class="col-lg">
                                <h5 class="text-black-50">Начало торгов</h5>
                                <h3><?php echo e(\Illuminate\Support\Carbon::parse($lot->start_auction)->format('d.m.Y H:i')); ?></h3>
                            </div>
                            <div class="col-lg-4">
                                <?php if(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s'))): ?>
                                    <a <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                       <?php endif; ?> class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                        Идут торги
                                    </a>
                                <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s')) + 900): ?>
                                    <a <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                       <?php endif; ?> class="h-100 btn btn-block btn-lg btn-info rounded-0">
                                        Торги начнутся
                                        через <?php echo e(floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 60) - (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600) * 60)); ?>

                                        минут
                                    </a>
                                <?php else: ?>
                                    <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                        Торги начнутся
                                        через <?php echo e(floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600)  . ' часов ' . (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 60) - (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600) * 60))); ?>

                                        минут
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
            <?php elseif(isset($my_profile) and $my_profile->user_role == 1): ?>
                <?php if(!$lot->protocol->isEmpty() and $lot->filings->where('profile_id', $my_profile->id)->where('status', 1)->count() > 0): ?>
                    <div class="card rounded-0 shadow">
                        <div class="card-header bg-light text-black-50">
                            <h5><strong><a class="card-link text-dark"
                                           href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->name); ?></a></strong>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-lg">
                                    <h5 class="text-black-50">Номер аукциона</h5>
                                    <h3><a class="card-link text-dark"
                                           href="<?php echo e(route('auction', ['auction' => $lot->auction->id])); ?>"><?php echo e($lot->auction->id); ?></a>
                                    </h3>
                                </div>
                                <div class="col-lg">
                                    <h5 class="text-black-50">Начало торгов</h5>
                                    <h3><?php echo e(\Illuminate\Support\Carbon::parse($lot->start_auction)->format('d.m.Y H:i')); ?></h3>
                                </div>
                                <div class="col-lg-4">
                                    <?php if(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s'))): ?>
                                        <a target="_blank"
                                           <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                           <?php endif; ?> class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                            Идут торги
                                        </a>
                                    <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s')) + 900): ?>
                                        <a target="_blank"
                                           <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                           <?php endif; ?> class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                            Торги начнутся
                                            через <?php echo e(floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600)  . ' часов ' . (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 60) - (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600) * 60))); ?>

                                            минут
                                        </a>
                                    <?php else: ?>
                                        <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                            Торги начнутся
                                            через <?php echo e(floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600)  . ' часов ' . (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 60) - (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600) * 60))); ?>

                                            минут
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/bidding.blade.php ENDPATH**/ ?>