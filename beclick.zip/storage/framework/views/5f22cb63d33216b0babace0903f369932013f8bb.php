<?php if(isset($specializations)): ?>
    <br>
    <h5 class="text-success">Специализации</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="0">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="val" val="<?php echo e($specialization->id); ?>"><?php echo e($specialization->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/specializations.blade.php ENDPATH**/ ?>