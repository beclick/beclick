<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>