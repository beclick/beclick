<?php if(isset($regions)): ?>
    <br>
    <h5 class="text-success">Регионы</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="0">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="get val" request="subregion" val="<?php echo e($region->id); ?>"><?php echo e($region->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(isset($subregions)): ?>
    <br>
    <h5 class="text-success">Центры</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="<?php echo e($region); ?>">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $subregions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subregion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="val" val="<?php echo e($subregion->id); ?>"><?php echo e($subregion->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/regions.blade.php ENDPATH**/ ?>