<?php $__env->startSection('title', $project->title); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <a href="<?php echo e(route('projects')); ?>" class="back-mob-link"></a>
        <div class="page-name">
            <div class="navi other">
                <?php echo e($project->title); ?> <i class="fa fa-angle-left"></i> <a
                    href="<?php echo e(route('projects')); ?>"><?php echo e(__('app.project1')); ?></a>
                <i class="fa fa-angle-left"></i> <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.project2')); ?></a>
            </div>
        </div>
        <div class="top-back-link other">
            <a href="<?php echo e(route('projects')); ?>" class="other"><span></span> <?php echo e(__('app.project3')); ?></a>
        </div>
    </div>
    <div class="project-page">
        <div class="top-info">
            <div class="flex">
                <div class="date">
                    ID <?php echo e($project->id); ?>

                    <span><?php echo e(\Illuminate\Support\Carbon::parse($project->created_at)->format('d.m.Y H:i')); ?></span>
                </div>
                <div class="views">
                    <?php echo e($project->views); ?>

                </div>
            </div>
            <div class="flex">
                <div class="info">
                    <div class="name">
                        <?php echo e($project->title); ?>

                    </div>
                    <p><?php echo e($project->text); ?></p>
                    <div class="field-name">
                        <?php echo $project->questions; ?>

                    </div>
                    <div class="button">
                        <?php if($project->status == 0): ?>
                            <a href="<?php echo e(route('requested', ['project' => $project->id])); ?>">
                                <button><span></span> <?php echo e(__('app.project4')); ?></button>
                            </a>
                        <?php endif; ?>
                        <a class="trash edit"
                           href="<?php echo e(route('new_project', ['project' => $project->id])); ?>"><?php echo e(__('app.project5')); ?></a>
                        <?php if($project->status == 0): ?>
                            <a class="trash"
                               href="<?php echo e(route('projects', ['delete' => $project->id])); ?>"><?php echo e(__('app.project6')); ?></a>
                        <?php else: ?>
                            <a class="trash"
                               href="<?php echo e(route('projects', ['return' => $project->id])); ?>"><?php echo e(__('app.project7')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
                <table>
                    <tr>
                        <td><?php echo e(__('app.project8')); ?></td>
                        <td>
                            <?php $__currentLoopData = explode('|', $project->regions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($loop->index > 0): ?>
                                    <p><?php echo e($region); ?></p>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                    </tr>
                    <tr>
                        <?php if(isset($project->profile->address)): ?>
                            <td><?php echo e(__('app.project9')); ?></td>
                            <td><?php echo e($project->profile->address); ?></td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php if(isset($project->profile->contact_phone)): ?>
                            <td><?php echo e(__('app.project10')); ?></td>
                            <td><?php echo e($project->profile->contact_phone); ?></td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php if(isset($project->profile->email)): ?>
                            <td><?php echo e(__('app.email')); ?></td>
                            <td><a href="mailto:<?php echo e($project->profile->email); ?>"><?php echo e($project->profile->email); ?></a></td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php if(isset($project->profile->contact_person)): ?>
                            <td><?php echo e(__('app.project11')); ?></td>
                            <td><?php echo e($project->profile->contact_person); ?></td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php if(isset($project->docs_url)): ?>
                            <td><?php echo e(__('app.project12')); ?></td>
                            <td><a target="_blank" href="<?php echo e($project->docs_url); ?>"><?php echo e(__('app.project13')); ?></a></td>
                        <?php endif; ?>
                    </tr>
                </table>
            </div>
        </div>
        <div class="flex">
            <nav class="menu">
                <span><?php echo e(__('app.project14')); ?></span>
                <ul>
                    <li><a class="a1 active"><?php echo e(__('app.project15')); ?></a></li>
                    <li><a class="a2"><?php echo e(__('app.project16')); ?></a></li>
                    <li><a class="a3"><?php echo e(__('app.project17')); ?></a></li>
                </ul>
            </nav>
            <div class="middle-price">
                <?php echo e(__('app.project18')); ?> <span>$ <?php echo e(number_format($price, 2, '.', '')); ?></span>
            </div>
        </div>
        <div class="list l1 active">
            <?php if(isset($project->responses)): ?>
                <?php $__currentLoopData = $project->responses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="response">
                        <div class="main-info flex">
                            <div class="name">
                                <div>
                                    <a href="<?php echo e(route('company', ['id' => $response->profile->id])); ?>">
                                        <div class="avatar"
                                             style=" <?php if(isset($response->profile->image)): ?> background-image: url(<?php echo e(asset('storage/' . $response->profile->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                                        </div>
                                    </a>
                                </div>
                                <div style="padding-right: 2rem">
                                    <div class="n">
                                        <?php echo e($response->profile->name); ?>

                                    </div>
                                    <p><?php echo $response->text; ?></p>
                                    <div class="links">
                                        <a href=tel:<?php echo e($response->profile->contact_phone); ?>"
                                           class="wa"><?php echo e($response->profile->contact_phone); ?> <?php if(isset($response->profile->contact_phone_d)): ?>
                                                <?php echo e(__('app.items6')); ?> <?php echo e($response->profile->contact_phone_d); ?> <?php endif; ?></a>
                                        <a href="mailto:<?php echo e($response->profile->email); ?>"><?php echo e($response->profile->email); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="date">
                                <p><?php echo e(\Illuminate\Support\Carbon::parse($response->created_at)->format('d.m.Y H:i')); ?></p>
                                <div class="price">
                                    <?php echo e(__('app.project19')); ?>

                                    <span>$<?php echo e($response->price); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="button flex">
                            <div class="but">
                                <?php if($response->status == 0): ?>
                                    <a href="<?php echo e(route('projects', ['select' => $response->id])); ?>">
                                        <button><?php echo e(__('app.project20')); ?></button>
                                    </a>
                                    <a href="<?php echo e(route('projects', ['reject' => $response->id])); ?>"><?php echo e(__('app.project21')); ?></a>
                                <?php elseif($response->status == 1): ?>
                                    <a id="undo"
                                       href="<?php echo e(route('projects', ['reject' => $response->id])); ?>"><?php echo e(__('app.project22')); ?></a>
                                    <?php echo e(__('app.project23')); ?>

                                <?php elseif($response->status == 2): ?>
                                    <button class="active"><span></span> <?php echo e(__('app.project24')); ?></button>
                                    <a id="undo"
                                       href="<?php echo e(route('projects', ['select' => $response->id])); ?>"><?php echo e(__('app.project25')); ?></a>
                                <?php endif; ?>
                            </div>
                            <?php if(isset($response->pdf)): ?>
                                <a data-fancybox="pdf<?php echo e($response->id); ?>"
                                   href="<?php echo e(asset('storage/' . $response->pdf)); ?>"
                                   class="pdf"><?php echo e(__('app.project26')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="list l2">
            <?php if(isset($project->responses)): ?>
                <?php $__currentLoopData = $project->responses->where('status', 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="response">
                        <div class="main-info flex">
                            <div class="name">
                                <div>
                                    <a href="<?php echo e(route('company', ['id' => $response->profile->id])); ?>">
                                        <div class="avatar"
                                             style=" <?php if(isset($response->profile->image)): ?> background-image: url(<?php echo e(asset('storage/' . $response->profile->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                                        </div>
                                    </a>
                                </div>
                                <div style="padding-right: 2rem">
                                    <div class="n">
                                        <?php echo e($response->profile->name); ?>

                                    </div>
                                    <p><?php echo $response->text; ?></p>
                                    <div class="links">
                                        <a href=tel:<?php echo e($response->profile->contact_phone); ?>"
                                           class="wa"><?php echo e($response->profile->contact_phone); ?> <?php if(isset($response->profile->contact_phone_d)): ?>
                                                <?php echo e(__('app.items6')); ?> <?php echo e($response->profile->contact_phone_d); ?> <?php endif; ?></a>
                                        <a href="mailto:<?php echo e($response->profile->email); ?>"><?php echo e($response->profile->email); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="date">
                                <p><?php echo e(\Illuminate\Support\Carbon::parse($response->created_at)->format('d.m.Y H:i')); ?></p>
                                <div class="price">
                                    <?php echo e(__('app.project19')); ?>

                                    <span>$<?php echo e($response->price); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="button flex">
                            <div class="but">
                                <button class="active"><span></span> <?php echo e(__('app.project24')); ?></button>
                                <a id="undo"
                                   href="<?php echo e(route('projects', ['select' => $response->id])); ?>"><?php echo e(__('app.project25')); ?></a>
                            </div>
                            <?php if(isset($response->pdf)): ?>
                                <a data-fancybox="pdf<?php echo e($response->id); ?>"
                                   href="<?php echo e(asset('storage/' . $response->pdf)); ?>"
                                   class="pdf"><?php echo e(__('app.project26')); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
        <div class="list l3">
            <?php if(isset($project->responses)): ?>
                <?php $__currentLoopData = $project->responses->where('status', 1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="response">
                        <div class="main-info flex">
                            <div class="name">
                                <div>
                                    <a href="<?php echo e(route('company', ['id' => $response->profile->id])); ?>">
                                        <div class="avatar"
                                             style=" <?php if(isset($response->profile->image)): ?> background-image: url(<?php echo e(asset('storage/' . $response->profile->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                                        </div>
                                    </a>
                                </div>
                                <div style="padding-right: 2rem">
                                    <div class="n">
                                        <?php echo e($response->profile->name); ?>

                                    </div>
                                    <p><?php echo $response->text; ?></p>
                                    <div class="links">
                                        <a href=tel:<?php echo e($response->profile->contact_phone); ?>"
                                           class="wa"><?php echo e($response->profile->contact_phone); ?> <?php if(isset($response->profile->contact_phone_d)): ?>
                                                <?php echo e(__('app.items6')); ?> <?php echo e($response->profile->contact_phone_d); ?> <?php endif; ?></a>
                                        <a href="mailto:<?php echo e($response->profile->email); ?>"><?php echo e($response->profile->email); ?></a>
                                    </div>
                                </div>
                            </div>
                            <div class="date">
                                <p><?php echo e(\Illuminate\Support\Carbon::parse($response->created_at)->format('d.m.Y H:i')); ?></p>
                                <div class="price">
                                    <?php echo e(__('app.project19')); ?>

                                    <span>$<?php echo e($response->price); ?></span>
                                </div>
                            </div>
                        </div>
                        <div class="button flex">
                            <div class="but">
                                <a id="undo"
                                   href="<?php echo e(route('projects', ['reject' => $response->id])); ?>"><?php echo e(__('app.project22')); ?></a>
                                <?php echo e(__('app.project23')); ?>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/project.blade.php ENDPATH**/ ?>