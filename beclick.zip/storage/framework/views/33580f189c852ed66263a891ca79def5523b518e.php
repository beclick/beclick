<?php $__env->startSection('title', 'Проверка подписи – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Получение и настройка ЭЦП</h3>
        <hr>
        <h5 class="text-danger">Примечание: в данный момент по техническим причинам браузер <strong>Intrnet Explorer
                не поддерживается</strong>, воспользуйтесь одним из рекомендованных браузеров (п 3. Настройка ЭЦП)
        </h5>
        <br>
        <div id="accordion">
            <div class="card rounded-0">
                <div class="card-header" id="headingOne">
                    <h5 class="mb-0">
                        <a href="#" class="nav-link" data-toggle="collapse" data-target="#collapseOne"
                           aria-expanded="true" aria-controls="collapseOne">
                            Получение ЭЦП
                        </a>
                    </h5>
                </div>
                <div id="collapseOne" class="collapse collapsed" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <h5>
                            Внимание! Для регистрации и
                            начала работы
                            в системе необходимо получить средства электронной подписи (ЭЦП) в одном из
                            аккредитованных
                            Удостоверяющих Центров.
                        </h5>
                        <p><b>Для получения ЭЦП через УЦ «Тензор» Вам необходимо пройти по <a
                                    href="https://ca.tensor.ru/petition.html?agent_code=1229#msid=s1458648534972"
                                    class="blue-text" target="_blank">ссылке</a></b></p>
                        <p> Единый бесплатный номер <b>8-800-200-30-15</b></p>
                        <p> УЦ Компании Тензор в настоящее время является лидером в области выдачи ключей для
                            систем
                            электронных торгов и имеет более 350 пунктов выдачи ЭЦП по всей территории РФ, 90 из
                            которых
                            являются филиалами Компании Тензор. </p>
                        <p> Если Вы регистрируетесь как физическое лицо, в поле "название" в анкете укажите ФИО.
                            Другие поля
                            заполняйте, где возможно, либо поставьте прочерк. </p>
                        <p> В течение одного рабочего дня после получения регистрационной анкеты ответственный
                            сотрудник
                            аккредитованного Удостоверяющего Центра свяжется с Вами для выставления счета на ЭЦП
                            и оформления
                            договора. </p>
                        <p> Для изготовления сертификата ключа ЭЦП Заказчик представляет Удостоверяющему
                            центру: </p>
                        <p><b>для юридических лиц:</b></p>
                        <ul class="collection">
                            <li class="collection-item">оригинал или нотариально заверенную копию выписки из
                                ЕГРЮЛ,
                                полученную не позднее чем за месяц до представления;
                            </li>
                            <li class="collection-item">заявление в Удостоверяющий центр по шаблону о выпуске
                                сертификата
                                открытого ключа подписи;
                            </li>
                            <li class="collection-item">паспорт и копию паспорта лица на чье имя изготавливается
                                сертификат
                                ключа подписи (листы с фотографией и пропиской);
                            </li>
                            <li class="collection-item">если ЭЦП получает руководитель организации: нотариально
                                заверенный
                                документ о назначении руководителя;
                            </li>
                            <li class="collection-item">если ЭЦП получает уполномоченный руководителем
                                предприятия
                                представитель: нотариально заверенная Доверенность, подтверждающая полномочия
                                владельца
                                сертификата ключа подписи. Доверенность на полномочного представителя
                                юридического лица на
                                получение сертификата ключа подписи (в случае, если сертификат ключа подписи
                                получает не
                                владелец сертификата, а его полномочный представитель);
                            </li>
                            <li class="collection-item">паспорт и копию паспорта лица прибывшего за получением
                                ЭЦП (листы с
                                фотографией и пропиской).
                            </li>
                        </ul>
                        <p><b>для индивидуальных предпринимателей:</b></p>
                        <ul class="collection">
                            <li class="collection-item">оригинал или нотариально заверенную копию выписки из
                                ЕГРИП,
                                полученную не позднее чем за месяц до представления;
                            </li>
                            <li class="collection-item">заявление в Удостоверяющий центр по шаблону о выпуске
                                сертификата
                                открытого ключа подписи;
                            </li>
                            <li class="collection-item">паспорт и копию паспорта ИП (листы с фотографией и
                                пропиской).
                            </li>
                        </ul>
                        <p><b> для физических лиц: </b></p>
                        <ul class="collection">
                            <li class="collection-item">копию документа, удостоверяющего личность физического
                                лица (листы с
                                фотографией и пропиской);
                            </li>
                            <li class="collection-item">нотариально заверенную копию свидетельства о постановке
                                на учет в
                                налоговом органе физического лица по месту жительства на территории Российской
                                Федерации;
                            </li>
                            <li class="collection-item">заявление в Удостоверяющий центр по шаблону о выпуске
                                сертификата
                                открытого ключа подписи.
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="card rounded-0">
                <div class="card-header" id="headingTwo">
                    <h5 class="mb-0">
                        <a href="#" class="nav-link collapsed" data-toggle="collapse" data-target="#collapseTwo"
                           aria-expanded="false" aria-controls="collapseTwo">
                            Настройка ЭЦП
                        </a>
                    </h5>
                </div>
                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                    <div class="card-body">
                        <p> Для настройки электронной подписи (далее ЭЦП) необходимо: </p><h5
                            class="text-info">1. Установите и настройте СКЗИ «КриптоПро CSP»</h5>
                        <p>1.1 Для применения средств электронной подписи при работе в системе Вам необходимо
                            приобрести
                            программное обеспечение «КриптоПро CSP» для вашей операционной системы.</p>
                        <p>Для покупки, установки и настройки «КриптоПро CSP» Вы можете воспользоваться
                            документацией по
                            установке «КриптоПро CSP», размещенной на <a target="_blank"
                                                                         href="https://www.cryptopro.ru/products/cades/plugin">сайте
                                производителя</a></p>
                        <p>1.3. Установите драйверы для USB токена, скачав их с сайта производителя</p>
                        <p>1.4. Установите необходимые сертификаты удостоверяющего центра, выдавшего вам ЭЦП</p>
                        <h5
                            class="text-info">2. Скачайте и установите КриптоПро ЭЦП Browser Plugin</h5>
                        <p>2.1. Для подписания документов и сведений электронной подписью на ЭТП используется
                            программное
                            обеспечение "КриптоПро ЭЦП Browser Plugin", которое позволяет работать на площадке в
                            любых
                            популярных браузерах (Mozilla Firefox, Chrome, Opera, Internet Explorer 9.0 и
                            выше)</p>
                        <p>2.2. Для настройки компьютера для работы с электронной подписью Вам необходимо будет
                            скачать и
                            установить <a target="_blank"
                                          href="https://www.cryptopro.ru/products/cades/plugin/get_2_0">КриптоПро
                                ЭЦП Browser Plugin</a></p><h5 class="blue-text">3. Настройте браузер</h5>
                        <p><b>MS Internet Explorer (версия 9+)</b> — в настоящее время не поддерживается</p>
                        <p><b>Firefox</b> — скачайте и установите расширение для браузера <a
                                href="http://cryptopro.ru/sites/default/files/products/cades/extensions/firefox_cryptopro_extension_latest.xpi">отсюда</a>
                            и установите его
                            следуя <a
                                href="/instructions/firefox_plugin_install.docx">инструкции</a> (<span
                                class="text-danger">Важно!</span>)
                        </p>
                        <p><b>Google Chrome</b> — установите <a
                                href="https://chrome.google.com/webstore/search/%D0%9A%D1%80%D0%B8%D0%BF%D1%82%D0%BE%20%D0%BF%D1%80%D0%BE?hl=ru">расширение</a>
                        </p>
                        <p><b>Opera</b> и <b>Яндекс Браузер</b> — установите <a
                                href="https://addons.opera.com/ru/extensions/details/cryptopro-extension-for-cades-browser-plug-in/?display=en">расширение</a>
                        </p>
                        <p> Если в произвели все настройки, описанные выше в можете приступить к
                            проверке вашей ЭЦП.<br><br></p>
                    </div>
                </div>
            </div>
            <br>
            <form novalidate method="POST" action="<?php echo e(route('sign')); ?>">
                <?php echo csrf_field(); ?>
                <button type="button" class="ecp_button btn btn-outline-primary btn-lg btn-block rounded-0">
                    Проверить ЭЦП
                </button>
            </form>
        </div>
    </div>

    <?php echo $__env->make('layouts.ecp-modal', ['title' => 'Проверка установленного програмного обеспечения, для работы с ЭЦП, выберете сертификат для подписи и нажмите "Проверить ЭЦП".', 'submit' => 'Проверить ЭЦП'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/auth/sign.blade.php ENDPATH**/ ?>