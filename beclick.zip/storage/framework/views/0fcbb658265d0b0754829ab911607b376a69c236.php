<?php $__env->startSection('title', 'Профиль – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Рассылка</h3>
        <hr>
        <form method="POST" action="{ route('admin.mailer') }}">
            <?php echo csrf_field(); ?>
            <div class="form-row">
                <div class="form-group col-lg">
                    <input class="form-control form-control-lg rounded-0" type="text" name="subject"
                           placeholder="Тема сообщения" required>
                </div>
                <div class="col-lg-auto">
                    <button type="submit" class="btn btn-lg btn-success rounded-0">Отправить
                    </button>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0" name="message"
                              placeholder="Введите текст сообщения"></textarea>
                </div>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/admin/mailer.blade.php ENDPATH**/ ?>