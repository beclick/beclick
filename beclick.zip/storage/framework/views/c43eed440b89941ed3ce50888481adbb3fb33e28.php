<?php if(isset($others)): ?>
    <br>
    <h5 class="text-success">Другое</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="0">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $others; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="get val" request="subother" val="<?php echo e($other->id); ?>"><?php echo e($other->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php elseif(isset($subothers)): ?>
    <br>
    <h5 class="text-success">Разделы</h5>
    <hr>
    <h5>
        <div class="read">
            <a class="crt btn btn-block btn-sm btn-secondary" sub="<?php echo e($other); ?>">Создать</a>
        </div>
    </h5>
    <br>
    <?php $__currentLoopData = $subothers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subother): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h5 class="num">
            <div class="read">
                <a class="del btn btn btn-sm btn-secondary">D</a>
                <a class="upd btn btn-sm btn-secondary">U</a>
                <label class="val" val="<?php echo e($subother->id); ?>"><?php echo e($subother->title); ?></label>
                <a class="iter float-left"><?php echo e($loop->iteration); ?></a>
            </div>
        </h5>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/others.blade.php ENDPATH**/ ?>