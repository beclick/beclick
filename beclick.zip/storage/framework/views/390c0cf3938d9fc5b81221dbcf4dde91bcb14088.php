<?php $__env->startSection('title', 'Технические работы – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="alert alert-light rounded-0 shadow">
            <h3>В данный момент в разделе ведутся технические работы.</h3>
            <h5>Это не займет много времени, спасибо за Ваше понимание</h5>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/errors/500.blade.php ENDPATH**/ ?>