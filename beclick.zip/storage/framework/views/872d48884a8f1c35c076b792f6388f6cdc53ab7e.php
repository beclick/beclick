<?php $__env->startSection('title', 'Вывод средств – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Вывод средств</h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50 p-0">
                <div class="list-group list-group-horizontal-lg rounded-0">
                    <a class="list-group-item list-group-item-secondary rounded-0 active" href="#all"
                       data-toggle="tab"><h5>Активные</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#events" data-toggle="tab"><h5>
                            Выполненные</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#none" data-toggle="tab">
                        <h5>Отказы</h5></a>
                </div>
            </div>
            <div class="tab-content">
                <div class="tab-pane fade active show" id="all">
                    <div class="container-fluid overflow-auto">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Номер заявки</th>
                                <th scope="col">Дата время заявки</th>
                                <th scope="col">Пользователь</th>
                                <th scope="col">ИНН</th>
                                <th scope="col">Реквизиты</th>
                                <th scope="col">Сумма</th>
                                <th scope="col">Действие</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $withd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $with): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($with->status == 0): ?>
                                    <tr>
                                        <th scope="row"><?php echo e($with->id); ?></th>
                                        <td><?php echo e($with->created_at); ?></td>
                                        <td><?php if(isset($with->profile->full_name)): ?> <?php echo e($with->profile->full_name); ?> <?php elseif(isset($with->profile->title)): ?> <?php echo e($with->profile->title); ?> <?php endif; ?></td>
                                        <td><?php if(isset($with->profile->inn)): ?> <?php echo e($with->profile->inn); ?> <?php endif; ?></td>
                                        <td><?php echo e($with->requisites); ?></td>
                                        <td><strong><?php echo e(number_format($with->summ / 100, 2, '.', '')); ?></strong></td>
                                        <td>
                                            <div class="row">
                                                <div class="col">
                                                    <button class="btn btn-block btn-danger rounded-0"
                                                            data-toggle="modal"
                                                            data-target="#god-rej<?php echo e($with->id); ?>">Отклонить
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="col">
                                                    <button class="btn btn-block btn-success rounded-0"
                                                            data-toggle="modal"
                                                            data-target="#god-confirm<?php echo e($with->id); ?>">Подтвердить
                                                    </button>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <div class="modal fade" id="god-rej<?php echo e($with->id); ?>" tabindex="-1" role="dialog">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content rounded-0">
                                                <div class="modal-header rounded-0">
                                                    <h5 class="modal-title">Укажите причину отказа</h5>
                                                </div>
                                                <div class="modal-body">
                                                    <form novalidate method="POST"
                                                          action="<?php echo e(route('admin.withdrawal')); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-group">
                                                            <textarea class="form-control form-control-lg rounded-0"
                                                                      required type="text" name="text"
                                                                      placeholder="Причины для отказа"></textarea>
                                                        </div>
                                                        <input type="hidden" name="withdrawal" value="<?php echo e($with->id); ?>">
                                                        <input type="hidden" name="confirm" value="false">
                                                        <button type="submit"
                                                                class="btn btn-block btn-lg btn-danger rounded-0">
                                                            Отказ
                                                        </button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="modal fade" id="god-confirm<?php echo e($with->id); ?>" tabindex="-1" role="dialog">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                            <div class="modal-content rounded-0">
                                                <div class="modal-header rounded-0">
                                                    <h5 class="modal-title">
                                                        Вывод суммы:
                                                        <strong><?php echo e(number_format($with->summ / 100, 2, '.', '')); ?></strong>
                                                    </h5>
                                                </div>
                                                <div class="modal-footer justify-content-center">
                                                    <a class="btn btn-block btn-lg btn-success rounded-0"
                                                       href="<?php echo e(route('admin.withdrawal', ['withdrawal' => $with->id, 'confirm' => 'true'])); ?>">Вывести</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="tab-pane fade" id="events">
                    <div class="container-fluid overflow-auto">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Номер заявки</th>
                                <th scope="col">Дата время заявки</th>
                                <th scope="col">Пользователь</th>
                                <th scope="col">ИНН</th>
                                <th scope="col">Реквизиты</th>
                                <th scope="col">Сумма</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $withd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $with): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($with->status == 1): ?>
                                    <tr>
                                        <th scope="row"><?php echo e($with->id); ?></th>
                                        <td><?php echo e($with->created_at); ?></td>
                                        <td><?php if(isset($with->profile->full_name)): ?> <?php echo e($with->profile->full_name); ?> <?php elseif(isset($with->profile->title)): ?> <?php echo e($with->profile->title); ?> <?php endif; ?></td>
                                        <td><?php if(isset($with->profile->inn)): ?> <?php echo e($with->profile->inn); ?> <?php endif; ?></td>
                                        <td><?php echo e($with->requisites); ?></td>
                                        <td><strong><?php echo e(number_format($with->summ / 100, 2, '.', '')); ?></strong></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="tab-pane fade" id="none">
                    <div class="container-fluid overflow-auto">
                        <table class="table">
                            <thead>
                            <tr>
                                <th scope="col">Номер заявки</th>
                                <th scope="col">Дата время заявки</th>
                                <th scope="col">Пользователь</th>
                                <th scope="col">ИНН</th>
                                <th scope="col">Реквизиты</th>
                                <th scope="col">Сумма</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $withd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $with): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($with->status == 2): ?>
                                    <tr>
                                        <th scope="row"><?php echo e($with->id); ?></th>
                                        <td><?php echo e($with->created_at); ?></td>
                                        <td><?php if(isset($with->profile->full_name)): ?> <?php echo e($with->profile->full_name); ?> <?php elseif(isset($with->profile->title)): ?> <?php echo e($with->profile->title); ?> <?php endif; ?></td>
                                        <td><?php if(isset($with->profile->inn)): ?> <?php echo e($with->profile->inn); ?> <?php endif; ?></td>
                                        <td><?php echo e($with->requisites); ?></td>
                                        <td><strong><?php echo e(number_format($with->summ / 100, 2, '.', '')); ?></strong></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/admin/withdrawal.blade.php ENDPATH**/ ?>