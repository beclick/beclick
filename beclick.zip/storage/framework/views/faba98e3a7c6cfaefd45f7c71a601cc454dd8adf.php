<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link href="<?php echo e(asset('style.css') . '?' . rand(0, 99999)); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
</head>
<body class="lp">
<div class="login-page">
    <div class="content">
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="logo">
                <img src="<?php echo e(asset('img/logo.svg')); ?>">
            </div>
            <div class="top-text">
                <?php echo e(__('auth.create_account')); ?>

            </div>
            <div class="field-name">
                <?php echo e(__('auth.user_name')); ?>

            </div>
            <input type="text" placeholder="<?php echo e(__('auth.enter_nicname')); ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name"
                   autofocus>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="field-name">
                <?php echo e(__('app.email')); ?>

            </div>
            <input class="ltr" type="text" placeholder="<?php echo e(__('auth.enter_email')); ?>" name="email"
                   value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="field-name">
                <?php echo e(__('auth.password')); ?>

            </div>
            <div class="pass">
                <a class="show-pass"></a>
                <input class="ltr" type="password" placeholder="<?php echo e(__('auth.enter_password')); ?>" name="password" required
                       autocomplete="current-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="pass">
                <a class="show-pass"></a>
                <input class="ltr" type="password" placeholder="<?php echo e(__('auth.confirm_password')); ?>" name="password_confirmation" required autocomplete="new-password">
            </div>
            <div class="agree">
                <input type="checkbox" class="checkbox" id="agree"><label for="agree"><?php echo e(__('auth.i_agree_with')); ?> <a href="#"><?php echo e(__('auth.service_rules_and_privacy_policy')); ?></a></label>
            </div>
            <button type="submit"><?php echo e(__('auth.register_now')); ?></button>
            <div class="or">
                <?php echo e(__('auth.or')); ?>

            </div>
            <a href="#" class="google-login">
                <img src="img/google.png"> <?php echo e(__('auth.login_with_google')); ?>

            </a>
        </form>
    </div>
    <div class="bottom-block">
        <?php echo e(__('auth.already_registered')); ?> <a href="<?php echo e(route('login')); ?>"><?php echo e(__('auth.login')); ?></a>
    </div>
    <div class="copy">
        <p><?php echo e(__('app.all_rights_reserved')); ?></p>
        <a href="#"><?php echo e(__('app.privacy_policy')); ?></a>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/auth/register.blade.php ENDPATH**/ ?>