<?php echo e($slot); ?>

<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>