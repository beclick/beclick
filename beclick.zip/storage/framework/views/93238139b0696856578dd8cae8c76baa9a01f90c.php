<?php $__env->startSection('title', 'Регламент – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>

    <section class="sign-container">
        <div class="container">
            <br>
            <br>
            <div class="layout_ik">
                <style type="text/css">
                    .req_ik > tbody > tr {
                        border-top: 1px solid #d7d7d7;
                    }
                    .req_ik > tbody > tr > td {
                        padding: 5px 0px 5px 0px;
                    }
                </style>
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        <h1>Регламент сервиса</h1>
                        <iframe
                            src="https://docs.google.com/document/d/e/2PACX-1vQUM9t3jsDHj2ltSzwvnXDyI8OpKNFOhl2_MigtWWgO0IDO6D_UIxIpUSS7foatraXGIdi-3aJMjYl-/pub?embedded=true"
                            style="border:1px #ffffff none;" name="doc" scrolling="yes" frameborder="1"
                            marginheight="0px" marginwidth="0px" height="800px" width="100%" allowfullscreen></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\beclick\resources\views/docs/regulations.blade.php ENDPATH**/ ?>