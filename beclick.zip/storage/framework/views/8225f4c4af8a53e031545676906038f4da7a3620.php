<?php $__env->startSection('title', 'Контакты – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>

    <section class="sign-container">
        <div class="container">
            <br>
            <br>
            <h1>Контакты</h1>
            <div class="container">
                <div class="row">
                    <div class="col s12"><p><b> Оператором электронной торговой площадки является компания ООО
                                «АРЕСТТОРГ» </b></p>
                        <p><i class="mdi mdi-map-marker fs22 blue-text"></i> Юридический адрес: г. Ставрополь, проезд
                            Гайдара, дом 21 <br>Фактический адрес: г. Ставрополь, 50 лет ВЛКСМ 16 И</p>
                        <p><i class="mdi mdi-map-marker fs22 blue-text"></i></p>
                        <p><b>Реквизиты</b></p>
                        <ul class="collection">
                            <li>Расчётный счёт: 40702810060100019313</li>
                            <li>Банк: СТАВРОПОЛЬСКОЕ ОТДЕЛЕНИЕ N5230 ПАО СБЕРБАНК</li>
                            <li>БИК: 040702615</li>
                            <li>Кор. Cчёт: 30101810907020000615</li>
                            <li>ОГРН: 1202600004683</li>
                            <li>ИНН: 2635245279</li>
                            <li>КПП: 263501001</li>
                            <li>Телефон: +7-906-497-08-70</li>
                        </ul>

                        <p><b>Дополнительные реквизиты</b></p>
                        <ul class="collection">
                            <li>Расчётный счёт: 40702810810000690305</li>
                            <li>Банк: АО "ТИНЬКОФФ БАНК"</li>
                            <li>БИК: 044525974</li>
                            <li>Кор. Cчёт: 30101810145250000974</li>
                            <li>ОГРН: 1202600004683</li>
                            <li>ИНН: 2635245279</li>
                            <li>КПП: 263501001</li>
                        </ul>

                        По вопросам сотрудничества:
                        <p>E-mail: support@арестторг.рф </p></div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/docs/contacts.blade.php ENDPATH**/ ?>