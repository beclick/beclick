<?php $__env->startSection('title', 'Профиль - beclick'); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                <?php if(isset($request->category) and isset($request->subcategory)): ?>
                    <a href="<?php echo e(route('find', ['category' => $request->category, 'subcategory' => $request->subcategory])); ?>"><?php echo e($all_categories[$request->category]->where('id', $request->subcategory)->first()->title); ?></a>
                    <i class="fa fa-angle-left"></i>
                <?php endif; ?>
                <?php if(isset($request->category)): ?>
                    <a href="<?php echo e(route('find', ['category' => $request->category])); ?>"><?php echo e($all_categories[0]->where('id', $request->category)->first()->title); ?></a>
                    <i class="fa fa-angle-left"></i>
                <?php endif; ?>
                <a href="<?php echo e(route('find')); ?>">Компании</a>
                <i class="fa fa-angle-left"></i>
                <a href="<?php echo e(route('home')); ?>">Главная</a>
            </div>
            <h1>Найти исполнителя</h1>
        </div>
    </div>
    <div class="profile-page">
        <div class="content c2 other2 active">
            <div class="flex">
                <div class="list">
                    <div class="flex">
                        <button type="button" class="send-btn top-button big send_btn"><span></span> Отправить запрос
                            выбранным
                        </button>
                        <div class="selected">
                            Выбрано: <span></span>
                            <a id="all_check">Выбрать все компании в категории</a>
                        </div>
                    </div>
                    <div class="search">
                        <div class="flex">
                            <p>Выслать приглашение по e-mail</p>
                        </div>
                        <input type="text" name="mails" placeholder="E-mail исполнителей через запятую">
                        <button type="button" id="mails"></button>
                    </div>
                    <form id="send_form">
                        <div id="result" class="flex2 comp">
                            <?php echo $__env->make('layouts.items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </form>
                </div>
                <div class="filter">
                    <div class="name main">
                        <img src="<?php echo e(asset('img/name12.svg')); ?>"> Фильтр компаний
                    </div>
                    <div class="block">
                        <select id="category" name="category" autocomplete="off">
                            <?php if(!isset($profile->category_id)): ?>
                                <option value="null">Не выбрано</option>
                            <?php endif; ?>
                            <?php if(isset($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                            <?php if(isset($request->category) and $request->category == $category->id): ?> selected <?php endif; ?>><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <select id="subcategory" name="subcategory" autocomplete="off">
                            <option value="null">Не выбрано</option>
                        </select>
                        <select id="specialization" name="specialization" autocomplete="off">
                            <?php if(!isset($profile->specialization_id)): ?>
                                <option value="null">Не выбрано</option>
                            <?php endif; ?>
                            <?php if(isset($specializations)): ?>
                                <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($specialization->id); ?>"
                                            <?php if(isset($request->specialization) and $request->specialization == $specialization->id): ?> selected <?php endif; ?>><?php echo e($specialization->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <div class="result">
                            <p>Результатов поиска: <span id="count"></span></p>
                            <a id="clear">Очистить фильтр</a>
                        </div>
                        <div class="no_mob">
                            <div class="name">
                                Рекомендуем
                            </div>
                            <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="filter mob">
                    <button class="top-button big send_btn"><span></span> Отправить запрос выбранным</button>
                    <div class="line"></div>
                    <div class="name">
                        Рекомендуем
                    </div>
                    <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            function get_sub(val) {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?get_sub=" + val,
                }).done(function (data) {
                    $('#subcategory').html(data);
                    $('#subcategory').children('option').prop('selected', false);
                    $('#subcategory').children('option').first().prop('selected', true);
                    get_count();
                });
            }

            <?php if(isset($request->category)): ?>
            get_sub(<?php echo e($request->category); ?>);
            <?php endif; ?>
            $('#category').change(function () {
                get_sub($(this).val());
            });

            var res;

            function get_count(clear) {
                var cat = $('#category').val(),
                    subcat = $('#subcategory').val(),
                    spec = $('#specialization').val();
                if (clear == 'clear') {
                    cat = 'null';
                    subcat = 'null';
                    spec = 'null';
                }
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?cat=" + cat + "&subcat=" + subcat + "&spec=" + spec,
                }).done(function (data) {
                    $('#count').html(`
                        ${data[0]}<a id="view"> показать</a>
                    `);
                    res = data[1];
                });
            }

            $('#count').on('click', '#view', function () {
                $('#result').empty().append(res);
            });

            $('.filter').find('select').change(function () {
                get_count();
            });

            $('#clear').click(function () {
                $('.filter').find('select').children('option').prop('selected', false);
                get_count('clear');
            });

            $('#mails').click(function () {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?mails=" + $(this).prev('input').val(),
                }).done(function (data) {
                    $('.popup.alrt').fadeIn().find('p').text(data);
                });
            });

            $('.send_btn').click(function () {
                document.location.href = '<?php echo e(route('requested')); ?>?' + $('#send_form').serialize();
            });

            $('#result').on('click', '.only_send', function () {
                document.location.href = '<?php echo e(route('requested')); ?>?company[]=' + $(this).siblings('.checkbox').val();
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/find.blade.php ENDPATH**/ ?>