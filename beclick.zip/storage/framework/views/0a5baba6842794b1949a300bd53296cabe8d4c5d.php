<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-lg-5">
            <div class="card rounded-0 shadow">
                <div class="card-header bg-light text-black-50 text-center">
                    <h4>Заявка на регистрацию в системе подана, подтвердите вашу почту</h4>
                </div>
                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success rounded-0" role="alert">
                            На вашу почту отправлено письмо для подтверждения регистрации. Перейдите по ссылке из письма.
                            Ссылка действительна в течении часа с момента получения письма.
                        </div>
                    <?php endif; ?>
                    После того, как вы подтвердите свой email, пройдите аккредитацию и ожидайте рассмотрения вашей заявки в течении 3 дней. При успешном рассмотрении вы получите уведомление на почту.
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success btn-lg btn-block rounded-0">Для повторной отправки письма нажмите сюда</button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/auth/verify.blade.php ENDPATH**/ ?>