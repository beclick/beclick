<?php if(isset($company)): ?>
    <?php $__env->startSection('title', $profile->name); ?>
<?php else: ?>
    <?php $__env->startSection('title', __('app.prof_title')); ?>
<?php endif; ?>


<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                <?php if(isset($company)): ?>
                    <a href="<?php echo e(route('company', ['id' => $profile->id])); ?>"><?php echo e($profile->name); ?></a>
                    <i class="fa fa-angle-left"></i>
                    <?php if(isset($profile->category) and isset($profile->subcategory)): ?>
                        <a href="<?php echo e(route('find', ['category' => $profile->category_id, 'subcategory' => $profile->subcategory_id])); ?>"><?php echo e($all_categories[$profile->category_id]->where('id', $profile->subcategory_id)->first()->title); ?></a>
                        <i class="fa fa-angle-left"></i>
                    <?php endif; ?>
                    <?php if(isset($profile->category)): ?>
                        <a href="<?php echo e(route('find', ['category' => $profile->category_id])); ?>"><?php echo e($all_categories[0]->where('id', $profile->category_id)->first()->title); ?></a>
                        <i class="fa fa-angle-left"></i>
                    <?php endif; ?>
                    <a href="<?php echo e(route('find')); ?>"><?php echo e(__('app.prof1')); ?></a>
                    <i class="fa fa-angle-left"></i>
                    <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.prof2')); ?></a>
                <?php else: ?>
                    <a href=""><?php echo e(__('app.prof_title')); ?></a><i class="fa fa-angle-left"></i> <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.prof2')); ?></a>
                <?php endif; ?>
            </div>
            <div class="company">
                <div class="avatar"
                     style="width: 10rem; height: 10rem; <?php if(isset($profile->image)): ?> background-image: url(<?php echo e(asset('storage/' . $profile->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                </div>
                <div style="padding-right: 3rem">
                    <h1><?php if(isset($profile->name)): ?> <?php echo e($profile->name); ?> <?php endif; ?></h1>
                    <div class="links">
                        <a onclick="copytext('<?php echo e(route('company', ['id' => $profile->id])); ?>'); this.innerText = '<?php echo e(__('app.prof6')); ?>'"><?php echo e(__('app.prof3')); ?></a>
                        <?php if(isset($company)): ?>
                            <a class="favorite"><?php echo e(__('app.prof4')); ?></a>
                            <a class="comp"><?php echo e(__('app.prof5')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php if(empty($company)): ?>
            <div class="subscribe-block">
                <?php if(isset($profile->subscription) and $subscription == true): ?>
                    <div class="date">
                        <?php echo e(__('app.prof7')); ?>

                        <span><?php echo e(\Illuminate\Support\Carbon::parse($profile->subscription)->format('d.m.Y H:i')); ?></span>
                    </div>
                    <a href="<?php echo e(route('payment')); ?>">
                        <button><span></span> <?php echo e(__('app.prof8')); ?></button>
                    </a>
                <?php elseif($subscription == true): ?>
                    <button><span></span> <?php echo e(__('app.prof9')); ?></button>
                <?php else: ?>
                    <a href="<?php echo e(route('payment')); ?>">
                        <button><span></span> <?php echo e(__('app.prof10')); ?></button>
                    </a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="company-mob-block">
        <div class="links">
            <a onclick="copytext('<?php echo e(route('company', ['id' => $profile->id])); ?>')"></a>
            <?php if(isset($company)): ?>
                <a class="favorite"></a>
                <a class="comp"></a>
            <?php endif; ?>
        </div>
        <?php if(isset($profile->pdf)): ?>
            <div class="pdf">
                <div><img src="<?php echo e(asset('img/pdf2.svg')); ?>"></div>
                <div><a data-fancybox="profile2" href="<?php echo e(asset('storage/' . $profile->pdf)); ?>"><?php echo e(__('app.prof11')); ?></a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="company-page flex">
        <div class="info">
            <div class="name">
                <img src="<?php echo e(asset('img/name8.svg')); ?>"> <?php echo e(__('app.prof12')); ?>

            </div>
            <div class="block">
                <div class="flex">
                    <div class="col">
                        <div class="item">
                            <?php if(isset($profile->contact_phone)): ?>
                                <?php echo e(__('app.prof13')); ?>

                                <span><?php echo e($profile->contact_phone); ?> <?php if(isset($profile->contact_phone_d)): ?>
                                        <?php echo e(__('app.items6')); ?> <?php echo e($profile->contact_phone_d); ?> <?php endif; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->phone_whatsapp)): ?>
                                <?php echo e(__('app.prof14')); ?>

                                <span><a class="wa" href=""><?php echo e($profile->phone_whatsapp); ?></a></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->telegram)): ?>
                                <?php echo e(__('app.prof15')); ?>

                                <span><?php echo e($profile->telegram); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->viber)): ?>
                                <?php echo e(__('app.prof16')); ?>

                                <span><?php echo e($profile->viber); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col">
                        <div class="item">
                            <?php if(isset($profile->address)): ?>
                                <?php echo e(__('app.prof17')); ?>

                                <span><?php echo e($profile->address); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->email)): ?>
                                <?php echo e(__('app.prof18')); ?>

                                <span><a href="mailto:<?php echo e($profile->email); ?>"><?php echo e($profile->email); ?></a></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->contact_person)): ?>
                                <?php echo e(__('app.prof19')); ?>

                                <span><?php echo e($profile->contact_person); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->regions)): ?>
                                <?php echo e(__('app.prof20')); ?>

                                <span>
                                    <?php $__currentLoopData = explode('|', $profile->regions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->index > 0): ?>
                                            <p><?php echo e($region); ?></p>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="line"></div>
            <div class="name">
                <img src="<?php echo e(asset('img/name1.svg')); ?>"> <?php echo e(__('app.prof21')); ?>

            </div>
            <div class="block">
                <div class="item">
                    <?php if(isset($profile->category)): ?>
                        <?php echo e(__('app.prof22')); ?>

                        <span><?php echo e($profile->category->title); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->subcategory)): ?>
                        <?php echo e(__('app.prof23')); ?>

                        <span><?php echo e($profile->subcategory->title); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->specialization) or isset($profile->specialization_list)): ?>
                        <?php echo e(__('app.prof24')); ?>

                    <?php endif; ?>
                    <?php if(isset($profile->specialization)): ?>
                        <span><?php echo e($profile->specialization->title); ?></span>
                    <?php endif; ?>
                    <?php if(isset($profile->specialization_list)): ?>
                        <span><?php echo e($profile->specialization_list); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <div class="name">
                <img src="<?php echo e(asset('img/name1.svg')); ?>"> <?php echo e(__('app.prof25')); ?>

            </div>
            <div class="block">
                <div class="item">
                    <?php if(isset($profile->description)): ?>
                        <?php echo e(__('app.prof26')); ?>

                        <span><?php echo e($profile->description); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->site)): ?>
                        <?php echo e(__('app.prof27')); ?>

                        <span><a href="<?php echo e($profile->site); ?>"><?php echo e($profile->site); ?></a></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->experience)): ?>
                        <?php echo e(__('app.prof28')); ?>

                        <span><?php echo e($profile->experience); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->amountworkers)): ?>
                        <?php echo e(__('app.prof29')); ?>

                        <span><?php echo e($profile->amountworkers); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <?php if(isset($profile->others)): ?>
                <?php $__currentLoopData = explode('<>', $profile->others); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $others): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index > 0 and isset($others)): ?>
                        <div class="name">
                            <img src="<?php echo e(asset('img/name4.svg')); ?>"><?php echo e(explode('|', $others)[0]); ?>

                        </div>
                        <div class="block">
                            <ul class="docs">
                                <?php if(isset($others)): ?>
                                    <?php $__currentLoopData = explode('|', $others); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->index > 0): ?>
                                            <li><?php echo e($other); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="line"></div>
            <?php endif; ?>
            <div class="name">
                <img src="<?php echo e(asset('img/name5.svg')); ?>"> <?php echo e(__('app.prof30')); ?>

            </div>
            <div class="block">
                <div class="hours">
                    <?php if($profile->mode_alw == 1): ?>
                        <p> <?php echo e(__('app.prof31')); ?> </p>
                    <?php else: ?>
                        <p>
                            <?php if(isset($profile->mode_week)): ?>
                                <?php echo e(__('app.prof32')); ?> <?php echo e(explode('|', $profile->mode_week)[0]); ?>

                                <?php echo e(__('app.prof33')); ?> <?php echo e(explode('|', $profile->mode_week)[1]); ?>

                            <?php endif; ?>
                        </p>
                        <p>
                            <?php if(isset($profile->mode_sat)): ?>
                                <?php echo e(__('app.prof34')); ?> <?php echo e(explode('|', $profile->mode_sat)[0]); ?>

                                <?php echo e(__('app.prof33')); ?> <?php echo e(explode('|', $profile->mode_sat)[1]); ?>

                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                    <?php if($profile->shabat == 1): ?>
                        <p><?php echo e(__('app.prof35')); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <div class="name">
                <img src="<?php echo e(asset('img/name7.svg')); ?>"> <?php echo e(__('app.prof36')); ?>

            </div>
            <div class="block">
                <div class="gallery">
                    <?php $__currentLoopData = $profile->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <img src="<?php echo e(asset('storage/' . $image->path)); ?>">
                            <a data-caption="<?php echo e($image->file_name); ?>" data-fancybox="gallery"
                               href="<?php echo e(asset('storage/' . $image->path)); ?>"></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="info2">
            <div class="name">
                <img src="<?php echo e(asset('img/name9.svg')); ?>"> <?php echo e(__('app.prof37')); ?>

            </div>
            <div class="block">
                <div class="item">
                    <?php echo e(__('app.prof38')); ?>

                    <span><?php echo e(\Illuminate\Support\Carbon::parse($profile->created_at)->format('d.m.Y')); ?></span>
                </div>
                <div class="item">
                    <?php echo e(__('app.prof39')); ?>

                    <span><?php echo e($profile->num_proj); ?></span>
                </div>
                <div class="item">
                    <?php echo e(__('app.prof40')); ?>

                    <span><?php echo e($profile->views); ?></span>
                </div>
                <div class="item">
                    <?php echo e(__('app.prof41')); ?>

                    <?php if($profile->resp_time / $profile->resp_num < 60): ?>
                        <span>~<?php echo e(round($profile->resp_time / $profile->resp_num)); ?> <?php echo e(__('app.items3')); ?></span>
                    <?php elseif($profile->resp_time / $profile->resp_num < 1440): ?>
                        <span>~<?php echo e(round($profile->resp_time / $profile->resp_num / 60)); ?> <?php echo e(__('app.items4')); ?></span>
                    <?php elseif($profile->resp_time / $profile->resp_num < 10080): ?>
                        <span>~<?php echo e(round($profile->resp_time / $profile->resp_num / 1440)); ?> <?php echo e(__('app.items5')); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <?php if(isset($profile->pdf)): ?>
                <div class="pdf">
                    <div><img src="<?php echo e(asset('img/pdf2.svg')); ?>"></div>
                    <div><a data-fancybox="profile1" href="<?php echo e(asset('storage/' . $profile->pdf)); ?>"><?php echo e(__('app.prof11')); ?></a>
                    </div>
                </div>
                <div class="line"></div>
            <?php endif; ?>
            <div class="name">
                <img src="<?php echo e(asset('img/name6.svg')); ?>"> <?php echo e(__('app.prof42')); ?>

            </div>
            <div class="block">
                <div class="reviews flex2">
                    <?php $__currentLoopData = $profile->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <img src="<?php echo e(asset('img/review.png')); ?>">
                            <a data-caption="<?php echo e($review->file_name); ?>" data-fancybox="reviews"
                               href="<?php echo e(asset('storage/' . $review->path)); ?>"></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>

    <?php if(isset($company)): ?>
        <div class="popup complaint">
            <div class="window">
                <a class="close"></a>
                <p><?php echo e(__('app.prof43')); ?></p>
                <div class="field-name">
                    <?php echo e(__('app.prof44')); ?>

                </div>
                <textarea id="text" placeholder="Введите причину"></textarea>
                <button id="send_comp"><?php echo e(__('app.prof45')); ?></button>
            </div>
        </div>

        <script>
            $(document).ready(function () {
                $('.comp').click(function () {
                    $('.popup.complaint').fadeIn();
                });
                $('#send_comp').click(function () {
                    $.ajax({
                        url: "<?php echo e(route('resource')); ?>?complaint=<?php echo e($profile->id); ?>" + '&text=' + $(this).siblings('#text').val(),
                    }).done(function (data) {
                        $('.popup.complaint').find('.close').click();
                        show_alert(data);
                    });
                });

                function favorite(val) {
                    $.ajax({
                        url: "<?php echo e(route('resource')); ?>?favorite=" + val,
                    }).done(function (data) {
                        show_alert(data);
                    });
                }

                $('.favorite').click(function () {
                    favorite(<?php echo e($profile->id); ?>);
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/profile.blade.php ENDPATH**/ ?>