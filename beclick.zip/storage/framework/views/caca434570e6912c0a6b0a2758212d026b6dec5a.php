<?php $__env->startSection('title', 'Уведомления – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Уведомления</h3>
        <hr>
        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row">
                <div class="col">
                    <div class="alert alert-info rounded-0">
                        <strong><?php echo e(\Illuminate\Support\Carbon::parse($message->created_at)->format('d.m.Y H:i')); ?> <?php echo $message->message; ?></strong>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/message.blade.php ENDPATH**/ ?>