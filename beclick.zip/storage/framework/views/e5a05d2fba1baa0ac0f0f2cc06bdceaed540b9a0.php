<?php $__env->startSection('title', 'Профиль – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Персональные данные</h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50 p-0">
                <div class="row text-dark m-4">
                    <div class="col-lg">
                        <h5><?php if($profile->user_type == 0): ?> <?php echo e($profile->title); ?> <?php elseif($profile->user_type == 1): ?> <?php echo e('ИП ' . $profile->full_name); ?> <?php elseif($profile->user_type == 2): ?> <?php echo e('ФЛ ' . $profile->full_name); ?> <?php endif; ?></h5>
                    </div>
                    <div class="col-lg-auto">
                        <h5 class="text-info">
                            <?php if($profile->user_role == 0): ?>
                                Организатор торгов
                            <?php elseif($profile->user_role == 1): ?>
                                Участник торгов
                            <?php endif; ?>
                        </h5>
                    </div>
                </div>
                <div class="list-group list-group-horizontal-lg rounded-0">
                    <a class="list-group-item list-group-item-secondary rounded-0 active" href="#all"
                       data-toggle="tab"><h5>Информация</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#docs" data-toggle="tab"><h5>
                            Документы</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#messages" data-toggle="tab">
                        <h5>
                            Сообщения</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#finance" data-toggle="tab">
                        <h5>
                            Финансы</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#events" data-toggle="tab"><h5>
                            История</h5></a>
                    <a class="col list-group-item rounded-0 text-right text-dark" href="<?php echo e(route('finance')); ?>">
                        <h5>Баланс: <?php echo e(number_format($profile->balance / 100, 2, '.', '')); ?> ₽ |
                            Блок: <?php echo e(number_format($profile->blocked / 100, 2, '.', '')); ?> ₽
                        </h5>
                    </a>
                </div>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane fade active show" id="all">
                        <?php if($profile->user_type == 0): ?>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Полное название организации:</p>
                                <p class="col"><?php echo e($profile->full_title); ?></p>
                            </h5>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Юридический адрес:</p>
                                <p class="col"><?php echo e($profile->ur_address); ?></p>
                            </h5>
                        <?php else: ?>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">ФИО:</p>
                                <p class="col"><?php echo e($profile->full_name); ?></p>
                            </h5>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Паспорт:</p>
                                <p class="col"><?php echo e($profile->passport); ?></p>
                            </h5>
                        <?php endif; ?>
                        <h5 class="row">
                            <p class="col-lg-4 text-black-50">Фактический адрес:</p>
                            <p class="col"><?php echo e($profile->address); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-4 text-black-50">ИНН:</p>
                            <p class="col"><?php echo e($profile->inn); ?></p>
                        </h5>
                        <h5 class="row">
                            <p class="col-lg-4 text-black-50">Контактный телефон:</p>
                            <p class="col"><?php echo e($profile->phone); ?></p>
                        </h5>
                        <?php if(isset($profile->email)): ?>
                            <h5 class="row">
                                <p class="col-lg-4 text-black-50">Адрес электронной почты:</p>
                                <p class="col"><?php echo e($profile->email); ?></p>
                            </h5>
                        <?php endif; ?>
                    </div>
                    <div class="tab-pane fade" id="docs">
                        <?php $__currentLoopData = $profile->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАНО
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="messages">
                        <form method="POST" action="<?php echo e(route('admin.home')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="profile" value="<?php echo e($profile->id); ?>">
                            <div class="form-row">
                                <div class="form-group col-lg">
                                    <input class="form-control form-control-lg rounded-0" type="text" name="subject"
                                           placeholder="Тема сообщения" required>
                                </div>
                                <div class="col-lg-auto">
                                    <button type="submit" class="btn btn-lg btn-success rounded-0">Отправить
                                    </button>
                                </div>
                            </div>
                            <div class="form-row">
                                <div class="form-group col">
                                    <textarea class="form-control form-control-lg rounded-0" name="message"
                                              placeholder="Введите текст сообщения"></textarea>
                                </div>
                            </div>
                        </form>
                        <hr>
                        <?php $__currentLoopData = $profile->message->sortDesc(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row">
                                <div class="col">
                                    <div class="alert alert-info rounded-0">
                                        <strong><?php echo e(\Illuminate\Support\Carbon::parse($message->created_at)->format('d.m.Y H:i')); ?> <?php echo $message->message; ?></strong>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="tab-pane fade" id="finance">
                        <form novalidate method="POST" action="<?php echo e(route('admin.balance')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($profile->id); ?>">
                            <div class="form-row">
                                <div class="form-group col-lg">
                                    <input type="text" name="balance" class="form-control form-control-lg rounded-0"
                                           required placeholder="Введите сумму">
                                </div>
                                <div class="col-lg-auto">
                                    <button type="submit" class="btn btn-lg btn-success rounded-0">Задать баланс
                                    </button>
                                </div>
                            </div>
                        </form>
                        <div class="container-fluid overflow-auto">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="border-0 text-uppercase small font-weight-bold">Дата время</th>
                                    <th class="border-0 text-uppercase small font-weight-bold">Сумма</th>
                                    <th class="border-0 text-uppercase small font-weight-bold">Действие</th>
                                    <th class="border-0 text-uppercase small font-weight-bold">Статус</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $profile->finance->sortDesc(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Illuminate\Support\Carbon::parse($finance->created_at)->format('d.m.Y H:i')); ?></td>
                                        <td><?php echo e(number_format($finance->coming / 100, 2, '.', '')); ?> ₽</td>
                                        <td><?php echo e($finance->event); ?></td>
                                        <td><?php echo e($finance->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="events">
                        <?php $__currentLoopData = $profile->events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <?php echo e($event->event); ?>

                                    </div>
                                    <div class="col-auto">
                                        <?php echo e(\Illuminate\Support\Carbon::parse($event->created_at)->format('d.m.Y H:i')); ?>

                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/admin/personal.blade.php ENDPATH**/ ?>