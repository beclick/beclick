<?php if(isset($scripts) and $scripts == 'start'): ?>
    <script src="<?php echo e(asset('js/common.js') . '?' . rand(0, 99999)); ?>"></script>
<?php endif; ?>
<?php if(isset($scripts) and $scripts == 'tiny'): ?>
    <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/layouts/scripts.blade.php ENDPATH**/ ?>