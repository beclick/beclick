<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link href="<?php echo e(asset('style.css') . '?' . rand(0, 99999)); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
</head>
<body class="lp">
<div class="login-page">
    <div class="content">
        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="logo">
                <img src="<?php echo e(asset('img/logo.svg')); ?>">
            </div>
            <div class="top-text">
                <?php echo e(__('passwords.reset_password')); ?>

            </div>
            <?php if(session('status')): ?>
                <div class="top-text">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="field-name">
                <?php echo e(__('app.email')); ?>

            </div>
            <input class="ltr" type="text" placeholder="<?php echo e(__('auth.enter_email')); ?>" name="email"
                   value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <button type="submit"><?php echo e(__('passwords.send_link_reset_password')); ?></button>
        </form>
    </div>
    <div class="bottom-block">
        <?php echo e(__('auth.already_registered')); ?> <a href="<?php echo e(route('login')); ?>"><?php echo e(__('auth.login')); ?></a>
    </div>
    <div class="copy">
        <p><?php echo e(__('app.all_rights_reserved')); ?></p>
        <a href="#"><?php echo e(__('app.privacy_policy')); ?></a>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>