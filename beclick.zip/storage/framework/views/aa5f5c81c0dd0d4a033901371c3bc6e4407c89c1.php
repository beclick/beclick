<?php $__env->startSection('title', 'Аукционный зал – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Аукционный зал: <a
                href="<?php echo e(route('auction', ['auction' => $lot->auction->id])); ?>">аукцион <?php echo e($lot->auction->id); ?></a> <a
                href="<?php echo e(route('home', ['lot' => $lot->id])); ?>">| лот <?php echo e($lot->num_lot); ?></a></h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50 p-0">
                <div class="row text-dark m-4">
                    <div class="col-lg">
                        <h5><?php echo e($lot->name); ?></h5>
                    </div>
                </div>
                <div class="list-group list-group-horizontal-lg rounded-0">
                    <a class="list-group-item list-group-item-secondary rounded-0 active" href="#torg"
                       data-toggle="tab"><h5>Ценовые предложения</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#all"
                       data-toggle="tab"><h5>Информация</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#docs" data-toggle="tab"><h5>
                            Документы</h5></a>
                    <div class="col list-group-item rounded-0 text-center text-danger">
                        <h2><strong class="clock"><?php echo e(\Illuminate\Support\Carbon::now()->format('H:i:s')); ?></strong></h2>
                    </div>
                    <div class="p-0 col-lg-3 list-group-item rounded-0">
                        <a href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>" class="h-100 btn btn-block alert-danger rounded-0">
                            Обновить страницу
                            <p><small>Страница обновляется автоматически</small></p>
                        </a>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <br>
                <?php if($lot->status == 0 and $my_profile->user_role == 1 and strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s'))): ?>
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-4">
                                <button class="h-100 btn btn-block btn-lg btn-outline-secondary rounded-0">
                                    <h5 class="text-black-50">Шаг аукциона</h5>
                                    <h3><?php echo e(number_format($lot->step_price / 100, 2, '.', '')); ?> ₽</h3>
                                </button>
                            </div>
                            <div class="col-lg">
                                <?php if(isset($rates->first()->profile_id) and $rates->first()->profile_id == $my_profile->id): ?>
                                    <button class="h-100 btn btn-lg btn-primary rounded-0">Ваша ценовое
                                        предложение
                                        максимальное
                                    </button>
                                <?php else: ?>
                                    <button class="h-100 btn btn-lg btn-success rounded-0"
                                            data-toggle="modal"
                                            data-target="#rates-modal">Сделать ценовое предложение
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                        <hr>
                        <div class="modal fade" id="rates-modal" tabindex="-1" role="dialog">
                            <div class="modal-dialog modal-dialog-centered" role="document">
                                <div class="modal-content rounded-0">
                                    <div class="modal-header rounded-0">
                                        <h5 class="modal-title">Сделать ценовое предложение</h5>
                                    </div>
                                    <div class="modal-body">
                                        <div class="form-group container">
                                            <form novalidate method="POST"
                                                  action="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" id="max_rate" name="max_rate"
                                                       value="">
                                                <input type="hidden" name="lot" value="<?php echo e($lot->id); ?>">
                                                <button type="button"
                                                        class="ecp_button btn btn-block btn-lg btn-success rounded-0">
                                                    Утвердить и подписать
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="tab-content">
                    <div class="tab-pane fade active show" id="torg">
                        <div id="rates" class="container">
                            <input id="h_timer" type="hidden" value="<?php echo e($timer); ?>">
                            <input id="h_rate" type="hidden"
                                   value="<?php if(isset($max_rate->price)): ?> <?php echo e($max_rate->price); ?> <?php endif; ?>">
                            <div class="row">
                                <?php if($timer != null and $lot->status == 0): ?>
                                    <div class="col-lg">
                                        <div class="h-100 btn btn-block btn-outline-secondary rounded-0">
                                            <h5 class="text-black-50">До конца срока подачи</h5>
                                            <h3 id="timer"><?php echo e(substr('0' . $timer / 60 % 60, -2) . ':' . substr('0' . $timer % 60, -2)); ?></h3>
                                        </div>
                                    </div>
                                <?php elseif($lot->status == 1): ?>
                                    <div class="col-lg">
                                        <div class="h-100 btn btn-block btn-outline-secondary rounded-0">
                                            <h5 class="text-black-50">Время окончания торгов</h5>
                                            <h3><?php echo e(\Illuminate\Support\Carbon::parse($lot->end_auction)->format('d.m.Y H:i')); ?></h3>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="col-lg">
                                    <div class="h-100 btn btn-block btn-lg btn-outline-success rounded-0">
                                        <h5 class="text-black-50">Начальная цена</h5>
                                        <h3><?php echo e(number_format($lot->start_price / 100, 2, '.', '')); ?> ₽</h3>
                                    </div>
                                </div>
                                <div class="col-lg">
                                    <div class="h-100 btn btn-block btn-lg btn-outline-success rounded-0">
                                        <h5 class="text-black-50">Текущая итоговая цена</h5>
                                        <h3><?php if(isset($max_rate)): ?> <?php echo e(number_format($max_rate->price / 100, 2, '.', '')); ?> <?php else: ?> <?php echo e(number_format($lot->start_price / 100, 2, '.', '')); ?> <?php endif; ?>
                                            ₽</h3>
                                    </div>
                                </div>
                            </div>
                            <hr>
                            <h5>Ценовые предложения</h5>
                            <div class="container-fluid overflow-auto">
                                <table class="table table-striped">
                                    <thead class="sticky-top">
                                    <tr class="">
                                        <th scope="col">Номер участника</th>
                                        <th scope="col">Номер предложения</th>
                                        <th scope="col">Номер заявки участника</th>
                                        <th scope="col">Ценовое предложение</th>
                                        <th scope="col">Дата и время ставки</th>
                                    </tr>
                                    </thead>
                                    <tbody class="">
                                    <?php $__currentLoopData = $rates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr <?php if($rate->profile_id == $my_profile->id): ?> class="text-primary" <?php endif; ?>>
                                            <th>
                                                <?php if($rate->profile_id == $my_profile->id): ?> Ваше предложение <?php else: ?>
                                                    ID: <?php echo e($rate->profile_id); ?> <?php endif; ?>
                                            </th>
                                            <th scope="row"><?php echo e($loop->count - $loop->index); ?></th>
                                            <th><?php echo e($lot->filings->where('profile_id', $rate->profile_id)->where('status', 1)->first()->id); ?></th>
                                            <th><?php echo e(number_format($rate->price / 100, 2, '.', '')); ?></th>
                                            <th><?php echo e(\Illuminate\Support\Carbon::parse($rate->created_at)->format('d.m.Y H:i:s')); ?></th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="all">
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Статус торгов</p>
                            <p class="col">
                                <?php if($lot->status == 1): ?>
                                    <strong class="text-success">Торги по лоту состоялись</strong>
                                <?php elseif($lot->status == 2): ?>
                                    <strong class="text-warning">Торги по лоту не состоялись</strong>
                                <?php elseif($lot->status == 3): ?>
                                    <strong class="text-danger">Приостановлен</strong>
                                <?php elseif($lot->status == 4): ?>
                                    <strong class="text-danger">Аннулирован</strong>
                                <?php elseif($lot->auction->status == 0): ?>
                                    <strong class="text-black-50">Не активный</strong>
                                <?php elseif($lot->auction->status == 1): ?>
                                    <?php if(strtotime(date('Y-m-d H:i')) <= strtotime($lot->start_request)): ?>
                                        <strong class="text-success">Объявлен</strong>
                                    <?php elseif(strtotime($lot->start_request) <= strtotime(date('Y-m-d H:i')) and strtotime(date('Y-m-d H:i')) < strtotime($lot->end_request)): ?>
                                        <strong class="text-info">Идёт приём заявок</strong>
                                    <?php elseif(strtotime($lot->end_request) <= strtotime(date('Y-m-d H:i')) and strtotime(date('Y-m-d H:i')) < strtotime($lot->start_auction)): ?>
                                        <strong class="text-warning">Приём заявок завершен</strong>
                                    <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i'))): ?>
                                        <strong class="text-success">Идут торги</strong>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Дата начала</p>
                            <p class="col">
                                <?php echo e(\Illuminate\Support\Carbon::parse($lot->start_auction)->format('d.m.Y H:i')); ?>

                            </p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Начальная цена</p>
                            <p class="col"><?php echo e(number_format($lot->start_price / 100, 2, '.', '')); ?> ₽</p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Размер задатка</p>
                            <p class="col"><?php echo e(number_format($lot->deposit_price / 100, 2, '.', '')); ?> ₽</p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Шаг аукциона</p>
                            <p class="col"><?php echo e(number_format($lot->step_price / 100, 2, '.', '')); ?> ₽</p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Организатор торгов</p>
                            <p class="col">
                                <?php if($lot->profile->user_type == 0): ?>
                                    <?php echo e($lot->profile->full_title); ?>

                                <?php else: ?>
                                    <?php echo e($lot->profile->full_name); ?>

                                <?php endif; ?>
                            </p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Имущество должника</p>
                            <p class="col"><?php echo e($lot->debtor); ?></p>
                        </h5>
                        <?php if($lot->status == 1): ?>
                            <h5 class="row m-0">
                                <p class="col-lg-5 text-black-50">Время окончания торгов</p>
                                <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($lot->end_auction)->format('d.m.Y H:i')); ?></p>
                            </h5>
                            <h5 class="row m-0">
                                <p class="col-lg-5 text-black-50">Победитель торгов</p>
                                <p class="col">
                                    <?php if(isset($max_rate)): ?>
                                        <?php if($max_rate->profile->user_type == 0): ?>
                                            <?php echo e($max_rate->profile->full_title); ?>

                                        <?php else: ?>
                                            <?php echo e($max_rate->profile->full_name); ?>

                                        <?php endif; ?>
                                    <?php endif; ?>
                                </p>
                            </h5>
                            <h5 class="row m-0">
                                <p class="col-lg-5 text-black-50">ИНН</p>
                                <p class="col">
                                    <?php if(isset($max_rate)): ?>
                                        <?php echo e($max_rate->profile->inn); ?>

                                    <?php endif; ?>
                                </p>
                            </h5>
                        <?php endif; ?>
                    </div>
                    <div class="tab-pane fade" id="docs">
                        <?php $__currentLoopData = $lot->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАН
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $lot->protocol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАН
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.ecp-modal', ['title' => 'Подтверждаю свое ценовое предложение, согласно регламенту ЭТП.', 'submit' => 'Сделать предложение'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if($timer != null and $lot->status == 0): ?>
            <script>
                $(document).ready(function () {
                    let time = $('#h_timer').val(),
                        max_rate = $('#h_rate').val(),
                        sec = 0;
                    $('#max_rate').val(max_rate);
                    const timer = setInterval(function () {
                        if (time == null) {
                            time = $('#h_timer').val();
                            $('#timer').addClass('text-danger');
                            $('#timer').text('обновление');

                            if (max_rate !== $('#h_rate').val()) {
                                max_rate = $('#h_rate').val();
                                $('#max_rate').val(max_rate);
                                $('#torg').prepend('<div class="container">' +
                                    '<div class="alert alert-danger rounded-0 text-center"><h5>Новая ставка</h5></div>' +
                                    '</div>');
                            }
                        } else {
                            $('#timer').removeClass('text-danger');
                            if (time <= 0) {
                                clearInterval(timer);
                                $('#timer').text('Время вышло');
                            } else {
                                let str_time = ('0' + Math.trunc((time - sec) / 60 % 60)).slice(-2) + ':' + ('0' + (time - sec) % 60).slice(-2);
                                $('#timer').text(str_time);
                            }
                        }
                        if (sec > 9) {
                            sec = 0;
                            $('#torg').load(document.URL + ' #rates');
                            time = null;
                        }
                        ++sec;
                    }, 1000);
                });
            </script>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/auction-hall.blade.php ENDPATH**/ ?>