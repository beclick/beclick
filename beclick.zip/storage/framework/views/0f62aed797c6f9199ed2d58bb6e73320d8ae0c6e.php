<?php $__env->startSection('title', __('app.offer_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <a href="<?php echo e(route('requests')); ?>" class="back-mob-link"></a>
        <div class="page-name">
            <div class="navi other">
                <?php echo e($project->title); ?>

                <i class="fa fa-angle-left"></i> <a href="<?php echo e(route('requests')); ?>"><?php echo e(__('app.offer_title')); ?></a>
                <i class="fa fa-angle-left"></i> <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.offer1')); ?></a>
            </div>
        </div>
        <div class="top-back-link other">
            <a href="<?php echo e(route('requests')); ?>" class="other"><span></span> <?php echo e(__('app.offer2')); ?></a>
        </div>
    </div>
    <div class="project-page">
        <div class="top-info">
            <div class="flex">
                <div class="date">
                    <span
                        class="other"><?php echo e(\Illuminate\Support\Carbon::parse($project->created_at)->format('d.m.Y H:i')); ?></span>
                </div>
                <?php if(strtotime($project->created_at) < strtotime($project->updated_at)): ?>
                    <div class="date">
                        <strong style="color: #EB5757"><?php echo e(__('app.offer3')); ?> <span
                                class="other"><?php echo e(\Illuminate\Support\Carbon::parse($project->updated_at)->format('d.m.Y H:i')); ?>

                        </strong></span>
                    </div>
                <?php endif; ?>
            </div>
            <div class="flex">
                <div class="info">
                    <div class="name">
                        <?php echo e($project->title); ?>

                    </div>
                    <p><?php echo e($project->text); ?></p>
                    <div class="field-name">
                        <?php echo $project->questions; ?>

                    </div>
                    <div class="button">
                        <a href="<?php echo e(route('requests', ['delete' => $project->id])); ?>">
                            <button class="other"><span></span> <?php echo e(__('app.offer4')); ?></button>
                        </a>
                        <a target="_blank" href="<?php echo e($project->docs_url); ?>"
                           class="trash other"><?php echo e(__('app.offer5')); ?></a>
                    </div>
                </div>
                <?php if($project->contact_hide == 1): ?>
                    <div class="hidden-info">
                        <p><?php echo e(__('app.offer6')); ?></p>
                    </div>
                <?php else: ?>
                    <table>
                        <tr>
                            <td><?php echo e(__('app.offer7')); ?></td>
                            <td>
                                <?php $__currentLoopData = explode('|', $project->regions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->index > 0): ?>
                                        <p><?php echo e($region); ?></p>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                        </tr>
                        <tr>
                            <?php if(isset($project->profile->address)): ?>
                                <td><?php echo e(__('app.offer8')); ?></td>
                                <td><?php echo e($project->profile->address); ?></td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if(isset($project->profile->contact_phone)): ?>
                                <td><?php echo e(__('app.offer9')); ?></td>
                                <td><?php echo e($project->profile->contact_phone); ?> <?php if(isset($project->profile->contact_phone_d)): ?>
                                        <?php echo e(__('app.items6')); ?> <?php echo e($project->profile->contact_phone_d); ?> <?php endif; ?></td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if(isset($project->profile->email)): ?>
                                <td><?php echo e(__('app.email')); ?></td>
                                <td><a href="mailto:<?php echo e($project->profile->email); ?>"><?php echo e($project->profile->email); ?></a>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <tr>
                            <?php if(isset($project->profile->contact_person)): ?>
                                <td><?php echo e(__('app.offer10')); ?></td>
                                <td><?php echo e($project->profile->contact_person); ?></td>
                            <?php endif; ?>
                        </tr>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        <?php if($project->contact_hide == 1): ?>
            <div class="hidden-info">
                <p><?php echo e(__('app.offer6')); ?></p>
            </div>
        <?php else: ?>
            <div class="response">
                <div class="main-info flex">
                    <div class="name">
                        <div>
                            <a href="<?php echo e(route('company', ['id' => $project->profile->id])); ?>">
                                <div class="avatar"
                                     style=" <?php if(isset($project->profile->image)): ?> background-image: url(<?php echo e(asset('storage/' . $project->profile->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                                </div>
                            </a>
                        </div>
                        <div style="padding-right: 2rem">
                            <div class="n other">
                                <?php echo e($project->profile->name); ?>

                            </div>
                            <p><?php echo e($project->profile->description); ?></p>
                        </div>
                    </div>
                    <div class="date other">
                        <p><?php echo e(\Illuminate\Support\Carbon::parse($project->profile->created_at)->format('d.m.Y H:i')); ?></p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php $__currentLoopData = $project->responses->where('profile_id', $myprofile->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $response): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="response">
                <div class="main-info flex">
                    <div class="name">
                        <p><?php echo $response->text; ?></p>
                    </div>
                    <div class="date">
                        <p><?php echo e(\Illuminate\Support\Carbon::parse($response->created_at)->format('d.m.Y H:i')); ?></p>
                        <div class="price">
                            <?php echo e(__('app.offer11')); ?>

                            <span>$<?php echo e($response->price); ?></span>
                        </div>
                    </div>
                </div>
                <div class="button flex">
                    <?php if(isset($response->pdf)): ?>
                        <a data-fancybox="pdf<?php echo e($response->id); ?>" href="<?php echo e(asset('storage/' . $response->pdf)); ?>"
                           class="pdf"><?php echo e(__('app.offer12')); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <form id="send_form">
            <?php echo csrf_field(); ?>
            <div class="editor">
                <p><?php echo e(__('app.offer13')); ?></p>
                <div class="wysiwig">
                    <textarea id="text"></textarea>
                </div>
                <div class="flex">
                    <div class="price">
                        <p><span>*</span> <?php echo e(__('app.offer14')); ?></p>
                        <div class="field">
                            <span>$</span>
                            <input name="price" type="number">
                        </div>
                    </div>
                    <div class="button">
                        <label>
                            <a class="pdf"><?php echo e(__('app.offer15')); ?></a>
                            <input type="file" name="pdf" accept="application/pdf" autocomplete="off" hidden>
                        </label>
                        <button class="send_btn" type="button"><span></span> <?php echo e(__('app.offer16')); ?></button>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script>
        $(document).ready(function () {
            $.ajax({
                url: "<?php echo e(route('resource', ['scripts' => 'tiny'])); ?>",
            }).done(function (data) {
                setTimeout(function () {
                    $('head').append(data);
                }, 100);
                setTimeout(function () {
                    tinymce.init({selector: '#text', directionality: 'rtl'});
                }, 1000);
            });


            $('.pdf').next('input').change(function () {
                var offer17 = '<?php echo e(__('app.offer17')); ?>';
                if (this.files[0]) {
                    var fr = new FileReader(),
                        type = this.files[0].type,
                        name = this.files[0].name;
                    if (type === 'application/pdf') {
                        fr.addEventListener('load', function () {
                            $('.pdf').text(name);
                        }, false);
                        fr.readAsDataURL(this.files[0]);
                    } else {
                        show_alert(offer17);
                    }
                }
            });

            $('.send_btn').click(function () {
                var text = tinymce.get('text').getContent(),
                    formData = new FormData($('#send_form')[0]);
                formData.append('text', text);
                $.ajax({
                    url: "<?php echo e(route('requests', ['proj' => $project->id])); ?>",
                    type: 'POST',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    contentType: false,
                    processData: false,
                    data: formData,
                }).done(function (data) {
                    show_alert(data[1]);
                    if (data[0] === 1) {
                        setTimeout(function () {
                            window.location.reload();
                        }, 500);
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/offer.blade.php ENDPATH**/ ?>