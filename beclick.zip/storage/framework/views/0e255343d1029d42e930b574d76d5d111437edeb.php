<?php $__env->startSection('title', __('app.requests_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                <?php echo e(__('app.requests_title')); ?> <i class="fa fa-angle-left"></i> <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.requests1')); ?></a>
            </div>
            <h1><?php echo e(__('app.requests_title')); ?></h1>
        </div>
        <div class="projects-top-menu">
            <ul>
                <li><a class="a1 active"><?php echo e(__('app.requests2')); ?></a></li>
                <li><a class="a2"><?php echo e(__('app.requests3')); ?></a></li>
                <li><a class="a3"><?php echo e(__('app.requests4')); ?></a></li>
            </ul>
        </div>
    </div>
    <div class="projects-page p3">
        <?php $__currentLoopData = $requs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($requ->status != 0): ?>
                <div class="item">
                    <div class="main-info">
                        <div class="flex">
                            <div class="date">
                                ID <?php echo e($requ->project->id); ?>

                                <?php if($requ->read == 1): ?>
                                    <span><strong style="color: #EB5757"><?php echo e(__('app.requests5')); ?></strong> <?php echo e(\Illuminate\Support\Carbon::parse($requ->project->updated_at)->format('d.m.Y H:i')); ?></span>
                                <?php else: ?>
                                    <span><?php echo e(\Illuminate\Support\Carbon::parse($requ->project->updated_at)->format('d.m.Y H:i')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="views">
                                <?php echo e($requ->project->views); ?>

                            </div>
                        </div>
                        <a href="#" class="name"><?php echo e($requ->project->title); ?></a>
                        <p class="ellipsis"><?php echo e($requ->project->text); ?></p>
                    </div>
                    <div class="button flex">
                        <a href="<?php echo e(route('requests', ['return' => $requ->project->id])); ?>" class="link"><?php echo e(__('app.requests6')); ?></a>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="projects-page p2">
        <?php $__currentLoopData = $requs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($requ->project->responses->count() > 0 and $requ->status == 0): ?>
                <div class="item">
                    <div class="main-info">
                        <div class="flex">
                            <div class="date">
                                ID <?php echo e($requ->project->id); ?>

                                <?php if($requ->read == 1): ?>
                                    <span><strong style="color: #EB5757"><?php echo e(__('app.requests5')); ?></strong> <?php echo e(\Illuminate\Support\Carbon::parse($requ->project->updated_at)->format('d.m.Y H:i')); ?></span>
                                <?php else: ?>
                                    <span><?php echo e(\Illuminate\Support\Carbon::parse($requ->project->updated_at)->format('d.m.Y H:i')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="views">
                                <?php echo e($requ->project->views); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(route('requests', ['proj' =>$requ->project->id])); ?>"
                           class="name"><?php echo e($requ->project->title); ?></a>
                        <p class="ellipsis"><?php echo e($requ->project->text); ?></p>
                    </div>
                    <div class="button flex">
                        <?php if($subscription == true): ?>
                            <a href="<?php echo e(route('requests', ['delete' => $requ->project->id])); ?>"
                               class="link"><?php echo e(__('app.requests7')); ?></a>
                            <div>
                                <a href="<?php echo e(route('requests', ['proj' =>$requ->project->id])); ?>">
                                    <button class="active"><span></span> <?php echo e(__('app.requests8')); ?></button>
                                </a>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo e(route('payment')); ?>" class="link"><?php echo e(__('app.requests9')); ?></a>
                            <div>
                                <button class="active" disabled><span></span> <?php echo e(__('app.requests10')); ?></button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="projects-page p1 active flex2">
        <?php $__currentLoopData = $requs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($requ->project->responses->count() == 0 and $requ->status == 0): ?>
                <div class="item">
                    <div class="main-info">
                        <div class="flex">
                            <div class="date">
                                ID <?php echo e($requ->project->id); ?>

                                <?php if($requ->read == 1): ?>
                                    <span><strong style="color: #EB5757"><?php echo e(__('app.requests5')); ?></strong> <?php echo e(\Illuminate\Support\Carbon::parse($requ->project->updated_at)->format('d.m.Y H:i')); ?></span>
                                <?php else: ?>
                                    <span><?php echo e(\Illuminate\Support\Carbon::parse($requ->project->updated_at)->format('d.m.Y H:i')); ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="views">
                                <?php echo e($requ->project->views); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(route('requests', ['proj' =>$requ->project->id])); ?>"
                           class="name"><?php echo e($requ->project->title); ?></a>
                        <p class="ellipsis"><?php echo e($requ->project->text); ?></p>
                    </div>
                    <div class="button flex">
                        <?php if($subscription == true): ?>
                            <a href="<?php echo e(route('requests', ['delete' => $requ->project->id])); ?>" class="link"><?php echo e(__('app.requests11')); ?></a>
                            <div>
                                <a href="<?php echo e(route('requests', ['proj' =>$requ->project->id])); ?>">
                                    <button class="big"><span></span> <?php echo e(__('app.requests12')); ?></button>
                                </a>
                            </div>
                        <?php else: ?>
                            <a href="<?php echo e(route('payment')); ?>" class="link"><?php echo e(__('app.requests9')); ?></a>
                            <div>
                                <button class="big" disabled><span></span> <?php echo e(__('app.requests12')); ?></button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/requests.blade.php ENDPATH**/ ?>