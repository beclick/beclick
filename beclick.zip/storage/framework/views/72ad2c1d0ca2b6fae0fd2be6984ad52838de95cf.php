<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width">

    <title>Добро пожаловать – beclick</title>
</head>
<body>
<br>
<h2>тут находится лендинг пейж</h2>
<?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('home')); ?>"><h2 class="reg-main__title">Домашняя страница</h2></a>
<?php else: ?>
    <a href="<?php echo e(route('login')); ?>"><h2 class="reg-main__title">Вход</h2></a>
    <?php if(Route::has('register')): ?>
        <a href="<?php echo e(route('register')); ?>"><h2 class="reg-main__title">Регистрация</h2></a>
    <?php endif; ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/welcome.blade.php ENDPATH**/ ?>