<?php $__env->startSection('title', 'Заявка на участие – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Подача заявки на уастие в торгах по лоту <?php echo e($lot->num_lot); ?> в аукционе <?php echo e($lot->auction->id); ?></h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50">
                <h5><strong><a class="card-link text-dark"
                               href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->name); ?></a></strong>
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-lg">
                        <h5 class="text-black-50">Начальная цена</h5>
                        <h3><?php echo e(number_format($lot->start_price / 100, 2, '.', '')); ?> ₽</h3>
                    </div>
                    <div class="col-lg">
                        <h5 class="text-black-50">Депозит</h5>
                        <h3><?php echo e(number_format($lot->deposit_price / 100, 2, '.', '')); ?> ₽</h3>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="col-lg">
                        <?php if($lot->status == 0): ?>
                            <?php if(isset($filing)): ?>
                                <?php if($filing->status == 0): ?>
                                    <a class="btn btn-block btn-lg btn-primary rounded-0"
                                       href="<?php echo e(route('filing')); ?>">Заявка уже отправлена, перейти к моим заявкам</a>
                                <?php elseif($filing->status == 1): ?>
                                    <a class="btn btn-block btn-lg btn-success rounded-0" href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>">Заявка одобрена,
                                        перейти к
                                        торгам</a>
                                <?php else: ?>
                                    <a class="btn btn-block btn-lg btn-danger rounded-0" href="<?php echo e(route('home')); ?>">Заявка
                                        отклонена</a>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if(($my_profile->balance - $my_profile->blocked) < $lot->deposit_price): ?>
                                    <a class="btn btn-block btn-lg btn-danger rounded-0" href="<?php echo e(route('finance')); ?>">Недостаточно
                                        свободных средств на счете</a>
                                <?php elseif(strtotime($lot->start_request) <= strtotime(date('Y-m-d H:i')) and strtotime(date('Y-m-d H:i')) < strtotime($lot->end_request)): ?>
                                    <form novalidate method="POST" action="<?php echo e(route('filing')); ?>" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input name="lot" value="<?php echo e($lot->id); ?>" hidden>
                                        <button type="button" class="ecp_button btn btn-block btn-lg btn-success rounded-0">
                                            Добавить
                                            документы и подписать ЭЦП
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <button type="button" class="btn btn-block btn-lg btn-success rounded-0">Сбор заявок
                                        начнется <?php echo e($lot->start_request); ?>

                                    </button>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php elseif($lot->status == 1): ?>
                            <button type="button" class="btn btn-block btn-lg btn-success rounded-0">Торги по лоту
                                состоялись
                            </button>
                        <?php elseif($lot->status == 2): ?>
                            <button type="button" class="btn btn-block btn-lg btn-danger rounded-0">Торги по лоту не
                                состоялись
                            </button>
                        <?php elseif($lot->status == 3): ?>
                            <button type="button" class="btn btn-block btn-lg btn-danger rounded-0">Лот аннулирован
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('layouts.ecp-modal', ['file' => 'true', 'title' => 'Подтверждаю свои действия и принимает условия подачи заявки на участие в торгах, согласно регламенту ЭТП.', 'submit' => 'Отправить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/filing.blade.php ENDPATH**/ ?>