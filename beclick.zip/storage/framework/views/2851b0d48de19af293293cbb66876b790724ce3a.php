<!doctype html>
<html dir="rtl" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/png">

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
    <!-- Common -->
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('style.css') . '?' . rand(0, 99999)); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('slick.css')); ?>" rel="stylesheet">

</head>
<body style="display: none">
<header class="header">
    <nav class="top-menu">
        <ul>
            <li><a href="#"><?php echo e(__('app.recomended')); ?></a></li>
            <li><a href="#"><?php echo e(__('app.forum')); ?></a></li>
            <li><a href="#"><?php echo e(__('app.useful')); ?></a></li>
            <li><a href="#"><?php echo e(__('app.faq')); ?></a></li>
        </ul>
    </nav>
    <div class="flex">
        <div class="left-side">
            <a class="menu-button"></a>
            <a href="<?php echo e(route('new_project')); ?>"><button class="add"><?php echo e(__('app.create_project')); ?> +</button></a>
            <div class="profile-link">
                <i class="fa fa-angle-down"></i> <?php echo e(__('app.my_profile')); ?> <img src="<?php echo e(asset('img/avatar.png')); ?>">
                <div class="sub">
                    <ul>
                        <li><a href="<?php echo e(route('profile')); ?>"><?php echo e(__('app.my_profile')); ?></a></li>
                        <li><a href="<?php echo e(route('profile.edit')); ?>"><?php echo e(__('app.edit_profile')); ?></a></li>
                        <li><a class="nav-link" href=""
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <?php echo e(__('app.exit')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            <a href="<?php echo e(route('payment')); ?>" class="subscribe"></a>
        </div>
        <div class="right-side">
            <ul>
                <li><a href="#"><?php echo e(__('app.articles')); ?></a></li>
                <li><a href="<?php echo e(route('payment')); ?>"><?php echo e(__('app.prices')); ?></a></li>
                <li><a href="<?php echo e(route('requests')); ?>"><?php if($requ_count > 0): ?>
                            <span><?php echo e($requ_count); ?></span><?php endif; ?><?php echo e(__('app.requests_kp')); ?></a></li>
                <li><a href="<?php echo e(route('projects')); ?>"><?php if($resp_count > 0): ?>
                            <span><?php echo e($resp_count); ?></span><?php endif; ?><?php echo e(__('app.my_projects')); ?></a></li>
            </ul>
            <a class="catalog-link"><i class="fa fa-angle-down"></i> <?php echo e(__('app.catalog_of_performers')); ?>

                <span></span></a>
            <div class="logo">
                <a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('img/logo.svg')); ?>"></a>
            </div>
        </div>
    </div>
    <div class="mobile-menu">
        <ul class="ul1">
            <li><a href="#"><?php echo e(__('app.articles')); ?></a></li>
            <li><a href="<?php echo e(route('payment')); ?>"><?php echo e(__('app.prices')); ?></a></li>
            <li><a href="<?php echo e(route('requests')); ?>"><?php if($requ_count > 0): ?>
                        <span><?php echo e($requ_count); ?></span><?php endif; ?><?php echo e(__('app.requests_kp')); ?></a></li>
            <li><a href="<?php echo e(route('projects')); ?>"><?php if($resp_count > 0): ?>
                        <span><?php echo e($resp_count); ?></span><?php endif; ?><?php echo e(__('app.my_projects')); ?></a></li>
        </ul>
        <ul class="ul2">
            <li><a href="#"><?php echo e(__('app.recomended')); ?></a></li>
            <li><a href="#"><?php echo e(__('app.forum')); ?></a></li>
            <li><a href="#"><?php echo e(__('app.useful')); ?></a></li>
            <li><a href="#"><?php echo e(__('app.faq')); ?></a></li>
        </ul>
        <a href="<?php echo e(route('new_project')); ?>">
            <button class="add"><?php echo e(__('app.create_project')); ?> +</button>
        </a>
    </div>
    <div class="mob-header-catalog">
        <ul>
            <?php $__currentLoopData = $all_categories[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a>
                        <span><?php echo e($category->title); ?></span>
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <ul>
                        <?php if(isset($all_categories[$category->id])): ?>
                            <?php $__currentLoopData = $all_categories[$category->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(route('find', ['category' => $category->id, 'subcategory' => $cat->id])); ?>"
                                       class="link"><span><i>(<?php echo e($cat->count); ?>)</i><?php echo e($cat->title); ?></span></a></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <div class="name">
            <?php echo e(__('app.find12')); ?>

        </div>
        <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="header-catalog">
        <ul>
            <?php $__currentLoopData = $all_categories[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <a href="<?php echo e(route('find', ['category' => $category->id])); ?>">
                        <span><?php echo e($category->title); ?></span>
                        <i class="fa fa-angle-left"></i>
                    </a>
                    <div class="sub">
                        <div class="flex">
                            <div class="col shops">
                                <div class="name">
                                    <?php echo e(__('app.find12')); ?>

                                </div>
                                <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            <?php if(isset($all_categories[$category->id])): ?>
                                <?php
                                    $i = $all_categories[$category->id]->count()/2;
                                ?>
                                <div class="col">
                                    <?php $__currentLoopData = $all_categories[$category->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="<?php echo e(route('find', ['category' => $category->id, 'subcategory' => $cat->id])); ?>"
                                           class="link"><span><i>(<?php echo e($cat->count); ?>)</i><?php echo e($cat->title); ?></span></a>
                                        <?php if($loop->iteration >= $i): ?>
                                            <?php
                                                $i = 999999;
                                            ?>
                                </div>
                                <div class="col">
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</header>

<div class="wrap">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<footer class="footer">
    <div class="wrap">
        <div class="flex">
            <nav>
                <p><?php echo e(__('app.about_project')); ?></p>
                <ul>
                    <li><a href="#"><?php echo e(__('app.about')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.contacts')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.privacy_policy')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.map_site')); ?></a></li>
                </ul>
            </nav>
            <nav>
                <p><?php echo e(__('app.to_the_customer')); ?></p>
                <ul>
                    <li><a href="#"><?php echo e(__('app.recomended')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.support')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.catalog_of_performers')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.prices')); ?></a></li>
                </ul>
            </nav>
            <nav>
                <p><?php echo e(__('app.for_the_contractor')); ?></p>
                <ul>
                    <li><a href="#"><?php echo e(__('app.support')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.companies')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.articles')); ?></a></li>
                    <li><a href="#"><?php echo e(__('app.forum')); ?></a></li>
                </ul>
            </nav>
            <div class="social">
                <p><?php echo e(__('app.social_networks')); ?></p>
                <div class="links">
                    <a href="#"><img src="<?php echo e(asset('img/social1.svg')); ?>"></a>
                    <a href="#"><img src="<?php echo e(asset('img/social2.svg')); ?>"></a>
                    <a href="#"><img src="<?php echo e(asset('img/social3.svg')); ?>"></a>
                    <a href="#"><img src="<?php echo e(asset('img/social4.svg')); ?>"></a>
                </div>
                <p><?php echo e(__('app.subscribe_news')); ?></p>
                <form>
                    <input type="text" placeholder="e-mail">
                    <button></button>
                </form>
            </div>
        </div>
        <div class="line"></div>
        <div class="flex">
            <div class="payment">
                <?php echo e(__('app.payment_system')); ?> <img src="<?php echo e(asset('img/payment.svg')); ?>">
            </div>
            <div class="copy">
                <?php echo e(__('app.all_rights_reserved')); ?>

            </div>
        </div>
    </div>
</footer>

<div class="alrt" style="display: none">
    <a class="close"></a>
    <p><?php if(isset($alert)): ?> <?php echo e($alert); ?> <?php endif; ?></p>
</div>

<script>
    $(document).ready(function () {
        $('body').children().each(function () {
            $(this).html($(this).html().replace(/\u2028/g, ''));
        });

        $.ajax({
            url: "<?php echo e(route('resource', ['scripts' => 'start'])); ?>",
        }).done(function (data) {
            $('head').append(data);
            const key = setInterval(function () {
                $('body').css('display', 'block');
                if ($('body').css('display') == 'block') {
                    clearInterval(key);
                }
            }, 10);
        });

        <?php if(isset($alert)): ?>
        history.replaceState(null, null, '<?php echo e(route($route)); ?>');
        setTimeout(function () {
            $('.alrt').fadeIn();
        }, 300);
        setTimeout(function () {
            $('.alrt').fadeOut();
        }, 3500);
        <?php endif; ?>
    });
</script>

</body>
</html>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/layouts/app.blade.php ENDPATH**/ ?>