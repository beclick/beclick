<?php $__env->startSection('title', 'Финансы – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
        <div class="container mt-5">
            <h3>Финансовая информация</h3>
            <hr>
            <div class="card rounded-0 shadow">
                <div class="card-header bg-white text-black-50 p-0">
                    <div class="row text-dark m-4">
                        <div class="col-lg">
                            <h5><?php if($my_profile->user_type == 0): ?> <?php echo e($my_profile->title); ?> <?php elseif($my_profile->user_type == 1): ?> <?php echo e('ИП ' . $my_profile->full_name); ?> <?php elseif($my_profile->user_type == 2): ?> <?php echo e('ФЛ ' . $my_profile->full_name); ?> <?php endif; ?></h5>
                        </div>
                        <div class="col-lg-auto">
                            <h5 class="text-info">
                                <?php if($my_profile->user_role == 0): ?>
                                    Организатор торгов
                                <?php elseif($my_profile->user_role == 1): ?>
                                    Участник торгов
                                <?php endif; ?>
                            </h5>
                        </div>
                    </div>
                    <div class="list-group list-group-horizontal-lg rounded-0">
                        <a class="card-link list-group-item list-group-item-secondary rounded-0 active" href="#all"
                           data-toggle="tab"><h5>Информация</h5></a>
                        <a class="list-group-item list-group-item-secondary rounded-0" href="#events" data-toggle="tab"><h5>
                                История</h5></a>
                        <a class="col list-group-item rounded-0 text-right text-dark" href="<?php echo e(route('finance')); ?>">
                            <h5>Баланс: <?php echo e(number_format($my_profile->balance / 100, 2, '.', '')); ?> ₽ |
                                Блок: <?php echo e(number_format($my_profile->blocked / 100, 2, '.', '')); ?> ₽
                            </h5>
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="tab-content">
                        <div class="tab-pane fade active show" id="all">
                                <h5 class="row">
                                    <p class="col-lg-4">Номер счета для оплаты услуг:</p>
                                    <p class="col">0001/IE-6864625-2</p>
                                </h5>
                                <h5 class="row">
                                    <p class="col">Для вывода денежных средства заполните заявку на вывод с указанием реквизитов
                                        для вывода, суммы и корректных реквизитов.</p>
                                </h5>
                                <h5 class="row">
                                    <a href="<?php echo e(route('withdrawal')); ?>" class="btn btn-block btn-lg btn-outline-primary rounded-0" role="button">
                                        Подать заявку на вывод. Вниимание! Все заявки обрабатываются вручную. Срок выполнения занимает до 3-х рабочих дней.
                                    </a>
                                </h5>
                            <h5 class="row">
                                <a href="<?php echo e(route('contacts')); ?>" class="btn btn-block btn-lg btn-outline-primary rounded-0" role="button">
                                    Реквизиты для перечисления средств
                                </a>
                            </h5>
                        </div>
                        <div class="tab-pane fade" id="events">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th class="border-0 text-uppercase small font-weight-bold">Дата время</th>
                                    <th class="border-0 text-uppercase small font-weight-bold">Сумма</th>
                                    <th class="border-0 text-uppercase small font-weight-bold">Действие</th>
                                    <th class="border-0 text-uppercase small font-weight-bold">Статус</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $my_profile->finance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e(\Illuminate\Support\Carbon::parse($finance->created_at)->format('d.m.Y H:i')); ?></td>
                                        <td><?php echo e(number_format($finance->coming / 100, 2, '.', '')); ?> ₽</td>
                                        <td><?php echo e($finance->event); ?></td>
                                        <td><?php echo e($finance->status); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/finance.blade.php ENDPATH**/ ?>