<?php $__env->startSection('title', 'Заявки на участие – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Заявки на участие</h3>
        <hr>
        <h5><a href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->name); ?></a></h5>
        <hr>
        <?php $__currentLoopData = $filings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(in_array($filing->auction->id, $auctions)): ?>
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-white text-black-50 p-0">
                        <div class="row text-dark m-4">
                            <div class="col-lg">
                                <h5><?php if($filing->profile->user_type == 0): ?> <?php echo e($filing->profile->title); ?> <?php elseif($filing->profile->user_type == 1): ?> <?php echo e('ИП ' . $filing->profile->full_name); ?> <?php elseif($filing->profile->user_type == 2): ?> <?php echo e('ФЛ ' . $filing->profile->full_name); ?> <?php endif; ?></h5>
                            </div>
                            <div class="col-lg-auto">
                                <h5 class="text-info">
                                    ID в системе: <?php echo e($filing->profile->id); ?>

                                </h5>
                            </div>
                        </div>
                        <div class="list-group list-group-horizontal-lg rounded-0">
                            <a class="list-group-item list-group-item-secondary rounded-0 active"
                               href="#all<?php echo e($filing->id); ?>"
                               data-toggle="tab"><h5>Информация</h5></a>
                            <a class="list-group-item list-group-item-secondary rounded-0" href="#docs<?php echo e($filing->id); ?>"
                               data-toggle="tab"><h5>
                                    Документы</h5></a>
                            <?php if($filing->status == 0): ?>
                                <div class="p-0 col list-group-item rounded-0">
                                    <a class="h-100 btn btn-block btn-lg btn-outline-danger rounded-0"
                                       data-toggle="modal" data-target="#bargaining-rej<?php echo e($filing->id); ?>">Отклонить</a>
                                </div>
                                <div class="p-0 col list-group-item rounded-0">
                                    <a class="h-100 btn btn-block btn-lg btn-outline-success rounded-0"
                                       data-toggle="modal" data-target="#bargaining-confirm<?php echo e($filing->id); ?>">Подтвердить</a>
                                </div>
                            <?php elseif($filing->status == 1): ?>
                                <div class="p-0 col list-group-item rounded-0">
                                    <a class="h-100 btn btn-block btn-lg btn-success rounded-0">Подтвержден</a>
                                </div>
                            <?php elseif($filing->status == 2): ?>
                                <div class="p-0 col list-group-item rounded-0">
                                    <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">Отклонен</a>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if($filing->status == 0): ?>
                            <div class="modal fade" id="bargaining-rej<?php echo e($filing->id); ?>" tabindex="-1"
                                 role="dialog">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content rounded-0">
                                        <div class="modal-header rounded-0">
                                            <h5 class="modal-title">Укажите причину отказа</h5>
                                        </div>
                                        <div class="modal-body">
                                            <form novalidate method="POST"
                                                  action="<?php echo e(route('bargaining')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input name="filing" value="<?php echo e($filing->id); ?>" hidden>
                                                <input name="confirm" value="false" hidden>
                                                <div class="form-group">
                                                    <textarea class="form-control form-control-lg rounded-0" required
                                                              type="text" name="text"
                                                              placeholder="Причины для отказа"></textarea>
                                                </div>
                                                <button type="button"
                                                        class="ecp_button btn btn-block btn-lg btn-danger rounded-0">
                                                    Подписать отказ
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="bargaining-confirm<?php echo e($filing->id); ?>" tabindex="-1"
                                 role="dialog">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content rounded-0">
                                        <div class="modal-header rounded-0">
                                            <h5 class="modal-title">Допустить участника к аукциону?</h5>
                                        </div>
                                        <div class="modal-body">
                                            <form novalidate method="POST"
                                                  action="<?php echo e(route('bargaining')); ?>">
                                                <?php echo csrf_field(); ?>
                                                <input name="filing" value="<?php echo e($filing->id); ?>" hidden>
                                                <input name="confirm" value="true" hidden>
                                                <button type="button"
                                                        class="ecp_button btn btn-block btn-lg btn-success rounded-0">
                                                    Подписать допуск
                                                </button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="tab-pane fade active show" id="all<?php echo e($filing->id); ?>">
                                <h5 class="row m-0">
                                    <p class="col-lg-4 text-black-50">Номер заявки:</p>
                                    <p class="col"><?php echo e($filing->id); ?></p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-4 text-black-50">Дата и время подачи заявки:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($filing->created_at)->format('d.m.Y H:i')); ?></p>
                                </h5>
                                <?php if($filing->profile->user_type == 0): ?>
                                    <h5 class="row m-0">
                                        <p class="col-lg-4 text-black-50">Полное название организации:</p>
                                        <p class="col"><?php echo e($filing->profile->full_title); ?></p>
                                    </h5>
                                <?php else: ?>
                                    <h5 class="row m-0">
                                        <p class="col-lg-4 text-black-50">ФИО:</p>
                                        <p class="col"><?php echo e($filing->profile->full_name); ?></p>
                                    </h5>
                                <?php endif; ?>
                                <h5 class="row m-0">
                                    <p class="col-lg-4 text-black-50">ИНН:</p>
                                    <p class="col"><?php echo e($filing->profile->inn); ?></p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-4 text-black-50">Контактный телефон:</p>
                                    <p class="col"><?php echo e($filing->profile->phone); ?></p>
                                </h5>
                            </div>
                            <div class="tab-pane fade" id="docs<?php echo e($filing->id); ?>">
                                <?php $__currentLoopData = $filing->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <strong>
                                        <div class="row">
                                            <div class="col">
                                                <a target="_blank" class="col-lg-7" target="_blank"
                                                   href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                                    <?php echo e($doc->file_name); ?>

                                                </a>
                                            </div>
                                            <div class="col-auto">
                                                <?php if($doc->sign): ?>
                                                    ПОДПИСАН ЭП
                                                <?php else: ?>
                                                    НЕ ПОДПИСАНО
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </strong>
                                    <hr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo $__env->make('layouts.ecp-modal', ['title' => 'Подтверждаю свои действия , согласно регламенту ЭТП.', 'submit' => 'Отправить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/bagraining.blade.php ENDPATH**/ ?>