<?php $__env->startSection('title', __('app.projects_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                <?php echo e(__('app.projects_title')); ?> <i class="fa fa-angle-left"></i> <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.projects1')); ?></a>
            </div>
            <h1><?php echo e(__('app.projects_title')); ?></h1>
        </div>
        <div class="projects-top-menu">
            <ul>
                <li><a class="a1 active"><?php echo e(__('app.projects2')); ?></a></li>
                <li><a class="a2"><?php echo e(__('app.projects3')); ?></a></li>
            </ul>
        </div>
    </div>
    <div class="projects-page flex2 p2">
        <?php if(isset($projects[1])): ?>
            <?php $__currentLoopData = $projects[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="main-info">
                        <div class="flex">
                            <div class="date">
                                ID <?php echo e($project->id); ?>

                                <span><?php echo e(\Illuminate\Support\Carbon::parse($project->created_at)->format('d.m.Y H:i')); ?></span>
                            </div>
                            <div class="views">
                                <?php echo e($project->views); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(route('projects', ['proj' => $project->id])); ?>"
                           class="name"><?php echo e($project->title); ?></a>
                        <p class="ellipsis"><?php echo e($project->text); ?></p>
                    </div>
                    <div class="button flex">
                        <?php if(isset($project->responses) and $project->responses->count() > 0): ?>
                            <div class="count">
                                <?php if($project->responses->where('status', 0)->count() > 0): ?>
                                    <span>+ <?php echo e($project->responses->where('status', 0)->count()); ?></span>
                                <?php endif; ?>
                                <?php echo e($project->responses->count()); ?><a
                                    href="<?php echo e(route('projects', ['proj' => $project->id])); ?>"><?php echo e(__('app.projects4')); ?></a>
                            </div>
                        <?php else: ?>
                            <div class="count no2">
                                <?php echo e(__('app.projects5')); ?>

                            </div>
                        <?php endif; ?>
                        <div>
                            <a class="edit" href="<?php echo e(route('new_project', ['project' => $project->id])); ?>"></a>
                            <a class="trash" href="<?php echo e(route('projects', ['return' => $project->id])); ?>"></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    <div class="projects-page p1 active flex2">
        <?php if(isset($projects[0])): ?>
            <?php $__currentLoopData = $projects[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="main-info">
                        <div class="flex">
                            <div class="date">
                                ID <?php echo e($project->id); ?>

                                <span><?php echo e(\Illuminate\Support\Carbon::parse($project->created_at)->format('d.m.Y H:i')); ?></span>
                            </div>
                            <div class="views">
                                <?php echo e($project->views); ?>

                            </div>
                        </div>
                        <a href="<?php echo e(route('projects', ['proj' => $project->id])); ?>"
                           class="name"><?php echo e($project->title); ?></a>
                        <p class="ellipsis"><?php echo e($project->text); ?></p>
                    </div>
                    <div class="button flex">
                        <?php if(isset($project->responses) and $project->responses->count() > 0): ?>
                            <div class="count">
                                <?php if($project->responses->where('status', 0)->count() > 0): ?>
                                    <span>+ <?php echo e($project->responses->where('status', 0)->count()); ?></span>
                                <?php endif; ?>
                                <?php echo e($project->responses->count()); ?><a
                                    href="<?php echo e(route('projects', ['proj' => $project->id])); ?>"><?php echo e(__('app.projects4')); ?></a>
                            </div>
                        <?php else: ?>
                            <div class="count no2">
                                <?php echo e(__('app.projects5')); ?>

                            </div>
                        <?php endif; ?>
                        <div>
                            <a class="edit" href="<?php echo e(route('new_project', ['project' => $project->id])); ?>"></a>
                            <a class="trash" href="<?php echo e(route('projects', ['delete' => $project->id])); ?>"></a>
                            <a href="<?php echo e(route('requested', ['project' => $project->id])); ?>">
                                <button><span></span> <?php echo e(__('app.projects6')); ?></button>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/projects.blade.php ENDPATH**/ ?>