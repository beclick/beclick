<?php $__env->startSection('title', 'Лоты – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-between align-items-start">
            <div class="col-lg-3">
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-white text-black-50 text-center pt-4 pb-3">
                        <h5><strong>Фильтр имущества</strong></h5>
                    </div>
                    <div class="card-body">
                        <form novalidate method="get" action="<?php echo e(route('home')); ?>">
                            <div class="form-group">
                                <select class="custom-select custom-select-lg rounded-0" name="type">
                                    <option value="null">Виды торгов</option>
                                    <option value="1" <?php if($request->type == 1): ?> selected <?php endif; ?>>
                                        Имущество должников
                                    </option>
                                    <option value="2" <?php if($request->type == 2): ?> selected <?php endif; ?>>
                                        Государственное и муниципальное имущество
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="custom-select custom-select-lg rounded-0" name="category">
                                    <option value="null">Категория лота</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"
                                                <?php if($request->category == $category->id): ?> selected <?php endif; ?>><?php echo e($category->category); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="custom-select custom-select-lg rounded-0" name="status">
                                    <option value="null">Статус торгов</option>
                                    <option value="1" <?php if($request->status == 1): ?> selected <?php endif; ?>>
                                        Прием завок не начался
                                    </option>
                                    <option value="2" <?php if($request->status == 2): ?> selected <?php endif; ?>>
                                        Идет прием заявок
                                    </option>
                                    <option value="3" <?php if($request->status == 3): ?> selected <?php endif; ?>>
                                        Прием заявок завершен
                                    </option>
                                    <option value="4" <?php if($request->status == 4): ?> selected <?php endif; ?>>
                                        Идут торги по лоту
                                    </option>
                                    <option value="5" <?php if($request->status == 5): ?> selected <?php endif; ?>>
                                        Торги по лоту состоялись
                                    </option>
                                    <option value="6" <?php if($request->status == 6): ?> selected <?php endif; ?>>
                                        Торги по лоту не состоялись
                                    </option>
                                    <option value="7" <?php if($request->status == 7): ?> selected <?php endif; ?>>
                                        Лот приостановлен
                                    </option>
                                    <option value="8" <?php if($request->status == 8): ?> selected <?php endif; ?>>
                                        Лот аннулирован
                                    </option>
                                </select>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg rounded-0" name="min_price"
                                       <?php if(isset($request->min_price)): ?> value="<?php echo e($request->min_price); ?>"
                                       <?php endif; ?> placeholder="Минимальная начальная стоимость">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg rounded-0" name="max_price"
                                       <?php if(isset($request->max_price)): ?> value="<?php echo e($request->max_price); ?>"
                                       <?php endif; ?> placeholder="Максимальная начальная стоимость">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg rounded-0" name="debtor"
                                       <?php if(isset($request->debtor)): ?> value="<?php echo e($request->debtor); ?>"
                                       <?php endif; ?> placeholder="Должник/Владелец">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-block btn-lg btn-primary rounded-0" type="submit">Найти</button>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(route('home')); ?>" class="btn btn-block btn-lg btn-primary rounded-0">Сбросить
                                    фильтры</a>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href="http://1c.lavrov.online" target="_blank">
                            <img style="position: relative; margin-top: 20px; width: 100%"
                                 src="<?php echo e(asset('img/ads.svg')); ?>">
                        </a>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <a href="<?php echo e(route('contacts')); ?>" target="_blank">
                            <img style="position: relative; margin-top: 20px; width: 100%"
                                 src="<?php echo e(asset('img/ads.svg')); ?>">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg">
                <?php if(!$lots->isEmpty()): ?>
                    <?php $__currentLoopData = $lots[$page]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card rounded-0 shadow">
                            <div class="card-header bg-light text-black-50">
                                <h5><strong><a class="card-link text-dark"
                                               href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->name); ?></a></strong>
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg">
                                        <h5 class="text-black-50">Начальная цена</h5>
                                        <h3><?php echo e(number_format($lot->start_price / 100, 2, '.', '')); ?> ₽</h3>
                                    </div>
                                    <div class="col-lg">
                                        <h5 class="text-black-50">Задаток</h5>
                                        <h3><?php echo e(number_format($lot->deposit_price / 100, 2, '.', '')); ?> ₽</h3>
                                    </div>
                                    <div class="col-lg-4">
                                        <?php if($lot->status == 1): ?>
                                            <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?>
                                                <a href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                                   class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                    Торги по лоту состоялись, посмотреть результаты
                                                </a>
                                            <?php else: ?>
                                                <a class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                    Торги по лоту состоялись
                                                </a>
                                            <?php endif; ?>
                                        <?php elseif($lot->status == 2): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">
                                                Торги по лоту не состоялись
                                            </a>
                                        <?php elseif($lot->status == 3): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-warning rounded-0">
                                                Приостановлен
                                            </a>
                                        <?php elseif($lot->status == 4): ?>
                                            <a class="h-100 btn btn-block btn-lg btn-danger rounded-0">
                                                Аннулирован
                                            </a>
                                        <?php elseif($lot->auction->status > 0): ?>
                                            <?php if(strtotime(date('Y-m-d H:i:s')) <= strtotime($lot->start_request)): ?>
                                                <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                    Опубликован
                                                </a>
                                            <?php elseif(strtotime($lot->start_request) <= strtotime(date('Y-m-d H:i:s')) and strtotime(date('Y-m-d H:i:s')) < strtotime($lot->end_request)): ?>
                                                <?php if(isset($my_profile) and $my_profile->user_role == 1): ?>
                                                    <a href="<?php echo e(route('filing', ['lot' => $lot->id])); ?>"
                                                       class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                        Подать заявку
                                                    </a>
                                                <?php else: ?>
                                                    <a class="h-100 btn btn-block btn-lg btn-primary rounded-0">
                                                        Идёт приём заявок
                                                    </a>
                                                <?php endif; ?>
                                            <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s'))): ?>
                                                <a target="_blank" <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                                   <?php endif; ?> class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                    Идут торги
                                                </a>
                                            <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i:s')) + 900): ?>
                                                <a target="_blank" <?php if((isset($my_profile) and $my_profile->id == $lot->profile_id) or (isset($my_profile) and $my_profile->user_role == 1)): ?> href="<?php echo e(route('auction_hall', ['lot' => $lot->id])); ?>"
                                                   <?php endif; ?> class="h-100 btn btn-block btn-lg btn-success rounded-0">
                                                    Торги начнутся
                                                    через <?php echo e(floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 60) - (floor((strtotime($lot->start_auction) - strtotime(date('Y-m-d H:i:s'))) / 3600) * 60)); ?>

                                                    минут
                                                </a>
                                            <?php elseif(strtotime($lot->end_request) <= strtotime(date('Y-m-d H:i:s')) and strtotime(date('Y-m-d H:i:s')) < strtotime($lot->start_auction)): ?>
                                                <a class="h-100 btn btn-block btn-lg btn-warning rounded-0">
                                                    Приём заявок завершен
                                                </a>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <hr>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Тип аукциона:</p>
                                    <p class="col">
                                        <?php if($lot->auction->type == 1): ?> Имущество должников <?php elseif($lot->auction->type == 2): ?> Государственное и муниципальное имущество <?php endif; ?>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Номер аукциона:</p>
                                    <p class="col">
                                        <a href="<?php echo e(route('auction', ['auction' => $lot->auction->id])); ?>"><?php echo e($lot->auction->id); ?></a>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Номер лота:</p>
                                    <p class="col">
                                        <a href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->num_lot); ?></a>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Дата начала приема заявок:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($lot->start_request)->format('d.m.Y H:i')); ?></p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Дата завершения приема заявок:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($lot->end_request)->format('d.m.Y H:i')); ?></p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Дата начала аукциона:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($lot->start_auction)->format('d.m.Y H:i')); ?></p>
                                </h5>
                            </div>
                        </div>
                        <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <div class="row container justify-content-center">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination">
                            <?php if($page >= 3): ?>
                                <li class="page-item">
                                    <a class="page-link"
                                       href="<?php echo e(route('home', ['category' => $request->category, 'status' => $request->status, 'min_price' => $request->min_price, 'max_price' => $request->max_price, 'debtor' => $request->debtor, 'page' => $page])); ?>"
                                       aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php for($i = 0; $i < $lots->count(); $i++): ?>
                                <?php if($i >= $page - 2 and $i <= $page + 2): ?>
                                    <li class="page-item <?php if($page == $i): ?> active <?php endif; ?>"><a
                                            class="page-link"
                                            href="<?php echo e(route('home', ['category' => $request->category, 'status' => $request->status, 'min_price' => $request->min_price, 'max_price' => $request->max_price, 'debtor' => $request->debtor, 'page' => $i + 1])); ?>"><?php echo e($i + 1); ?></a>
                                    </li>
                                <?php endif; ?>
                            <?php endfor; ?>
                            <?php if($page < $lots->count() - 2): ?>
                                <li class="page-item">
                                    <a class="page-link"
                                       href="<?php echo e(route('home', ['category' => $request->category, 'status' => $request->status, 'min_price' => $request->min_price, 'max_price' => $request->max_price, 'debtor' => $request->debtor, 'page' => $page + 2])); ?>"
                                       aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/home.blade.php ENDPATH**/ ?>