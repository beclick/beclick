<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link href="<?php echo e(asset('style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
</head>
<body class="lp">
<div class="login-page">
    <div class="content">
        <div class="logo">
            <img src="<?php echo e(asset('img/logo.svg')); ?>">
        </div>
        <div class="top-text">
            <?php if(session('resent')): ?>
                <?php echo e(__('auth.verification_link_sent_email')); ?>

            <?php else: ?>
                <?php echo e(__('auth.verify_your_email')); ?>

            <?php endif; ?>
        </div>
        <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
            <?php echo csrf_field(); ?>
            <button type="submit"><?php echo e(__('auth.click_request_another')); ?></button>
        </form>
    </div>
    <div class="bottom-block">
    </div>
    <div class="copy">
        <p><?php echo e(trans('app.all_rights_reserved')); ?></p>
        <a href="#"><?php echo e(trans('app.privacy_policy')); ?></a>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/auth/verify.blade.php ENDPATH**/ ?>