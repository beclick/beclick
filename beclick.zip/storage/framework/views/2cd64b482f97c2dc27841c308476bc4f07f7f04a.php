<?php echo e($slot); ?>

<?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>