<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="js/common.js"></script>
</head>
<body class="lp">
<div class="login-page">
    <div class="content">
        <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="logo">
                <img src="img/logo.svg">
            </div>
            <div class="top-text">
                Введите ваш e-mail и пароль для доступа к сайту
            </div>
            <div class="field-name">
                E-mail
            </div>
            <input type="text" placeholder="Введите ваш e-mail" name="email"
                   value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="field-name">
                Пароль
            </div>
            <div class="pass">
                <a class="show-pass"></a>
                <input type="password" placeholder="Введите ваш пароль" name="password"
                       required autocomplete="current-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="agree">
                <input type="checkbox" class="checkbox" id="agree"><label for="agree">Запомнить меня</label>
            </div>
            <button type="submit">Войти</button>
            <div class="or">
                или
            </div>
            <a href="#" class="google-login">
                <img src="img/google.png"> Войти через Google
            </a>
        </form>
    </div>
    <div class="bottom-block">
        <p>?Забыли пароль</p>
        Нет аккаунта? <a href="<?php echo e(route('register')); ?>">Зарегистрироваться</a>
    </div>
    <div class="copy">
        <p><?php echo e(trans('app.all_rights_reserved')); ?></p>
        <a href="#"><?php echo e(trans('app.privacy_policy')); ?></a>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\beclick\resources\views/auth/login.blade.php ENDPATH**/ ?>