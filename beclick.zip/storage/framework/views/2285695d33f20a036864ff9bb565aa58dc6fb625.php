<?php $__env->startSection('title', __('app.edit_prof_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                <?php echo e(__('app.edit_prof1')); ?> <i class="fa fa-angle-left"></i> <a href="<?php echo e(route('profile')); ?>"><?php echo e(__('app.edit_prof1')); ?></a> <i
                    class="fa fa-angle-left"></i> <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.edit_prof3')); ?></a>
            </div>
            <h1><?php echo e(__('app.edit_prof4')); ?></h1>
        </div>
        <?php if(isset($profile->id)): ?>
            <div class="subscribe-block">
                <?php if(isset($profile->subscription)): ?>
                    <div class="date">
                        <?php echo e(__('app.edit_prof5')); ?>

                        <span><?php echo e(\Illuminate\Support\Carbon::parse($profile->subscription)->format('d.m.Y H:i')); ?></span>
                    </div>
                <?php endif; ?>
                <a href="<?php echo e(route('payment')); ?>">
                    <button><span></span> <?php echo e(__('app.edit_prof6')); ?></button>
                </a>
            </div>
        <?php endif; ?>
    </div>
    <div class="profile-page">
        <div class="steps">
            <ul>
                <li><a class="s1 active"><?php echo e(__('app.edit_prof7')); ?></a></li>
                <li><a class="s2"><?php echo e(__('app.edit_prof8')); ?></a></li>
                <li><a class="s3"><?php echo e(__('app.edit_prof9')); ?></a></li>
            </ul>
        </div>
        <div class="mob-steps">
            <div class="step s1"><?php echo e(__('app.edit_prof7')); ?></div>
            <div class="step s2"><?php echo e(__('app.edit_prof8')); ?></div>
            <div class="step s3"><?php echo e(__('app.edit_prof9')); ?></div>
        </div>
        <form id="edit-form" method="POST" action="<?php echo e(route('profile.edit')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="content c1 active">
                <div class="flex">
                    <div class="photo">
                        <div id="upload_image" class="upload"
                             style="<?php if(isset($profile->image)): ?> background-image:  url(<?php echo e(asset('storage/' . $profile->image)); ?>);  <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                            <label>
                                <span id="logo"><?php echo e(__('app.edit_prof10')); ?></span>
                                <input type="file" id="image" accept="image/jpeg,image/png" hidden
                                       autocomplete="off">
                            </label>
                        </div>
                        <p><?php echo e(__('app.edit_prof11')); ?></p>
                        <p><?php echo e(__('app.edit_prof12')); ?></p>
                    </div>
                    <div class="fields">
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof13')); ?>

                        </div>
                        <div class="field">
                            <input class="inp" name="name" type="text"
                                   value="<?php if(isset($profile->name)): ?> <?php echo e($profile->name); ?> <?php endif; ?>" autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof14')); ?>

                        </div>
                        <div class="field">
                            <input class="inp" name="address" type="text"
                                   value="<?php if(isset($profile->address)): ?> <?php echo e($profile->address); ?> <?php endif; ?>"
                                   autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof15')); ?>

                        </div>
                        <div class="field">
                            <input class="inp ltr" name="phone_whatsapp" type="text"
                                   value="<?php if(isset($profile->phone_whatsapp)): ?> <?php echo e($profile->phone_whatsapp); ?> <?php endif; ?>"
                                   autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof16')); ?>

                        </div>
                        <div class="field">
                            <input class="inp ltr" name="email" type="text"
                                   value="<?php if(isset($profile->email)): ?> <?php echo e($profile->email); ?> <?php endif; ?>" autocomplete="off">
                        </div>
                        <div class="line"></div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name1.svg')); ?>"> <?php echo e(__('app.edit_prof17')); ?>

                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof18')); ?>

                        </div>
                        <div class="field">
                            <select id="category" name="category" autocomplete="off">
                                <?php if(!isset($profile->category_id)): ?>
                                    <option value="" class="op_f">-------</option>
                                <?php endif; ?>
                                <?php if(isset($categories)): ?>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($category->id); ?>"
                                                <?php if(isset($profile->category_id) and $profile->category_id == $category->id): ?> selected <?php endif; ?>><?php echo e($category->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="link">
                            <a id="add_category"><?php echo e(__('app.edit_prof19')); ?></a>
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof20')); ?>

                        </div>
                        <div class="field">
                            <select id="subcategory" name="subcategory" autocomplete="off">
                            </select>
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof21')); ?>

                        </div>
                        <div class="field">
                            <select name="specialization_id" autocomplete="off">
                                <?php if(!isset($profile->specialization_id)): ?>
                                    <option value="" class="op_f">-------</option>
                                <?php endif; ?>
                                <?php if(isset($specializations)): ?>
                                    <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($specialization->id); ?>"
                                                <?php if(isset($profile->specialization_id) and $profile->specialization_id == $specialization->id): ?> selected <?php endif; ?>><?php echo e($specialization->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof22')); ?>

                        </div>
                        <div class="field">
                            <input class="inp" name="specialization" type="text"
                                   value="<?php if(isset($profile->specialization_list)): ?> <?php echo e($profile->specialization_list); ?> <?php endif; ?>" autocomplete="off">
                        </div>
                        <div class="line"></div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name2.svg')); ?>"> <?php echo e(__('app.edit_prof23')); ?>

                        </div>
                        <div id="upload_pdf" class="upload">
                            <label>
                                <span><?php echo e(__('app.edit_prof24')); ?></span>
                                <input type="file" id="pdf" accept="application/pdf" hidden
                                       autocomplete="off">
                            </label>
                        </div>
                        <div class="files">
                            <div id="pdf_file" class="item" <?php if(!isset($profile->pdf)): ?> style="display: none" <?php endif; ?>>
                                <?php if(isset($profile->pdf)): ?>
                                    <a target="_blank" href="<?php echo e(asset('storage/' . $profile->pdf)); ?>"><img
                                            src="<?php echo e(asset('img/pdf.svg')); ?>"><?php echo e(__('app.edit_prof25')); ?></a><a
                                        class="delete"></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="att">
                            <div class="name">
                                <?php echo e(__('app.edit_prof26')); ?>

                            </div>
                            <?php echo __('app.edit_prof27'); ?>

                        </div>
                        <div class="button">
                            <button type="button" class="n"><?php echo e(__('app.edit_prof28')); ?> <span></span></button>
                            <a href="" onclick="event.preventDefault(); document.getElementById('edit-form').submit();"><?php echo e(__('app.edit_prof29')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content c2 other">
                <div class="flex">
                    <div class="fields big">
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof30')); ?>

                        </div>
                        <div class="field">
                            <input class="inp" name="contact_person" type="text"
                                   value="<?php if(isset($profile->contact_person )): ?> <?php echo e($profile->contact_person); ?> <?php endif; ?>"
                                   autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof31')); ?>

                        </div>
                        <div class="field flex">
                            <input class="inp tel2 ltr" name="contact_phone" type="text"
                                   value="<?php if(isset($profile->contact_phone )): ?> <?php echo e($profile->contact_phone); ?> <?php endif; ?>"
                                   autocomplete="off">
                            <input class="inp tel1 ltr" name="contact_phone_d" type="text" placeholder="<?php echo e(__('app.items6')); ?>"
                                   value="<?php if(isset($profile->contact_phone_d )): ?> <?php echo e($profile->contact_phone_d); ?> <?php endif; ?>"
                                   autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof32')); ?>

                        </div>
                        <div class="field">
                            <input class="inp ltr" name="telegram" type="text"
                                   value="<?php if(isset($profile->telegram )): ?> <?php echo e($profile->telegram); ?> <?php endif; ?>"
                                   autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof33')); ?>

                        </div>
                        <div class="field">
                            <input class="inp ltr" name="viber" type="text"
                                   value="<?php if(isset($profile->viber )): ?> <?php echo e($profile->viber); ?> <?php endif; ?>" autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof34')); ?>

                        </div>
                        <div class="field">
                        <textarea class="inp" name="description"
                                  placeholder="<?php echo e(__('app.edit_prof35')); ?>"><?php if(isset($profile->description )): ?> <?php echo e($profile->description); ?> <?php endif; ?></textarea>
                        </div>
                        <div class="line"></div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name3.svg')); ?>"> <?php echo e(__('app.edit_prof36')); ?>Регионы оказания услуг
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof37')); ?>

                        </div>
                        <div class="regions">
                            <div class="item">
                                <input name="regions[]" type="checkbox" class="checkbox reg" value="<?php echo e(__('app.all_israile')); ?>"
                                       id="chf"
                                       <?php if(isset($project->regions) and isset(explode('|', $profile->regions)[1]) and explode('|', $profile->regions)[1] == __('app.all_israile')): ?> checked
                                       <?php endif; ?> autocomplete="off"><label
                                    for="chf"><?php echo e(__('app.all_israile')); ?></label>
                            </div>
                            <?php $__currentLoopData = $regions[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <a class="link"><i class="fa fa-angle-left"></i></a>
                                    <input type="checkbox" class="checkbox" id="ch<?php echo e($region->id); ?>" autocomplete="off">
                                    <label for="ch<?php echo e($region->id); ?>"><?php echo e($region->title); ?></label>
                                    <div class="list">
                                        <?php if(isset($regions[$region->id])): ?>
                                            <?php $__currentLoopData = $regions[$region->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input name="regions[]" type="checkbox" class="checkbox"
                                                       id="ch<?php echo e($reg->id); ?>" value="<?php echo e($reg->title); ?>"
                                                       <?php if(isset($profile->regions) and in_array($reg->title, explode('|', $profile->regions))): ?> checked
                                                       <?php endif; ?> autocomplete="off">
                                                <label
                                                    for="ch<?php echo e($reg->id); ?>"><?php echo e($reg->title); ?></label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="line"></div>
                        <div class="button">
                            <a class="next"></a>
                            <button type="button" class="n"><?php echo e(__('app.edit_prof28')); ?> <span></span></button>
                            <a href="" onclick="event.preventDefault(); document.getElementById('edit-form').submit();"><?php echo e(__('app.edit_prof29')); ?></a> <a class="prev"><?php echo e(__('app.edit_prof291')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content c3 other">
                <div class="flex">
                    <div class="fields big">
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof38')); ?>

                        </div>
                        <div class="field">
                            <input class="inp ltr" name="site" type="text"
                                   value="<?php if(isset($profile->site )): ?> <?php echo e($profile->site); ?> <?php endif; ?>" autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof39')); ?>

                        </div>
                        <div class="field">
                            <select name="experience" autocomplete="off">
                                <option value="">-------</option>
                                <?php $__currentLoopData = $exps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($exp->title); ?>"
                                            <?php if(isset($profile->experience) and $profile->experience == $exp->title): ?> selected <?php endif; ?>><?php echo e($exp->title); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.edit_prof40')); ?>

                        </div>
                        <div class="field">
                            <select name="amountworkers" autocomplete="off">
                                <option value="">-------</option>
                                <?php $__currentLoopData = $amounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($amount->title); ?>"
                                            <?php if(isset($profile->amountworkers) and $profile->amountworkers == $amount->title): ?> selected <?php endif; ?>><?php echo e($amount->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="line"></div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name4.svg')); ?>"> <?php echo e(__('app.edit_prof41')); ?>

                        </div>
                        <div class="regions">
                            <?php $__currentLoopData = $others[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <a class="link"><i class="fa fa-angle-left"></i></a>
                                    <input type="checkbox" class="checkbox" name="others[]"
                                           value="<><?php echo e($other->title); ?>" id="ot<?php echo e($other->id); ?>" autocomplete="off">
                                    <label for="ot<?php echo e($other->id); ?>"><?php echo e($other->title); ?></label>
                                    <div class="list">
                                        <?php if(isset($others[$other->id])): ?>
                                            <?php $__currentLoopData = $others[$other->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $oth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input name="others[]" type="checkbox" class="checkbox"
                                                       id="ot<?php echo e($oth->id); ?>" value="<?php echo e($oth->title); ?>"
                                                       <?php if(isset($profile->others) and in_array($oth->title, explode('|', $profile->others))): ?> checked
                                                       <?php endif; ?> autocomplete="off">
                                                <label
                                                    for="ot<?php echo e($oth->id); ?>"><?php echo e($oth->title); ?></label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="link other">
                            <a id="add_cert"><?php echo e(__('app.edit_prof42')); ?></a>
                        </div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name5.svg')); ?>"> <?php echo e(__('app.edit_prof43')); ?>

                        </div>
                        <div class="line"></div>
                        <div class="time-select">
                            <input type="checkbox" class="checkbox timeinp" id="time1" name="time1"
                                   <?php if(isset($profile->mode_week)): ?> checked <?php endif; ?> autocomplete="off">
                            <label for="time1">
                                <div class="pre"><?php echo e(__('app.edit_prof44')); ?></div>
                                <label <?php if(!isset($profile->mode_week)): ?> style="display: none" <?php endif; ?>>
                                    <select name="starttime1" autocomplete="off">
                                        <?php for($i=6; $i<21; $i++): ?>
                                            <option
                                                value="<?php echo e(substr('0' . $i, -2) . ':00'); ?>"
                                                <?php if(isset($profile->mode_week) and explode('|', $profile->mode_week)[0] == substr('0' . $i, -2) . ':00'): ?> selected <?php endif; ?>><?php echo e(substr('0' . $i, -2) . ':00'); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <span>—</span>
                                    <select name="endtime1" autocomplete="off">
                                        <?php for($i=6; $i<21; $i++): ?>
                                            <option
                                                value="<?php echo e(substr('0' . $i, -2) . ':00'); ?>"
                                                <?php if(isset($profile->mode_week) and explode('|', $profile->mode_week)[1] == substr('0' . $i, -2) . ':00'): ?> selected <?php endif; ?>><?php echo e(substr('0' . $i, -2) . ':00'); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </label>
                            </label>
                            <input type="checkbox" class="checkbox timeinp" id="time2" name="time2"
                                   <?php if(isset($profile->mode_sat)): ?> checked <?php endif; ?> autocomplete="off">
                            <label for="time2">
                                <div class="pre"><?php echo e(__('app.edit_prof45')); ?></div>
                                <label <?php if(!isset($profile->mode_sat)): ?> style="display: none" <?php endif; ?>>
                                    <select name="starttime2" autocomplete="off">
                                        <?php for($i=6; $i<21; $i++): ?>
                                            <option
                                                value="<?php echo e(substr('0' . $i, -2) . ':00'); ?>"
                                                <?php if(isset($profile->mode_sat) and explode('|', $profile->mode_sat)[0] == substr('0' . $i, -2) . ':00'): ?> selected <?php endif; ?>><?php echo e(substr('0' . $i, -2) . ':00'); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                    <span>—</span>
                                    <select name="endtime2" autocomplete="off">
                                        <?php for($i=6; $i<21; $i++): ?>
                                            <option
                                                value="<?php echo e(substr('0' . $i, -2) . ':00'); ?>"
                                                <?php if(isset($profile->mode_sat) and explode('|', $profile->mode_sat)[1] == substr('0' . $i, -2) . ':00'): ?> selected <?php endif; ?>><?php echo e(substr('0' . $i, -2) . ':00'); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </label>
                            </label>
                            <input type="checkbox" class="checkbox" id="time3" name="time3"
                                   <?php if(isset($profile->mode_alw) and $profile->mode_alw == 1): ?> checked
                                   <?php endif; ?> autocomplete="off">
                            <label for="time3">
                                <div class="pre"><?php echo e(__('app.edit_prof46')); ?></div>
                            </label>
                        </div>
                        <div class="shabbat">
                            <input type="checkbox" class="checkbox" id="time4" name="time4"
                                   <?php if(isset($profile->shabat) and $profile->shabat == 1): ?> checked
                                   <?php endif; ?> autocomplete="off">
                            <label for="time4">
                                <?php echo e(__('app.edit_prof47')); ?>

                            </label>
                        </div>
                        <div class="line"></div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name6.svg')); ?>"> <?php echo e(__('app.edit_prof48')); ?>

                        </div>
                        <div id="upload_reviews" class="upload">
                            <label>
                                <span><?php echo e(__('app.edit_prof49')); ?></span>
                                <input type="file" id="reviews" accept="application/pdf" hidden
                                       autocomplete="off" multiple>
                            </label>
                        </div>
                        <div id="reviews_files" class="files">
                            <?php if(isset($profile->reviews)): ?>
                                <?php $__currentLoopData = $profile->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="item">
                                        <a data-caption="<?php echo e($review->file_name); ?>" data-fancybox="reviews"
                                           href="<?php echo e(asset('storage/' . $review->path)); ?>">
                                            <img src="<?php echo e(asset('img/pdf.svg')); ?>">
                                            <span><?php echo e($review->file_name); ?></span>
                                        </a>
                                        <a class="delete review_del"></a>
                                        <input value="<?php echo e($review->id); ?>" hidden autocomplete="off">
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <div class="att">
                            <div class="name">
                                <?php echo e(__('app.edit_prof26')); ?>

                            </div>
                            <?php echo __('app.edit_prof50'); ?>

                        </div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name7.svg')); ?>"> <?php echo e(__('app.edit_prof51')); ?>

                        </div>
                        <div id="upload_gallery" class="upload">
                            <label>
                                <span><?php echo e(__('app.edit_prof52')); ?></span>
                                <input type="file" id="gallery" accept="image/jpeg,image/png" hidden
                                       autocomplete="off" multiple>
                            </label>
                        </div>
                        <div class="att other">
                            <?php echo __('app.edit_prof53'); ?>

                        </div>
                        <div class="uploaded">
                            <p><?php echo e(__('app.edit_prof54')); ?></p>
                            <div id="gallery_files" class="flex2">
                                <?php if(isset($profile->images)): ?>
                                    <?php $__currentLoopData = $profile->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="item">
                                            <a data-caption="<?php echo e($image->file_name); ?>" data-fancybox="gallery"
                                               href="<?php echo e(asset('storage/' . $image->path)); ?>">
                                                <img src="<?php echo e(asset('storage/' . $image->path)); ?>">
                                            </a>
                                            <a class="image_del"><strong><?php echo e(__('app.edit_prof55')); ?></strong></a>
                                            <p><?php echo e($image->file_name); ?></p>
                                            <input value="<?php echo e($image->id); ?>" hidden autocomplete="off">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="button">
                            <a href="#" class="next"></a>
                            <button type="submit" class="finish"><span></span> <?php echo e(__('app.edit_prof56')); ?></button>
                            <a class="prev other"><?php echo e(__('app.edit_prof291')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <div class="popup cat">
        <div class="window">
            <a class="close"></a>
            <p><?php echo e(__('app.add_new_work_category')); ?></p>
            <div class="field-name">
                <?php echo e(__('app.name_of_category')); ?>

            </div>
            <input id="title" type="text" placeholder="<?php echo e(__('app.enter_the_title')); ?>">
            <textarea id="text" placeholder="<?php echo e(__('app.describe_added_category')); ?>"></textarea>
            <button id="send_category"><?php echo e(__('app.response')); ?></button>
        </div>
    </div>

    <div class="popup cert">
        <div class="window">
            <a class="close"></a>
            <p><?php echo e(__('app.edit_prof57')); ?></p>
            <div class="field-name">
                <?php echo e(__('app.edit_prof58')); ?>

            </div>
            <input id="title" type="text" placeholder="<?php echo e(__('app.enter_the_title')); ?>">
            <textarea id="text" placeholder="<?php echo e(__('app.edit_prof59')); ?>"></textarea>
            <button id="send_cert"><?php echo e(__('app.edit_prof60')); ?></button>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('#send_category').click(function () {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?need=Category" + '&title=' + $(this).siblings('#title').val() + '&text=' + $(this).siblings('#text').val(),
                }).done(function (data) {
                    $('.popup.cat').find('.close').click();
                    show_alert(data);
                });
            });

            $('#send_cert').click(function () {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?need=Sertificat" + '&title=' + $(this).siblings('#title').val() + '&text=' + $(this).siblings('#text').val(),
                }).done(function (data) {
                    $('.popup.cat').find('.close').click();
                    show_alert(data);
                });
            });

            $('#add_category').click(function () {
                $('.popup.cat').fadeIn();
            });
            $('#add_cert').click(function () {
                $('.popup.cert').fadeIn();
            });

            function get_sub(val) {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?get_sub=" + val,
                }).done(function (data) {
                    $('#subcategory').html(data);
                });
            }

            $('.list').each(function () {
                if ($(this).children('input:checked').length > 0) {
                    $(this).siblings('input').prop('checked', true);
                } else {
                    $(this).siblings('input').prop('checked', false);
                }
            });
            <?php if(isset($profile->category_id)): ?>
            get_sub(<?php echo e($profile->category_id); ?>);
            <?php endif; ?>
            $('#category').change(function () {
                get_sub($(this).val());
            });
            $('.list').children('input').change(function () {
                if ($(this).parent().children('input:checked').length > 0) {
                    $(this).parent().siblings('input').prop('checked', true);
                    $('#chf').prop('checked', false);
                } else {
                    $(this).parent().siblings('input').prop('checked', false);
                }
            });
            $('.list').prev().prev('input').change(function () {
                if ($(this).is(':checked')) {
                    $(this).next().next('.list').children('input').prop('checked', true);
                    $('#chf').prop('checked', false);
                } else {
                    $(this).next().next('.list').children('input').prop('checked', false);
                }
            });
            $('#chf').change(function () {
                if ($(this).is(':checked')) {
                    $(this).parent().parent().find('input').not(this).prop('checked', false);
                }
            });
            $('.timeinp').change(function () {
                if ($(this).prop('checked')) {
                    $(this).next('label').children('label').css('display', 'inline');
                } else {
                    $(this).next('label').children('label').css('display', 'none');
                }
            });
            $('.inp').on('input', function () {
                if ($(this).val() > '') {
                    $(this).parent('div').removeClass('bad').addClass('ok');
                } else {
                    $(this).parent('div').removeClass('ok').addClass('bad');
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/edit_profile.blade.php ENDPATH**/ ?>