<?php $__env->startSection('title', 'Заявки на участие – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Журнал заявок на участие в торгах по лотам</h3>
        <hr>
        <div class="row justify-content-between align-items-start">
            <div class="col-lg-3">
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-white text-black-50 text-center pt-4 pb-3">
                        <h5><strong>Фильтр</strong></h5>
                    </div>
                    <div class="card-body">
                        <form novalidate method="get" action="<?php echo e(route('bargaining')); ?>">
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg rounded-0" name="auction"
                                       <?php if(isset($request->auction)): ?> value="<?php echo e($request->auction); ?>"
                                       <?php endif; ?> placeholder="Номер аукциона">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control form-control-lg rounded-0" name="debtor"
                                       <?php if(isset($request->debtor)): ?> value="<?php echo e($request->debtor); ?>"
                                       <?php endif; ?> placeholder="Должник/Владелец">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-block btn-lg btn-primary rounded-0" type="submit">Найти</button>
                            </div>
                            <div class="form-group">
                                <a href="<?php echo e(route('bargaining')); ?>" class="btn btn-block btn-lg btn-primary rounded-0">Сбросить</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg">
                <?php $__currentLoopData = $lots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($lot->filings->where('status', '<', 3)->count() > 0 and strtotime($lot->end_request) <= strtotime(date('Y-m-d H:i'))): ?>
                        <div class="card rounded-0 shadow">
                            <div class="card-header bg-light text-black-50">
                                <h5><strong><a class="card-link text-dark"
                                               href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->name); ?></a></strong>
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg">
                                        <h5 class="text-black-50">Заявок</h5>
                                        <h3><?php echo e($lot->filings->where('status', '<', 3)->count()); ?></h3>
                                    </div>
                                    <div class="col-lg">
                                        <h5 class="text-black-50">Одобрено</h5>
                                        <h3><?php echo e($lot->filings->where('status', 1)->count()); ?></h3>
                                    </div>
                                    <div class="col-lg-4">
                                        <a class="h-100 btn btn-block btn-lg rounded-0 <?php if($lot->protocol->isEmpty()): ?> btn-danger <?php else: ?> btn-info <?php endif; ?>"
                                           href="<?php echo e(route('protocol-lot', ['protocol' => $lot->id])); ?>">
                                            <p>Журнал участников</p>
                                            <?php if($lot->protocol->isEmpty()): ?>
                                                Необходимо прикрепить протокол
                                            <?php else: ?>
                                                Протокол прикреплен
                                            <?php endif; ?>
                                        </a>
                                    </div>
                                    <div class="col-lg-3">
                                        <a class="h-100 btn btn-block btn-lg btn-warning rounded-0"
                                           href="<?php echo e(route('bargaining', ['lot' => $lot->id])); ?>">Перейти к
                                            заявкам</a>
                                    </div>
                                </div>
                                <hr>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Тип аукциона:</p>
                                    <p class="col">
                                        <?php if($lot->auction->type == 1): ?> Имущество должников <?php elseif($lot->auction->type == 2): ?> Муниципальное имущество <?php endif; ?>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Статус торгов:</p>
                                    <p class="col">
                                        <?php if($lot->status == 0): ?>
                                            <strong class="text-info">Прием заявок завершен</strong>
                                        <?php elseif($lot->status == 1): ?>
                                            <strong class="text-success">Торги по лоту состоялись</strong>
                                        <?php elseif($lot->status == 2): ?>
                                            <strong class="text-danger">Торги по лоту не состоялись</strong>
                                        <?php elseif($lot->status == 3): ?>
                                            <strong class="text-warning">Приостановлен</strong>
                                        <?php elseif($lot->status == 4): ?>
                                            <strong class="text-danger">Аннулирован</strong>
                                        <?php endif; ?>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Аукцион номер:</p>
                                    <p class="col">
                                        <a href="<?php echo e(route('auction', ['auction' => $lot->auction->id])); ?>"><?php echo e($lot->auction->id); ?></a>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Лот номер:</p>
                                    <p class="col">
                                        <a href="<?php echo e(route('home', ['lot' => $lot->id])); ?>"><?php echo e($lot->num_lot); ?></a>
                                    </p>
                                </h5>
                                <h5 class="row m-0">
                                    <p class="col-lg-7 text-black-50">Дата начала аукциона:</p>
                                    <p class="col"><?php echo e(\Illuminate\Support\Carbon::parse($lot->start_auction)->format('d.m.Y H:i')); ?></p>
                                </h5>
                            </div>
                        </div>
                        <br>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/bagraining-lots.blade.php ENDPATH**/ ?>