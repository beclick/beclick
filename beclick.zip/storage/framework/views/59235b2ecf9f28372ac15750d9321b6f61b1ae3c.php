<?php $__env->startSection('title', 'Вход в админку – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="card rounded-0 shadow">
                    <div class="card-header bg-light text-black-50 text-center">
                        <h4>Панель администратора</h4>
                    </div>
                    <div class="card-body">
                        <div class="form-group container">
                            <form method="POST" action="<?php echo e(route('admin.login')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="text" placeholder="Логин" class="form-control form-control-lg rounded-0" name="login" required autofocus autocomplete="off">
                                <br>
                                <input type="password" placeholder="Пароль" class="form-control form-control-lg rounded-0" name="password" required autocomplete="off">
                                <br>
                                <button class="btn btn-success btn-lg btn-block rounded-0" type="submit">Войти как администратор</button>
                                <br>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/login.blade.php ENDPATH**/ ?>