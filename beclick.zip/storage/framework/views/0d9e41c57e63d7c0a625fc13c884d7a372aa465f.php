<!doctype html>
<html dir="rtl" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/png">

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/common.js') . '?' . rand(0, 99999)); ?>"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
<?php echo $__env->yieldContent('script'); ?>
<!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('style.css') . '?' . rand(0, 99999)); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('slick.css')); ?>" rel="stylesheet">
</head>
<body>

<div class="wrap">
    <div class="flex">
        <div class="page-name">
            <div class="company">
                <div class="avatar"
                     style="width: 10rem; height: 10rem; <?php if(isset($profile->image)): ?> background-image: url(<?php echo e(asset('storage/' . $profile->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                </div>
                <div style="padding-right: 3rem">
                    <h1><?php if(isset($profile->name)): ?> <?php echo e($profile->name); ?> <?php endif; ?></h1>
                    <div class="links">
                        <a onclick="copytext('<?php echo e(route('company', ['id' => $profile->id])); ?>')">Скопировать ссылку</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="subscribe-block">
            <a href="<?php echo e(route('admin.home')); ?>">
                <button> Назад</button>
            </a>
            <a href="<?php echo e(route('admin.home', ['id' => $profile->id, 'advert' => 'true'])); ?>">
                <?php if($profile->advert == 0): ?>
                    <button> Рекламировать</button>
                <?php elseif($profile->advert == 1): ?>
                    <button> Отменить рекламу</button>
                <?php endif; ?>
            </a>
        </div>
    </div>
    <div class="company-mob-block">
        <div class="links">
            <a onclick="copytext('<?php echo e(route('company', ['id' => $profile->id])); ?>')"></a>
        </div>
        <?php if(isset($profile->pdf)): ?>
            <div class="pdf">
                <div><img src="<?php echo e(asset('img/pdf2.svg')); ?>"></div>
                <div><a data-fancybox="profile2" href="<?php echo e(asset('storage/' . $profile->pdf)); ?>">Посмотреть
                        расширенный профиль компании</a>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <div class="company-page flex">
        <div class="info">
            <div class="name">
                <img src="<?php echo e(asset('img/name8.svg')); ?>"> Контакты и адрес компании
            </div>
            <div class="block">
                <div class="flex">
                    <div class="col">
                        <div class="item">
                            <?php if(isset($profile->contact_phone)): ?>
                                Телефон компании
                                <span><?php echo e($profile->contact_phone); ?> <?php if(isset($profile->contact_phone_d)): ?>
                                        доп: <?php echo e($profile->contact_phone_d); ?> <?php endif; ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->phone_whatsapp)): ?>
                                Сотовый телефон / WhatsApp
                                <span><a class="wa" href=""><?php echo e($profile->phone_whatsapp); ?></a></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->telegram)): ?>
                                Telegram
                                <span><?php echo e($profile->telegram); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->viber)): ?>
                                Viber
                                <span><?php echo e($profile->viber); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col">
                        <div class="item">
                            <?php if(isset($profile->address)): ?>
                                Адрес
                                <span><?php echo e($profile->address); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->email)): ?>
                                Электронная почта
                                <span><a href="mailto:<?php echo e($profile->email); ?>"><?php echo e($profile->email); ?></a></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->contact_person)): ?>
                                Контактное лицо
                                <span><?php echo e($profile->contact_person); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="item">
                            <?php if(isset($profile->regions)): ?>
                                Регионы и город работы
                                <span>
                                    <?php $__currentLoopData = explode('|', $profile->regions); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->index > 0): ?>
                                            <p><?php echo e($region); ?></p>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="line"></div>
            <div class="name">
                <img src="<?php echo e(asset('img/name1.svg')); ?>"> Категория работы и специализация
            </div>
            <div class="block">
                <div class="item">
                    <?php if(isset($profile->category)): ?>
                        Категория
                        <span><?php echo e($profile->category->title); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->subcategory)): ?>
                        Подкатегория
                        <span><?php echo e($profile->subcategory->title); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->specialization) or isset($profile->specialization_list)): ?>
                        Специализация
                    <?php endif; ?>
                    <?php if(isset($profile->specialization)): ?>
                        <span><?php echo e($profile->specialization->title); ?></span>
                    <?php endif; ?>
                    <?php if(isset($profile->specialization_list)): ?>
                        <span><?php echo e($profile->specialization_list); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <div class="name">
                <img src="<?php echo e(asset('img/name1.svg')); ?>"> Публичные данные компании
            </div>
            <div class="block">
                <div class="item">
                    <?php if(isset($profile->description)): ?>
                        Описание компании
                        <span><?php echo e($profile->description); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->site)): ?>
                        Сайт компании
                        <span><a href="<?php echo e($profile->site); ?>"><?php echo e($profile->site); ?></a></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->experience)): ?>
                        Опыт работы
                        <span><?php echo e($profile->experience); ?></span>
                    <?php endif; ?>
                </div>
                <div class="item">
                    <?php if(isset($profile->amountworkers)): ?>
                        Количество работников
                        <span><?php echo e($profile->amountworkers); ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <?php if(isset($profile->others)): ?>
                <?php $__currentLoopData = explode('<>', $profile->others); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $others): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->index > 0 and isset($others)): ?>
                        <div class="name">
                            <img src="<?php echo e(asset('img/name4.svg')); ?>"><?php echo e(explode('|', $others)[0]); ?>

                        </div>
                        <div class="block">
                            <ul class="docs">
                                <?php if(isset($others)): ?>
                                    <?php $__currentLoopData = explode('|', $others); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->index > 0): ?>
                                            <li><?php echo e($other); ?></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="line"></div>
            <?php endif; ?>
            <div class="name">
                <img src="<?php echo e(asset('img/name5.svg')); ?>"> Режим работы
            </div>
            <div class="block">
                <div class="hours">
                    <?php if($profile->mode_alw == 1): ?>
                        <p> 24/7 </p>
                    <?php else: ?>
                        <p>
                            <?php if(isset($profile->mode_week)): ?>
                                ВС-ЧТ с <?php echo e(explode('|', $profile->mode_week)[0]); ?>

                                до <?php echo e(explode('|', $profile->mode_week)[1]); ?>

                            <?php endif; ?>
                        </p>
                        <p>
                            <?php if(isset($profile->mode_sat)): ?>
                                ПТ с <?php echo e(explode('|', $profile->mode_sat)[0]); ?>

                                до <?php echo e(explode('|', $profile->mode_sat)[1]); ?>

                            <?php endif; ?>
                        </p>
                    <?php endif; ?>
                    <?php if($profile->shabat == 1): ?>
                        <p>Недоступен в шаббат</p>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <div class="name">
                <img src="<?php echo e(asset('img/name7.svg')); ?>"> Галерея работ
            </div>
            <div class="block">
                <div class="gallery">
                    <?php $__currentLoopData = $profile->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <img src="<?php echo e(asset('storage/' . $image->path)); ?>">
                            <a data-caption="<?php echo e($image->file_name); ?>" data-fancybox="gallery"
                               href="<?php echo e(asset('storage/' . $image->path)); ?>"></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="info2">
            <div class="name">
                <img src="<?php echo e(asset('img/name9.svg')); ?>"> Статистика
            </div>
            <div class="block">
                <div class="item">
                    Дата регистрации
                    <span><?php echo e(\Illuminate\Support\Carbon::parse($profile->created_at)->format('d.m.Y')); ?></span>
                </div>
                <div class="item">
                    Создано проектов
                    <span><?php echo e($profile->num_proj); ?></span>
                </div>
                <div class="item">
                    Количество просмотров
                    <span><?php echo e($profile->views); ?></span>
                </div>
                <div class="item">
                    Время отклика
                    <?php if($profile->resp_time / $profile->resp_num < 60): ?>
                        <span>~<?php echo e(round($profile->resp_time / $profile->resp_num)); ?> минут</span>
                    <?php elseif($profile->resp_time / $profile->resp_num < 1440): ?>
                        <span>~<?php echo e(round($profile->resp_time / $profile->resp_num / 60)); ?> часов</span>
                    <?php elseif($profile->resp_time / $profile->resp_num < 10080): ?>
                        <span>~<?php echo e(round($profile->resp_time / $profile->resp_num / 1440)); ?> недель</span>
                    <?php endif; ?>
                </div>
            </div>
            <div class="line"></div>
            <?php if(isset($profile->pdf)): ?>
                <div class="pdf">
                    <div><img src="<?php echo e(asset('img/pdf2.svg')); ?>"></div>
                    <div><a data-fancybox="profile1" href="<?php echo e(asset('storage/' . $profile->pdf)); ?>">Посмотреть
                            расширенный профиль компании</a>
                    </div>
                </div>
                <div class="line"></div>
            <?php endif; ?>
            <div class="name">
                <img src="<?php echo e(asset('img/name6.svg')); ?>"> Отзывы
            </div>
            <div class="block">
                <div class="reviews flex2">
                    <?php $__currentLoopData = $profile->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <img src="<?php echo e(asset('img/review.png')); ?>">
                            <a data-caption="<?php echo e($review->file_name); ?>" data-fancybox="reviews"
                               href="<?php echo e(asset('storage/' . $review->path)); ?>"></a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/company.blade.php ENDPATH**/ ?>