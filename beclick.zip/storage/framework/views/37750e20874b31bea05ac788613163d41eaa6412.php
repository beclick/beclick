<?php echo e($slot); ?>

<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>