<!doctype html>
<html dir="rtl" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.svg')); ?>" type="image/png">

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <!-- Scripts -->
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo e(asset('js/slick.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css">

    <!-- Styles -->
    <link href="<?php echo e(asset('style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('slick.css')); ?>" rel="stylesheet">
</head>
<body>
<header class="header">
    <nav class="top-menu">
        <ul>
            <li><a href="#"><?php echo e(trans('app.recomended')); ?></a></li>
            <li><a href="#"><?php echo e(trans('app.forum')); ?></a></li>
            <li><a href="#"><?php echo e(trans('app.useful')); ?></a></li>
            <li><a href="#"><?php echo e(trans('app.faq')); ?></a></li>
        </ul>
    </nav>
    <div class="flex">
        <div class="left-side">
            <a class="menu-button"></a>
            <button class="add"><?php echo e(trans('app.create_project')); ?> +</button>
            <div class="profile-link">
                <i class="fa fa-angle-down"></i> <?php echo e(trans('app.my_profile')); ?> <img src="img/avatar.png">
                <div class="sub">
                    <ul>
                        <li><a href="#"><?php echo e(trans('app.edit_profile')); ?></a></li>
                        <li><a class="nav-link" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <?php echo e(trans('app.exit')); ?>

                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
            <a href="#" class="subscribe"></a>
        </div>
        <div class="right-side">
            <ul>
                <li><a href="#"><?php echo e(trans('app.articles')); ?></a></li>
                <li><a href="#"><?php echo e(trans('app.prices')); ?></a></li>
                <li><a href="#"><span>15</span><?php echo e(trans('app.requests_kp')); ?></a></li>
                <li><a href="#"><span>+2</span><?php echo e(trans('app.my_projects')); ?></a></li>
            </ul>
            <a class="catalog-link"><i class="fa fa-angle-down"></i> <?php echo e(trans('app.catalog_of_performers')); ?>

                <span></span></a>
            <div class="logo">
                <a href="/"><img src="img/logo.svg"></a>
            </div>
        </div>
    </div>
    <div class="mobile-menu">
        <ul class="ul1">
            <li><a href="#"><?php echo e(trans('app.articles')); ?></a></li>
            <li><a href="#"><?php echo e(trans('app.prices')); ?></a></li>
            <li><a href="#"><span>15</span><?php echo e(trans('app.requests_kp')); ?></a></li>
            <li><a href="#"><span>+2</span><?php echo e(trans('app.my_projects')); ?></a></li>
        </ul>
        <ul class="ul2">
            <li><a href="#"><?php echo e(trans('app.recomended')); ?></a></li>
            <li><a href="#"><?php echo e(trans('app.forum')); ?></a></li>
            <li><a href="#"><?php echo e(trans('app.useful')); ?></a></li>
            <li><a href="#"><?php echo e(trans('app.faq')); ?></a></li>
        </ul>
        <button class="add"><?php echo e(trans('app.create_project')); ?> +</button>
    </div>
    <div class="mob-header-catalog">
        <ul>
            <li>
                <a>
                    <img src="img/menu1.svg">
                    <span>Architects Interior</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <ul>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                </ul>
            </li>
            <li>
                <a>
                    <img src="img/menu2.svg">
                    <span>Engineers</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <ul>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                </ul>
            </li>
            <li>
                <a>
                    <img src="img/menu3.svg">
                    <span>Supportive services</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <ul>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                </ul>
            </li>
            <li>
                <a>
                    <img src="img/menu4.svg">
                    <span>Construction management and execution</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <ul>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                    <li><a href="#" class="link"><span><i>(7)</i> Model Builders</span></a></li>
                </ul>
            </li>
        </ul>
        <div class="name">
            Рекомендуем исполнителей
        </div>
        <div class="shop">
            <div class="name">
                <div>
                    Intel Corporation
                    <span>+972 41 872 3131</span>
                </div>
                <div><a href="#"><img src="img/shop.png"></a></div>
            </div>
            <p>Мы такие замечательные и классные, работаем на рынке уже 14 лет и всё умеем</p>
        </div>
        <div class="shop">
            <div class="name">
                <div>
                    Intel Corporation
                    <span>+972 41 872 3131</span>
                </div>
                <div><a href="#"><img src="img/shop.png"></a></div>
            </div>
            <p>Мы такие замечательные и классные, работаем на рынке уже 14 лет и всё умеем</p>
        </div>
        <div class="shop">
            <div class="name">
                <div>
                    Intel Corporation
                    <span>+972 41 872 3131</span>
                </div>
                <div><a href="#"><img src="img/shop.png"></a></div>
            </div>
            <p>Мы такие замечательные и классные, работаем на рынке уже 14 лет и всё умеем</p>
        </div>
        <div class="bottom-link">
            <a href="#">Как сюда попасть?</a>
        </div>
    </div>
    <div class="header-catalog">
        <ul>
            <li>
                <a href="#">
                    <img src="img/menu1.svg">
                    <span>Architects Interior</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <div class="sub">
                    <div class="flex">
                        <div class="col shops">
                            <div class="name">
                                Рекомендуем исполнителей
                            </div>
                            <div class="shop">
                                <div class="name">
                                    <div>
                                        Intel Corporation
                                        <span>+972 41 872 3131</span>
                                    </div>
                                    <div><a href="#"><img src="img/shop.png"></a></div>
                                </div>
                                <p>Мы такие замечательные и классные, работаем на рынке уже 14 лет и всё умеем</p>
                            </div>
                            <div class="shop">
                                <div class="name">
                                    <div>
                                        Intel Corporation
                                        <span>+972 41 872 3131</span>
                                    </div>
                                    <div><a href="#"><img src="img/shop.png"></a></div>
                                </div>
                                <p>Мы такие замечательные и классные, работаем на рынке уже 14 лет и всё умеем</p>
                            </div>
                            <div class="shop">
                                <div class="name">
                                    <div>
                                        Intel Corporation
                                        <span>+972 41 872 3131</span>
                                    </div>
                                    <div><a href="#"><img src="img/shop.png"></a></div>
                                </div>
                                <p>Мы такие замечательные и классные, работаем на рынке уже 14 лет и всё умеем</p>
                            </div>
                            <a href="#" class="bottom-link">Как сюда попасть?</a>
                        </div>
                        <div class="col">
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                        </div>
                        <div class="col">
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                            <a href="#" class="link"><span><i>(7)</i> Model Builders</span></a>
                            <a href="#" class="link"><span><i>14</i> 3D Computer Renderings</span></a>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <a href="#">
                    <img src="img/menu2.svg">
                    <span>Engineers</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <div class="sub">
                    <br/><br/>Подпункты &nbsp; &nbsp;<br/><br/><br/>
                </div>
            </li>
            <li>
                <a href="#">
                    <img src="img/menu3.svg">
                    <span>Supportive services</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <div class="sub">
                    <br/><br/>Подпункты 22 &nbsp; &nbsp;<br/><br/><br/>
                </div>
            </li>
            <li>
                <a href="#">
                    <img src="img/menu4.svg">
                    <span>Construction management and execution</span>
                    <i class="fa fa-angle-left"></i>
                </a>
                <div class="sub">
                    <br/><br/>Подпункты 33 &nbsp; &nbsp;<br/><br/><br/>
                </div>
            </li>
        </ul>
    </div>
</header>

<div class="wrap">
    <?php echo $__env->yieldContent('content'); ?>
</div>

<footer class="footer">
    <div class="wrap">
        <div class="flex">
            <nav>
                <p><?php echo e(trans('app.about_project')); ?></p>
                <ul>
                    <li><a href="#"><?php echo e(trans('app.about')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.contacts')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.privacy_policy')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.map_site')); ?></a></li>
                </ul>
            </nav>
            <nav>
                <p><?php echo e(trans('app.to_the_customer')); ?></p>
                <ul>
                    <li><a href="#"><?php echo e(trans('app.recomended')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.support')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.catalog_of_performers')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.prices')); ?></a></li>
                </ul>
            </nav>
            <nav>
                <p><?php echo e(trans('app.for_the_contractor')); ?></p>
                <ul>
                    <li><a href="#"><?php echo e(trans('app.support')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.companies')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.articles')); ?></a></li>
                    <li><a href="#"><?php echo e(trans('app.forum')); ?></a></li>
                </ul>
            </nav>
            <div class="social">
                <p<?php echo e(trans('app.social_networks')); ?></p>
                <div class="links">
                    <a href="#"><img src="img/social1.svg"></a>
                    <a href="#"><img src="img/social2.svg"></a>
                    <a href="#"><img src="img/social3.svg"></a>
                    <a href="#"><img src="img/social4.svg"></a>
                </div>
                <p><?php echo e(trans('app.subscribe_news')); ?></p>
                <form>
                    <input type="text" placeholder="e-mail">
                    <button></button>
                </form>
            </div>
        </div>
        <div class="line"></div>
        <div class="flex">
            <div class="payment">
                <?php echo e(trans('app.payment_system')); ?> <img src="img/payment.svg">
            </div>
            <div class="copy">
                <?php echo e(trans('app.all_rights_reserved')); ?>

            </div>
        </div>
    </div>
</footer>
<div class="popup cat">
    <div class="window">
        <a class="close"></a>
        <p><?php echo e(trans('app.add_new_work_category')); ?></p>
        <div class="field-name">
            <?php echo e(trans('app.name_of_category')); ?>

        </div>
        <input type="text" placeholder="<?php echo e(trans('app.enter_the_title')); ?>">
        <div class="field-name">
            <?php echo e(trans('app.name_of_category')); ?>

        </div>
        <textarea placeholder="<?php echo e(trans('app.describe_added_category')); ?>"></textarea>
        <button><?php echo e(trans('app.save')); ?></button>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\OpenServer\domains\beclick\resources\views/layouts/app.blade.php ENDPATH**/ ?>