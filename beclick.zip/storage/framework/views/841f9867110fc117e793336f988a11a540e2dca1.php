<?php $__env->startSection('title', 'Админка – Beclick'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container mt-3">
        <h3>Настройки</h3>
        <hr>
        <div id="accordion">
            <div class="card">
                <div class="card-header" id="headingOne">
                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapseOne"
                            aria-expanded="true" aria-controls="collapseOne">
                        <h5>CRUD - Категории</h5>
                    </button>
                </div>
                <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordion">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg text-right border border-secondary rounded m-1">
                                <h5 class="text-success">Категории</h5>
                                <hr>
                                <a class="crt btn btn-block btn-sm btn-secondary">Создать</a>
                                <input value="0" hidden>
                                <br>
                                <div id="categories">
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h5>
                                            <div>
                                                <a class="del btn btn-sm btn-secondary">D</a>
                                                <a class="upd btn btn-sm btn-secondary">U</a>
                                                <label><?php echo e($category->title); ?></label>
                                                <input value="<?php echo e($category->id); ?>" hidden>
                                                </div>
                                        </h5>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-lg text-right border border-secondary rounded m-1">
                                <h5 class="text-success">Подкатегории</h5>
                                <hr>
                                <a class="crt btn btn-block btn-sm btn-secondary" style="display: none">Создать</a>
                                <input value="" hidden>
                                <br>
                                <div id="subcategories">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header" id="heading2">
                    <button class="btn btn-link" data-toggle="collapse" data-target="#collapse2"
                            aria-expanded="true" aria-controls="collapse2">
                        <h5>CRUD - Специализации</h5>
                    </button>
                </div>
                <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordion">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg text-right border border-secondary rounded m-1">
                                <h5 class="text-success">Специализации</h5>
                                <hr>
                                <a class="crt btn btn-block btn-sm btn-secondary">Создать</a>
                                <br>
                                <div id="specializations">
                                    <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h5>
                                            <div>
                                                <a class="del btn btn-sm btn-secondary">D</a>
                                                <a class="upd btn btn-sm btn-secondary">U</a>
                                                <label><?php echo e($specialization->title); ?></label>
                                                <input value="<?php echo e($specialization->id); ?>" hidden>
                                            </div>
                                        </h5>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-lg text-right border border-secondary rounded m-1">
                                <h5 class="text-success">Новые специализации</h5>
                                <hr>
                                <div id="specializations">
                                    <?php $__currentLoopData = $newspecializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $newspecialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <h5>
                                            <?php echo e($newspecialization); ?>

                                        </h5>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function () {
            function get_sub(val) {
                $.ajax({
                    url: "<?php echo e(route('admin.resource')); ?>?get_sub=" + val,
                }).done(function (data) {
                    $('#subcategories').empty();
                    data.forEach(function (item) {
                        $('#subcategories').append(`
                            <h5><a class="del btn btn-sm btn-secondary">D</a>
                            <a class="upd btn btn-sm btn-secondary">U</a>
                            <label>${item.title}</label>
                            <input value="${item.id}" hidden>
                            </h5>
                        `);
                    });
                    $('#subcategories').siblings('input').val(val);
                    $('#subcategories').siblings('.crt').css('display', 'block');
                });
            }

            $('#categories').on('click', 'label', function () {
                get_sub($(this).next('input').val());
                $('#categories').find('label').removeClass('text-info');
                $(this).addClass('text-info');
            });

            $('#categories, #subcategories').on('click', '.upd', function () {
                var id = $(this).siblings('input').val(),
                    val = $(this).siblings('label').text(),
                    route = "<?php echo e(route('admin.settings', ['category' => 'update'])); ?>",
                    csrf = '<?php echo csrf_field(); ?>';
                $('#myaction').modal('show').find('.modal-header').empty().append(`
                    <h5>Редактировать</h5>
               `);
                $('#myaction').modal('show').find('.modal-body').empty().append(`
                    <form method="POST" action="${route}">
                        ${csrf}
                        <input type="text" class="form-control" name="value" value="${val}">
                        <input type="text" class="form-control" name="id" value="${id}" hidden>
                        <hr>
                        <button type="submit" class="btn btn-block btn-success">Соранить</button>
                    </form>
               `);
            });

            $('#categories, #subcategories').on('click', '.del', function () {
                var id = $(this).siblings('input').val(),
                    val = $(this).siblings('label').text(),
                    route = "<?php echo e(route('admin.settings', ['category' => 'delete'])); ?>",
                    csrf = '<?php echo csrf_field(); ?>';
                $('#myaction').modal('show').find('.modal-header').empty().append(`
                    <h5>Удалить ${val}</h5>
               `);
                $('#myaction').modal('show').find('.modal-body').empty().append(`
                    <form method="POST" action="${route}">
                        ${csrf}
                        <input type="text" class="form-control" name="id" value="${id}" hidden>
                        <button type="submit" class="btn btn-block btn-success">Удалить</button>
                    </form>
               `);
            });

            $('#categories, #subcategories').parent('div').on('click', '.crt', function () {
                var id = $(this).siblings('input').val(),
                    route = "<?php echo e(route('admin.settings', ['category' => 'create'])); ?>",
                    csrf = '<?php echo csrf_field(); ?>';
                $('#myaction').modal('show').find('.modal-header').empty().append(`
                    <h5>Создать</h5>
               `);
                $('#myaction').modal('show').find('.modal-body').empty().append(`
                    <form method="POST" action="${route}">
                        ${csrf}
                        <input type="text" class="form-control" name="value">
                        <input type="text" class="form-control" name="id" value="${id}" hidden>
                        <hr>
                        <button type="submit" class="btn btn-block btn-success">Создать</button>
                    </form>
               `);
            });

            $('#specializations').on('click', '.upd', function () {
                var id = $(this).siblings('input').val(),
                    val = $(this).siblings('label').text(),
                    route = "<?php echo e(route('admin.settings', ['specialization' => 'update'])); ?>",
                    csrf = '<?php echo csrf_field(); ?>';
                $('#myaction').modal('show').find('.modal-header').empty().append(`
                    <h5>Редактировать</h5>
               `);
                $('#myaction').modal('show').find('.modal-body').empty().append(`
                    <form method="POST" action="${route}">
                        ${csrf}
                        <input type="text" class="form-control" name="value" value="${val}">
                        <input type="text" class="form-control" name="id" value="${id}" hidden>
                        <hr>
                        <button type="submit" class="btn btn-block btn-success">Соранить</button>
                    </form>
               `);
            });

            $('#specializations').on('click', '.del', function () {
                var id = $(this).siblings('input').val(),
                    val = $(this).siblings('label').text(),
                    route = "<?php echo e(route('admin.settings', ['specialization' => 'delete'])); ?>",
                    csrf = '<?php echo csrf_field(); ?>';
                $('#myaction').modal('show').find('.modal-header').empty().append(`
                    <h5>Удалить ${val}</h5>
               `);
                $('#myaction').modal('show').find('.modal-body').empty().append(`
                    <form method="POST" action="${route}">
                        ${csrf}
                        <input type="text" class="form-control" name="id" value="${id}" hidden>
                        <button type="submit" class="btn btn-block btn-success">Удалить</button>
                    </form>
               `);
            });

            $('#specializations').parent('div').on('click', '.crt', function () {
                var route = "<?php echo e(route('admin.settings', ['specialization' => 'create'])); ?>",
                    csrf = '<?php echo csrf_field(); ?>';
                $('#myaction').modal('show').find('.modal-header').empty().append(`
                    <h5>Создать</h5>
               `);
                $('#myaction').modal('show').find('.modal-body').empty().append(`
                    <form method="POST" action="${route}">
                        ${csrf}
                        <input type="text" class="form-control" name="value">
                        <hr>
                        <button type="submit" class="btn btn-block btn-success">Создать</button>
                    </form>
               `);
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/admin/settings.blade.php ENDPATH**/ ?>