<?php $__env->startSection('title', 'Вход в админку – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <section class="login container-fluid">
        <form class="login-form" id="login-form" novalidate="" method="POST" action="<?php echo e(route('admin.login')); ?>">
            <?php echo csrf_field(); ?>
            <h1 class="login__title">Панель администратора</h1>
            <div class="form-group container">
                <input class="form-control" type="text" name="login" placeholder="Логин" required="">
                <input class="form-control" type="password" name="password" placeholder="Пароль" required=""
                       id="password">
                <button class="btn login__btn" type="submit" onclick="validateLogin();" id="loginSubmit">Войти в систему
                </button>
            </div>
        </form>
    </section>

    <script>
        function validateLogin() {
            var validator = $("#login-form").validate({

                rules: {
                    login: "required",
                    password: "required",
                },
                messages: {
                    login: "Введите ваш логин",
                    password: "Введите пароль",
                },
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/admin/login.blade.php ENDPATH**/ ?>