<?php $__env->startSection('title', __('app.payment_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="payment-page">
        <h1><?php echo e(__('app.payment1')); ?></h1>
        <div class="top-text">
            <?php echo e(__('app.payment2')); ?>

        </div>
        <div class="flex">
            <input type="radio" class="radio" id="r2" name="r1">
            <label for="r2">
                <span class="badge"><?php echo e(__('app.payment3')); ?></span>
                <div class="name">
                    <?php echo e(__('app.payment4')); ?>

                </div>
                <div class="price">
                    <?php echo e(__('app.payment5')); ?>

                </div>
                <div class="text">
                    <?php echo __('app.payment6'); ?>

                </div>
                <button><?php echo e(__('app.payment7')); ?></button>
            </label>
            <input type="radio" class="radio" id="r1" name="r1">
            <label for="r1">
                <span class="badge green"><?php echo e(__('app.payment8')); ?></span>
                <div class="name">
                    <?php echo e(__('app.payment9')); ?>

                </div>
                <div class="price">
                    <?php echo e(__('app.payment10')); ?>

                </div>
                <div class="text">
                    <?php echo __('app.payment11'); ?>

                </div>
                <button class="green"><?php echo e(__('app.payment12')); ?></button>
            </label>
        </div>
        <div class="invite">
            <p><?php echo e(__('app.payment13')); ?></p>
            <div class="links">
                <a href="#"><span><?php echo e(__('app.payment14')); ?></span></a>
                <a href="#"><span><?php echo e(__('app.payment15')); ?></span></a>
                <a href="#"><span><?php echo e(__('app.payment16')); ?></span></a>
            </div>
            <div class="link">
                <span><?php echo e(__('app.payment17')); ?></span> <input type="text" value="catchdeal.me/r/companyname">
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/payment.blade.php ENDPATH**/ ?>