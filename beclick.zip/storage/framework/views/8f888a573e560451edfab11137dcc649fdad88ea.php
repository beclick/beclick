<?php if(isset($questions)): ?>
    <div class="fields-name">
        <img src="<?php echo e(asset('img/name10.svg')); ?>"> <?php echo e(__('app.quest1')); ?>

    </div>
    <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="field-name">
            <?php echo e($question->title); ?>

            <input id="title" type="text" name="questions[]"
                   value="name|||<?php echo e($question->title); ?>" autocomplete="off" hidden>
        </div>
        <div class="field">
            <?php if($question->type_question == 1): ?>
                <input id="title" type="text" name="questions[]"
                       value="<?php echo e($question->variants); ?>" autocomplete="off">
            <?php elseif($question->type_question == 2): ?>
                <select id="category_n" name="questions[]" autocomplete="off">
                    <?php if(isset($question->variants)): ?>
                        <?php $__currentLoopData = explode('|', $question->variants); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($variant); ?>"><?php echo e($variant); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </select>
            <?php elseif($question->type_question == 3): ?>
                <div class="regions">
                    <div class="item">
                        <?php if(isset($question->variants)): ?>
                            <?php $__currentLoopData = explode('|', $question->variants); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="checkbox" class="checkbox" id="chss<?php echo e($loop->iteration); ?>" name="questions[]"
                                       value="<?php echo e($variant); ?>" autocomplete="off">
                                <label for="chss<?php echo e($loop->iteration); ?>"><?php echo e($variant); ?></label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/layouts/questions.blade.php ENDPATH**/ ?>