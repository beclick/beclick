<?php $__env->startSection('title', 'Протокол уастников торгов по лоту ' .  $lot->num_lot  . ' аукциона ' .  $lot->auction_id  . ' – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h3>Журнал уастников</h3>
        <hr>
        <div class="card rounded-0 shadow">
            <div class="card-header bg-white text-black-50 p-0">
                <div class="row text-dark m-4">
                    <div class="col-lg">
                        <h5><?php echo e($lot->name); ?></h5>
                    </div>
                </div>
                <div class="list-group list-group-horizontal-lg rounded-0">
                    <a class="list-group-item list-group-item-secondary rounded-0 active" href="#users"
                       data-toggle="tab"><h5>Участники</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#all"
                       data-toggle="tab"><h5>Информация</h5></a>
                    <a class="list-group-item list-group-item-secondary rounded-0" href="#docs" data-toggle="tab"><h5>
                            Документы</h5></a>
                    <div class="p-0 col list-group-item rounded-0 text-right text-dark">
                        <?php if($lot->protocol->isEmpty()): ?>
                            <form class="h-100" method="POST"
                                  action="<?php echo e(route('protocol-lot')); ?>" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="lot" value="<?php echo e($lot->id); ?>">
                                <button type="button"
                                        class="h-100 ecp_button btn btn-block btn-lg btn-danger rounded-0">
                                    Прикрепить протокол.<a target="_blank"
                                                           href="<?php echo e(asset('docs/проект протокола.docx')); ?>">&nbsp;Образец
                                        протокола</a>
                                </button>
                            </form>
                        <?php else: ?>
                            <button type="button" class="h-100 btn btn-block btn-lg btn-success rounded-0">Протокол
                                прикреплен
                            </button>
                        <?php endif; ?>
                    </div>
                    <div class="col list-group-item rounded-0 text-right text-dark">
                        <h5>
                            <a href="<?php echo e(route('auction', ['auction' => $lot->auction->id])); ?>">Аукцион <?php echo e($lot->auction->id); ?></a>
                            <a href="<?php echo e(route('home', ['lot' => $lot->id])); ?>">Лот <?php echo e($lot->num_lot); ?></a></h5>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="tab-content">
                    <div class="tab-pane fade active show" id="users">
                        <h5>Участники</h5>
                        <div class="container-fluid overflow-auto">
                            <table class="table table-striped">
                                <thead class="sticky-top">
                                <tr class="">
                                    <th scope="col">Номер участника</th>
                                    <th scope="col">ИНН</th>
                                    <th scope="col">Номер заявки участника</th>
                                    <th scope="col">Участник</th>
                                    <th scope="col">Дата подачи заявки</th>
                                    <th scope="col">Заблокирована сумма</th>
                                </tr>
                                </thead>
                                <tbody class="">
                                <?php $__currentLoopData = $filings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr <?php if($filing->profile_id == $my_profile->id): ?> class="text-primary" <?php endif; ?>>
                                        <th>ID: <?php echo e($filing->profile_id); ?></th>
                                        <th><?php echo e($filing->profile->inn); ?></th>
                                        <th><?php echo e($lot->filings->where('profile_id', $filing->profile_id)->where('status', 1)->first()->id); ?></th>
                                        <th><?php if($filing->profile->user_type == 0): ?> <?php echo e($filing->profile->title); ?> <?php elseif($filing->profile->user_type == 1): ?> <?php echo e('ИП ' . $filing->profile->full_name); ?> <?php elseif($filing->profile->user_type == 2): ?> <?php echo e('ФЛ ' . $filing->profile->full_name); ?> <?php endif; ?></th>
                                        <th><?php echo e(\Illuminate\Support\Carbon::parse($filing->created_at)->format('d.m.Y H:i')); ?></th>
                                        <th><?php echo e(number_format($lot->deposit_price / 100, 2, '.', '')); ?> ₽</th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="tab-pane fade" id="all">
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Статус торгов</p>
                            <p class="col">
                                <?php if($lot->status == 1): ?>
                                    <strong class="text-success">Торги по лоту состоялись</strong>
                                <?php elseif($lot->status == 2): ?>
                                    <strong class="text-warning">Торги по лоту не состоялись</strong>
                                <?php elseif($lot->status == 3): ?>
                                    <strong class="text-danger">Приостановлен</strong>
                                <?php elseif($lot->status == 4): ?>
                                    <strong class="text-danger">Аннулирован</strong>
                                <?php elseif($lot->auction->status == 0): ?>
                                    <strong class="text-black-50">Не активный</strong>
                                <?php elseif($lot->auction->status == 1): ?>
                                    <?php if(strtotime(date('Y-m-d H:i')) <= strtotime($lot->start_request)): ?>
                                        <strong class="text-success">Объявлен</strong>
                                    <?php elseif(strtotime($lot->start_request) <= strtotime(date('Y-m-d H:i')) and strtotime(date('Y-m-d H:i')) < strtotime($lot->end_request)): ?>
                                        <strong class="text-info">Идёт приём заявок</strong>
                                    <?php elseif(strtotime($lot->end_request) <= strtotime(date('Y-m-d H:i')) and strtotime(date('Y-m-d H:i')) < strtotime($lot->start_auction)): ?>
                                        <strong class="text-warning">Приём заявок завершен</strong>
                                    <?php elseif(strtotime($lot->start_auction) <= strtotime(date('Y-m-d H:i'))): ?>
                                        <strong class="text-success">Идут торги</strong>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Дата начала</p>
                            <p class="col">
                                <?php echo e(\Illuminate\Support\Carbon::parse($lot->start_auction)->format('d.m.Y H:i')); ?>

                            </p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Начальная цена</p>
                            <p class="col"><?php echo e(number_format($lot->start_price / 100, 2, '.', '')); ?> ₽</p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Шаг аукциона</p>
                            <p class="col"><?php echo e(number_format($lot->step_price / 100, 2, '.', '')); ?> ₽</p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Организатор торгов</p>
                            <p class="col">
                                <?php if($lot->profile->user_type == 0): ?>
                                    <?php echo e($lot->profile->full_title); ?>

                                <?php else: ?>
                                    <?php echo e($lot->profile->full_name); ?>

                                <?php endif; ?>
                            </p>
                        </h5>
                        <h5 class="row m-0">
                            <p class="col-lg-5 text-black-50">Имущество должника</p>
                            <p class="col"><?php echo e($lot->debtor); ?></p>
                        </h5>
                    </div>
                    <div class="tab-pane fade" id="docs">
                        <?php $__currentLoopData = $lot->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАН
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $lot->protocol; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <strong>
                                <div class="row">
                                    <div class="col">
                                        <a target="_blank" class="col-lg-7" target="_blank"
                                           href="<?php echo e(asset('storage/' . $doc->path)); ?>">
                                            <?php echo e($doc->file_name); ?>

                                        </a>
                                    </div>
                                    <div class="col-auto">
                                        <?php if($doc->sign): ?>
                                            ПОДПИСАН ЭП
                                        <?php else: ?>
                                            НЕ ПОДПИСАН
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </strong>
                            <hr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <?php echo $__env->make('layouts.ecp-modal', ['file' => 'true', 'title' => 'Подтверждаю свое согласие на размещение протокола доступа участников к торгам по лоту на ЭТП, согласно регламенту ЭТП.', 'submit' => 'Разместить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/protocol-lot.blade.php ENDPATH**/ ?>