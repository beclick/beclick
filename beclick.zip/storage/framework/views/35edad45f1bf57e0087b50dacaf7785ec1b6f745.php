<?php $__env->startSection('title', 'Вопрос-ответ – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>


    <section class="sign">
        <div class="sign-container">

            <section class="accordion-section clearfix mt-3" aria-label="Question Accordions">
  <div class="container">

      <h2>Часто задаваемые вопросы: </h2>
      <br>



<div class="schema-faq-code" itemscope="" itemtype="https://schema.org/FAQPage">
    <div itemscope="" itemprop="mainEntity" itemtype="https://schema.org/Question" class="faq-question">
        <h3 itemprop="name" class="faq-q">Я забыл пароль для входа в личный кабинет. Как его восстановить?</h3>
        <div itemscope="" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
             <p itemprop="text" class="faq-a">     Для восстановления пароля перейдите <a href="/password/reset">на страницу сброса пароля</a>.  Введите email, на который вы регистрировали учетную запись в системе и нажмите кнопку Сбросить пароль. Дальнейшие инструкции по сбросу пароля будут в письме.</p>
        </div>
    </div>

    <div itemscope="" itemprop="mainEntity" itemtype="https://schema.org/Question" class="faq-question">
        <h3 itemprop="name" class="faq-q"> Какие требования к паролю установлены на площадке Арестторг.рф</h3>
        <div itemscope="" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
             <p itemprop="text" class="faq-a">Требованиями политики информационной безопасности к сложности пароля установлено, что пароль пользователя должен отвечать минимум трем перечисленным ниже критериям:
             - содержит латинские буквы в заглавном регистре;
              - содержит латинские буквы в строчном регистре;
            - содержит цифры;
          - содержит знаки препинания.
При этом, общая длина пароля должна быть не менее 8 символов.</p>
        </div>
    </div>

    <div itemscope="" itemprop="mainEntity" itemtype="https://schema.org/Question" class="faq-question">
        <h3 itemprop="name" class="faq-q"> Как вывести средства с баланса?</h3>
        <div itemscope="" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
             <p itemprop="text" class="faq-a">Для того, чтобы вывести средства со счета в системе, создайте заявку на вывод с указанием суммы и реквизитов.<br> <a href="/withdrawal">Подать заявку на вывод</a></p>
        </div>
    </div>

    <div itemscope="" itemprop="mainEntity" itemtype="https://schema.org/Question" class="faq-question">
        <h3 itemprop="name" class="faq-q">Как установить и настроить ЭП?</h3>
        <div itemscope="" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
             <p itemprop="text" class="faq-a">Перейдите на страницу <a href="/sign">Настроить ЭП</a> для получения инструкций по получению и настройке электронной цифровой подписи</p>
        </div>
    </div>


    <div itemscope="" itemprop="mainEntity" itemtype="https://schema.org/Question" class="faq-question">
        <h3 itemprop="name" class="faq-q">Вернется ли нам на счет обеспечение заявки и в какие сроки?</h3>
        <div itemscope="" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
             <p itemprop="text" class="faq-a">В соответствии с Регламентом работы электронной площадки Арестторг операции по прекращению блокирования денежных средств, внесенных в качестве обеспечения заявки на участие в электронном аукционе, у участников не допущенных к участию в аукционе, не принявших участие в аукционе, заявки которых признаны несоответствующими, осуществляются в 19:00 (по серверному времени площадки) дня, следующего за днем публикации протокола рассмотрения (единственной заявки, единственного участника), протокола проведения аукциона, протокола подведения итогов. У участника (победителя) аукциона, с которым заключается контракт, операция по прекращению блокирования денежных средств, внесенных в качестве обеспечения заявки на участие в электронном аукционе, осуществляется после заключения контракта на электронной площадке. Участие в электронных аукционах осуществляется без взимания платы.</p>
        </div>
    </div>



        <div itemscope="" itemprop="mainEntity" itemtype="https://schema.org/Question" class="faq-question">
        <h3 itemprop="name" class="faq-q">Какое время указывается на электронной площадке в Извещении о проведении аукциона?</h3>
        <div itemscope="" itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
             <p itemprop="text" class="faq-a">Все действия, связанные с проведением электронного аукциона, осуществляются по серверному (московскому) времени площадки.</p>
        </div>
    </div>



</div>






      </div>

  </div>
</section>

        </div>

<style type="text/css">
  .schema-faq-code {
border: 1px solid #dedee0;
border-radius: 0px;
background-color:#fefbf9;
  overflow:hidden;
}
.schema-faq-code .faq-q {
font-size: 14px;
font-weight: bold;
margin: 0;
padding: 12px 56px 12px 12px;
line-height: 1.4;
cursor: pointer;
position: relative;
border-bottom: 1px solid #dedee0;
-webkit-touch-callout: none;
-webkit-user-select: none;
-khtml-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
}
.faq-q:after {
    content: "+";
    position: absolute;
    top: 50%;
    right: 0;
    width: 56px;
    text-align: center;
    -webkit-transform: translateY(-50%);
    -moz-transform: translateY(-50%);
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    font-weight: bold;
    color: #000;
    font-size: 20px;
}
.faq-q.faq-q-open:after {
    content: "-";
}

.schema-faq-code .faq-q:hover{

background: #fff;
}
.faq-a {
margin: 0;
padding: 12px;
background-color:#fff;
font-size: 14px;
line-height: 1.4;
  border-bottom: 1px solid #dedee0;
  display: none;
}
.schema-faq-code .faq-question:last-child .faq-a {
  border-bottom:0px;
}
</style>

<script type="text/javascript">

  jQuery('.faq-q').click(function(){
  if (jQuery(this).siblings().find('.faq-a').is(':visible')) {
    jQuery(this).removeClass('faq-q-open');
    jQuery(this).siblings().find('.faq-a').removeClass('faq-a-open').slideUp();
}
else {
  jQuery(this).addClass('faq-q-open');
  jQuery(this).siblings().find('.faq-a').addClass('faq-a-open').slideDown();
  }
})
</script>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/docs/faq.blade.php ENDPATH**/ ?>