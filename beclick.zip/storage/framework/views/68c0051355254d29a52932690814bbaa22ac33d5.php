<?php $__env->startSection('title', 'Новый аукцион – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <?php if(isset($request->type) or isset($auction)): ?>
            <?php if($request->type == 1 or (isset($auction) and $auction->type == 1)): ?>
                <h3><strong class="text-danger">Тип аукциона: Реализация имущества должников</strong></h3>
            <?php elseif($request->type == 2 or (isset($auction) and $auction->type == 2)): ?>
                <h3><strong class="text-danger">Тип аукциона: Продажа муниципального имущества</strong></h3>
            <?php endif; ?>
        <?php else: ?>
            <a href="<?php echo e(route('creation-auction', ['type' => 1])); ?>"
               class="btn btn-outline-primary btn-lg btn-block rounded-0">
                Реализация имущества должников
            </a>
            <br>
            <a href="<?php echo e(route('creation-auction', [ 'type' => 2])); ?>"
               class="btn btn-outline-primary btn-lg btn-block rounded-0">
                Продажа муниципального имущества
            </a>
            <br>
        <?php endif; ?>
        <?php if(isset($request->type) or isset($auction)): ?>
            <h3><?php if(isset($auction)): ?> Редактирование <?php else: ?> Создание <?php endif; ?> аукциона</h3>
            <hr>
            <form method="POST" action="<?php echo e(route('creation-auction')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($request->type)): ?>
                    <input name="type" value="<?php echo e($request->type); ?>" hidden>
                <?php endif; ?>
                <h5>Общая информация</h5>
                <div class="form-row">
                    <div class="form-group col">
                        <input <?php if(isset($auction)): ?> value="<?php echo e($auction->name); ?>" <?php else: ?> value="<?php echo e(old('name')); ?>"
                               <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               type="text" name="name" required placeholder="Название аукциона">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col">
                        <input <?php if(isset($auction)): ?> value="<?php echo e($auction->organiser); ?>" <?php else: ?> value="<?php echo e(old('organiser')); ?>"
                               <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['organiser'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               type="text" name="organiser" required placeholder="Организатор">
                        <?php $__errorArgs = ['organiser'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col">
                        <input <?php if(isset($auction)): ?> value="<?php echo e($auction->base); ?>" <?php else: ?> value="<?php echo e(old('base')); ?>"
                               <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['base'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               type="text" name="base" required placeholder="Основание для реализации на торгах">
                        <?php $__errorArgs = ['base'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col">
                        <input <?php if(isset($auction)): ?> value="<?php echo e($auction->place_auc); ?>" <?php else: ?>  value="<?php echo e(old('place_auc')); ?>"
                               <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['place_auc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               type="text" name="place_auc" required placeholder="Место проведения торгов">
                        <?php $__errorArgs = ['place_auc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col">
                        <input <?php if(isset($auction)): ?> value="<?php echo e($auction->place); ?>" <?php else: ?>  value="<?php echo e(old('place')); ?>"
                               <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                               type="text" name="place" required placeholder="Место подведения результатов торгов">
                        <?php $__errorArgs = ['place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <hr>
                <h5>Укажите актуальные даты и время</h5>
                <div class="form-row">
                    <div class="form-group col-lg">
                        <div class="input-group">
                            <input <?php if(isset($auction)): ?> value="<?php echo e(\Illuminate\Support\Carbon::parse($auction->start_request)->format('Y.m.d H:i')); ?>" <?php endif; ?> id="start_request" class="form-control form-control-lg rounded-0" required
                                   placeholder="Начало приёма заявок" type="text" name="start_request">
                            <div class="input-group-append">
                                <div class="input-group-text rounded-0">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none"
                                         xmlns="http://www.w3.org/2000/svg" class="img-svg replaced-svg">
                                        <path
                                            d="M5.5 8.16675H3.83333V9.83341H5.5V8.16675ZM8.83333 8.16675H7.16667V9.83341H8.83333V8.16675ZM12.1667 8.16675H10.5V9.83341H12.1667V8.16675ZM13.8333 2.33341H13V0.666748H11.3333V2.33341H4.66667V0.666748H3V2.33341H2.16667C1.24167 2.33341 0.508333 3.08341 0.508333 4.00008L0.5 15.6667C0.5 16.1088 0.675595 16.5327 0.988155 16.8453C1.30072 17.1578 1.72464 17.3334 2.16667 17.3334H13.8333C14.75 17.3334 15.5 16.5834 15.5 15.6667V4.00008C15.5 3.08341 14.75 2.33341 13.8333 2.33341ZM13.8333 15.6667H2.16667V6.50008H13.8333V15.6667Z"
                                            fill="#3A5EDB"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-lg">
                        <div class="input-group">
                            <input <?php if(isset($auction)): ?> value="<?php echo e(\Illuminate\Support\Carbon::parse($auction->end_request)->format('Y.m.d H:i')); ?>" <?php endif; ?> id="end_request" class="form-control form-control-lg rounded-0" required
                                   placeholder="Окончание приёма заявок" type="text" name="end_request">
                            <div class="input-group-append">
                                <div class="input-group-text rounded-0">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none"
                                         xmlns="http://www.w3.org/2000/svg" class="img-svg replaced-svg">
                                        <path
                                            d="M5.5 8.16675H3.83333V9.83341H5.5V8.16675ZM8.83333 8.16675H7.16667V9.83341H8.83333V8.16675ZM12.1667 8.16675H10.5V9.83341H12.1667V8.16675ZM13.8333 2.33341H13V0.666748H11.3333V2.33341H4.66667V0.666748H3V2.33341H2.16667C1.24167 2.33341 0.508333 3.08341 0.508333 4.00008L0.5 15.6667C0.5 16.1088 0.675595 16.5327 0.988155 16.8453C1.30072 17.1578 1.72464 17.3334 2.16667 17.3334H13.8333C14.75 17.3334 15.5 16.5834 15.5 15.6667V4.00008C15.5 3.08341 14.75 2.33341 13.8333 2.33341ZM13.8333 15.6667H2.16667V6.50008H13.8333V15.6667Z"
                                            fill="#3A5EDB"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-lg">
                        <div class="input-group">
                            <input <?php if(isset($auction)): ?> value="<?php echo e(\Illuminate\Support\Carbon::parse($auction->start_auction)->format('Y.m.d H:i')); ?>" <?php endif; ?> id="start_auction" class="form-control form-control-lg rounded-0" required
                                   placeholder="Дата и время начала аукциона" type="text" name="start_auction">
                            <div class="input-group-append">
                                <div class="input-group-text rounded-0">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none"
                                         xmlns="http://www.w3.org/2000/svg" class="img-svg replaced-svg">
                                        <path
                                            d="M5.5 8.16675H3.83333V9.83341H5.5V8.16675ZM8.83333 8.16675H7.16667V9.83341H8.83333V8.16675ZM12.1667 8.16675H10.5V9.83341H12.1667V8.16675ZM13.8333 2.33341H13V0.666748H11.3333V2.33341H4.66667V0.666748H3V2.33341H2.16667C1.24167 2.33341 0.508333 3.08341 0.508333 4.00008L0.5 15.6667C0.5 16.1088 0.675595 16.5327 0.988155 16.8453C1.30072 17.1578 1.72464 17.3334 2.16667 17.3334H13.8333C14.75 17.3334 15.5 16.5834 15.5 15.6667V4.00008C15.5 3.08341 14.75 2.33341 13.8333 2.33341ZM13.8333 15.6667H2.16667V6.50008H13.8333V15.6667Z"
                                            fill="#3A5EDB"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group col-lg">
                        <div class="input-group">
                            <input <?php if(isset($auction)): ?> value="<?php echo e(\Illuminate\Support\Carbon::parse($auction->end_auction)->format('Y.m.d')); ?>" <?php endif; ?> id="end_auction" class="form-control form-control-lg rounded-0" required
                                   placeholder="Подведение результатов торгов" type="text" name="end_auction">
                            <div class="input-group-append">
                                <div class="input-group-text rounded-0">
                                    <svg width="16" height="18" viewBox="0 0 16 18" fill="none"
                                         xmlns="http://www.w3.org/2000/svg" class="img-svg replaced-svg">
                                        <path
                                            d="M5.5 8.16675H3.83333V9.83341H5.5V8.16675ZM8.83333 8.16675H7.16667V9.83341H8.83333V8.16675ZM12.1667 8.16675H10.5V9.83341H12.1667V8.16675ZM13.8333 2.33341H13V0.666748H11.3333V2.33341H4.66667V0.666748H3V2.33341H2.16667C1.24167 2.33341 0.508333 3.08341 0.508333 4.00008L0.5 15.6667C0.5 16.1088 0.675595 16.5327 0.988155 16.8453C1.30072 17.1578 1.72464 17.3334 2.16667 17.3334H13.8333C14.75 17.3334 15.5 16.5834 15.5 15.6667V4.00008C15.5 3.08341 14.75 2.33341 13.8333 2.33341ZM13.8333 15.6667H2.16667V6.50008H13.8333V15.6667Z"
                                            fill="#3A5EDB"></path>
                                    </svg>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <h5>Порядок участия</h5>
                <div class="form-row">
                    <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['order1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              required
                              placeholder="Порядок оформления участия в торгах, перечень представляемых участниками торгов документов и требования к их оформлению"
                              name="order1"><?php if(isset($auction)): ?> <?php echo e($auction->order1); ?> <?php elseif(old('order1')): ?> <?php echo e(old('order1')); ?> <?php endif; ?></textarea>
                        <?php $__errorArgs = ['order1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['order2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              required
                              placeholder="Cроки и порядок внесения и возврата задатка, реквизиты счетов, на которые вносится задаток"
                              name="order2"><?php if(isset($auction)): ?> <?php echo e($auction->order2); ?> <?php elseif(old('order2')): ?> <?php echo e(old('order2')); ?> <?php endif; ?></textarea>
                        <?php $__errorArgs = ['order2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['order3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              required placeholder="Место, срок и порядок подписания протокола о результатах торгов"
                              name="order3"><?php if(isset($auction)): ?> <?php echo e($auction->order3); ?> <?php elseif(old('order3')): ?> <?php echo e(old('order3')); ?> <?php endif; ?></textarea>
                        <?php $__errorArgs = ['order3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col">
                    <textarea class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['order4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                              required placeholder="Порядок и срок заключения договора купли-продажи"
                              name="order4"><?php if(isset($auction)): ?> <?php echo e($auction->order4); ?> <?php elseif(old('order4')): ?> <?php echo e(old('order4')); ?> <?php endif; ?></textarea>
                        <?php $__errorArgs = ['order3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <?php if(isset($auction)): ?> <input name="auction" value="<?php echo e($auction->id); ?>" hidden>  <?php endif; ?>
                <button type="button" class="ecp_button btn btn-success btn-lg btn-block rounded-0">Добавить файлы и
                    подписать ЭЦП
                </button>
            </form>
        <?php endif; ?>
    </div>

    <?php if(isset($request->type) or isset($auction)): ?>
        <?php echo $__env->make('layouts.ecp-modal', ['file' => 'true', 'title' => 'Подтверждаю свое согласие на размещение аукционана на ЭТП, согласно регламенту ЭТП.', 'submit' => 'Разместить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <script>
            $(document).ready(function () {
                $.datetimepicker.setLocale('ru');
                $('#start_request').datetimepicker({
                    format: 'Y.m.d H:i',
                    onShow: function (ct) {
                        this.setOptions({
                            maxDateTime: $('#end_request').val() ? $('#end_request').val() : false
                        })
                    }
                });
                $('#end_request').datetimepicker({
                    format: 'Y.m.d H:i',
                    onShow: function (ct) {
                        this.setOptions({
                            minDateTime: $('#start_request').val() ? $('#start_request').val() : false,
                            maxDateTime: $('#start_auction').val() ? $('#start_auction').val() : false
                        })
                    }
                });
                $('#start_auction').datetimepicker({
                    format: 'Y.m.d H:i',
                    onShow: function (ct) {
                        this.setOptions({
                            minDateTime: $('#end_request').val() ? $('#end_request').val() : false,
                            maxDateTime: $('#end_auction').val() ? $('#end_auction').val() : false
                        })
                    }
                });
                $('#end_auction').datetimepicker({
                    format: 'Y.m.d',
                    onShow: function (ct) {
                        this.setOptions({
                            minDate: jQuery('#start_auction').val() ? jQuery('#start_auction').val() : false
                        })
                    },
                    timepicker: false
                });
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/creation-auction.blade.php ENDPATH**/ ?>