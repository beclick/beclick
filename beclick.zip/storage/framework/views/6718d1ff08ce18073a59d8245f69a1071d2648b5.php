<?php $__env->startSection('title', __('app.requested_title')); ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                <?php echo e(__('app.requested_title')); ?> <i class="fa fa-angle-left"></i> <a href="<?php echo e(route('home')); ?>"><?php echo e(__('app.requested1')); ?></a>
            </div>
            <h1><?php echo e(__('app.requested_title')); ?></h1>
        </div>
    </div>
    <div class="profile-page">
        <div class="steps">
            <ul>
                <li><a class="s1 <?php if(empty($request->project)): ?> active <?php endif; ?>"><?php echo e(__('app.requested2')); ?></a></li>
                <li><a class="s2 <?php if(isset($request->project)): ?> active <?php endif; ?>"><?php echo e(__('app.requested3')); ?></a></li>
            </ul>
        </div>
        <div class="content c1 other2 <?php if(empty($request->project)): ?> active <?php endif; ?>">
            <div class="flex">
                <div class="list">
                    <div class="flex">
                        <button class="top-button send_btn"><span></span> <?php echo e(__('app.requested4')); ?></button>
                    </div>
                    <form id="project_form">
                        <div class="projects-page find active flex2">
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <div class="main-info">
                                        <input type="checkbox" class="checkbox" id="proj<?php echo e($project->id); ?>"
                                               name="project[]" value="<?php echo e($project->id); ?>"
                                               <?php if($project->id == $request->project): ?> checked <?php endif; ?>><label
                                            for="proj<?php echo e($project->id); ?>"><?php echo e(__('app.requested5')); ?></label>
                                        <div class="flex">
                                            <div class="date">
                                                ID <?php echo e($project->id); ?>

                                                <span><?php echo e(\Illuminate\Support\Carbon::parse($project->created_at)->format('d.m.Y H:i')); ?></span>
                                            </div>
                                            <div class="views">
                                                <?php echo e($project->views); ?>

                                            </div>
                                        </div>
                                        <a href="<?php echo e(route('projects', ['project' => $project->id])); ?>"
                                           class="name"><?php echo e($project->title); ?></a>
                                        <p class="ellipsis"><?php echo e($project->text); ?></p>
                                    </div>
                                    <div class="button flex">
                                        <?php if(isset($project->responses) and $project->responses->count() > 0): ?>
                                            <div class="count">
                                                <?php if($project->responses->where('read', 0)->count() > 0): ?>
                                                    <span>+ <?php echo e($project->responses->where('read', 0)->count()); ?></span>
                                                <?php endif; ?>
                                                <?php echo e($project->responses->count()); ?><a
                                                    href="<?php echo e(route('projects', ['proj' => $project->id])); ?>"><?php echo e(__('app.requested6')); ?></a>
                                            </div>
                                        <?php else: ?>
                                            <div class="count no2">
                                                <?php echo e(__('app.requested7')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </form>
                </div>
                <div class="filter">
                    <div class="block">
                        <div class="no_mob">
                            <div class="name">
                                <?php echo e(__('app.find12')); ?>

                            </div>
                            <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="filter mob">
                    <button class="top-button big send_btn"><span></span> <?php echo e(__('app.requested8')); ?></button>
                    <div class="line"></div>
                    <div class="name">
                        <?php echo e(__('app.find12')); ?>

                    </div>
                    <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        <div class="content c2 other2 <?php if(isset($request->project)): ?> active <?php endif; ?>">
            <div class="flex">
                <div class="list">
                    <div class="flex">
                        <button type="button" class="send-btn top-button big send_btn"><span></span><?php echo e(__('app.find4')); ?>

                        </button>
                        <div class="selected">
                            <?php echo e(__('app.find5')); ?> <span></span>
                            <a id="all_check"><?php echo e(__('app.find6')); ?></a>
                        </div>
                    </div>
                    <div class="search">
                        <div class="flex">
                            <p><?php echo e(__('app.find7')); ?></p>
                        </div>
                        <input type="text" name="mails" placeholder="<?php echo e(__('app.find8')); ?>">
                        <button type="button" id="mails"></button>
                    </div>
                    <form id="send_form">
                        <div id="result" class="flex2 comp">
                            <?php echo $__env->make('layouts.items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </form>
                </div>
                <div class="filter">
                    <div class="name main">
                        <img src="<?php echo e(asset('img/name12.svg')); ?>"> <?php echo e(__('app.find9')); ?>

                    </div>
                    <div class="block">
                        <select id="category" name="category" autocomplete="off">
                            <?php if(!isset($profile->category_id)): ?>
                                <option value="null">-------</option>
                            <?php endif; ?>
                            <?php if(isset($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                            <?php if(isset($request->category) and $request->category == $category->id): ?> selected <?php endif; ?>><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <select id="subcategory" name="subcategory" autocomplete="off">
                            <option value="null">-------</option>
                        </select>
                        <select id="specialization" name="specialization" autocomplete="off">
                            <?php if(!isset($profile->specialization_id)): ?>
                                <option value="null">-------</option>
                            <?php endif; ?>
                            <?php if(isset($specializations)): ?>
                                <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($specialization->id); ?>"
                                            <?php if(isset($request->specialization) and $request->specialization == $specialization->id): ?> selected <?php endif; ?>><?php echo e($specialization->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <div class="result">
                            <p><?php echo e(__('app.find10')); ?> <span id="count"></span></p>
                            <a id="clear"><?php echo e(__('app.find11')); ?></a>
                        </div>
                        <div class="no_mob" style="direction: ltr">
                            <div class="name" style="direction: rtl">
                                <?php echo e(__('app.find12')); ?>

                            </div>
                            <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="filter mob">
                    <button class="top-button big send_btn"><span></span> <?php echo e(__('app.find4')); ?></button>
                    <div class="line"></div>
                    <div class="name">
                        <?php echo e(__('app.find12')); ?>

                    </div>
                    <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {

            $('.list').children('input').change(function () {
                if ($(this).parent().children('input:checked').length > 0) {
                    $(this).parent().siblings('input').prop('checked', true);
                } else {
                    $(this).parent().siblings('input').prop('checked', false);
                }
            });

            <?php if(isset($request->company)): ?>
            $('.comp').find('.checkbox').prop('checked', true);

            <?php endif; ?>

            function get_sub(val) {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?get_sub=" + val,
                }).done(function (data) {
                    $('#subcategory').html(data);
                    $('#subcategory').children('option').prop('selected', false);
                    $('#subcategory').children('option').first().prop('selected', true);
                    get_count();
                });
            }

            <?php if(isset($request->category)): ?>
            get_sub(<?php echo e($request->category); ?>);
            <?php endif; ?>
            $('#category').change(function () {
                get_sub($(this).val());
            });

            var res;

            function get_count(clear) {
                var cat = $('#category').val(),
                    subcat = $('#subcategory').val(),
                    spec = $('#specialization').val(),
                    find13 = '<?php echo e(__('app.find13')); ?>';
                if (clear == 'clear') {
                    cat = 'null';
                    subcat = 'null';
                    spec = 'null';
                }
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?cat=" + cat + "&subcat=" + subcat + "&spec=" + spec,
                }).done(function (data) {
                    $('#count').html(`
                        ${data[0]}<a id="view"> ${find13}</a>
                    `);
                    res = data[1];
                });
            }

            $('#count').on('click', '#view', function () {
                $('#result').empty().append(res);
            });

            $('.filter').find('select').change(function () {
                get_count();
            });

            $('#clear').click(function () {
                $('.filter').find('select').children('option').prop('selected', false);
                get_count('clear');
            });

            $('#mails').click(function () {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?mails=" + $(this).prev('input').val(),
                }).done(function (data) {
                    show_alert(data);
                });
            });

            $('.send_btn').click(function () {
                var data = $('#send_form').serialize() + '&' + $('#project_form').serialize(),
                    new_project21 = '<?php echo e(__('app.new_project21')); ?>';
                $.ajax({
                    url: "<?php echo e(route('requested')); ?>",
                    type: 'POST',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    data: data,
                }).done(function (data) {
                    show_alert(data[1]);
                    $('#send_form').find('.checkbox:checked').siblings('.only_send').addClass('active').html(`<span></span>${new_project21}`);
                });
            });

            $('#result').on('click', '.only_send', function () {
                var data = 'company[]=' + $(this).siblings('.checkbox').val() + '&' + $('#project_form').serialize(),
                    th = $(this),
                    new_project21 = '<?php echo e(__('app.new_project21')); ?>';
                $.ajax({
                    url: "<?php echo e(route('requested')); ?>",
                    type: 'POST',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    data: data,
                }).done(function (data) {
                    show_alert(data[1]);
                    if (data[0] === 1) {
                        th.addClass('active').html(`<span></span>${new_project21}`);
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/requested.blade.php ENDPATH**/ ?>