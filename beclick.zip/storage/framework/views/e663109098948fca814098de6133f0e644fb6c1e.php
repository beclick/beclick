<?php $__env->startSection('title', 'Аккредитация – Арестторг.рф'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <?php if(isset($my_profile)): ?>
            <?php if($my_profile->confirmed == 2): ?>
                <h3>Смена регистрационных данных</h3>
                <hr>
                <h5>
                    <?php if($my_profile->user_role == 0): ?>
                        Организатор торгов:&nbsp;
                    <?php elseif($my_profile->user_role == 1): ?>
                        Участник:&nbsp;
                    <?php endif; ?>
                    <?php if($my_profile->user_type == 0): ?>
                        <?php echo e($my_profile->title); ?>

                    <?php elseif($my_profile->user_type == 1): ?>
                        <?php echo e('ИП ' . $my_profile->full_name); ?>

                    <?php elseif($my_profile->user_type == 2): ?>
                        <?php echo e('ФЛ ' . $my_profile->full_name); ?>

                    <?php endif; ?>
                </h5>
            <?php else: ?>
                <h3>Вы подали заявку на аккредитацию.</h3>
            <?php endif; ?>
                <h5><strong>Заявка на смену регистрационных данных будет рассмотрена в ручном режиме в течении 3 рабочих
                        дней.</strong>
                </h5>
            <br>
        <?php else: ?>
            <h3>Аккредитация пользователя</h3>
            <hr>
            <h5>
                <?php if(isset($request->role)): ?>
                    <?php if($request->role == 0): ?>
                        <strong class="text-danger">Вы регистрируетесь как организатор торгов</strong>, для смены
                        роли после регистрации обратитесь в техподдержку.
                    <?php elseif($request->role == 1): ?>
                        <strong class="text-danger">Вы регистрируетесь как участник</strong>, для смены роли после
                        регистрации обратитесь в техподдержку.
                    <?php endif; ?>
                <?php else: ?>
                    Выберите роль, которую будет представлять Ваша организация, в процессе проведения торгов.
                <?php endif; ?>
                <strong>Заявка на регистрацию будут рассмотрена в ручном режиме в течении 3 рабочих
                    дней.</strong>
            </h5>
            <br>
            <?php if(isset($request->role)): ?>
                <?php if(isset($request->type)): ?>
                    <?php if($request->type == 0): ?>
                        <h4><strong class="text-danger">Юридическое лицо (ЮЛ)</strong></h4>
                    <?php elseif($request->type == 1): ?>
                        <h4><strong class="text-danger">Индивидуальный предприниматель (ИП)</strong></h4>
                    <?php elseif($request->type == 2): ?>
                        <h4><strong class="text-danger">Физическое лицо (ФЛ)</strong></h4>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="<?php echo e(route('accreditation', ['role' => $request->role, 'type' => 0])); ?>"
                       class="btn btn-outline-primary btn-lg btn-block rounded-0">
                        Юридическое лицо (ЮЛ)
                    </a>
                    <br>
                    <a href="<?php echo e(route('accreditation', ['role' => $request->role, 'type' => 1])); ?>"
                       class="btn btn-outline-primary btn-lg btn-block rounded-0">
                        Индивидуальный предприниматель (ИП)
                    </a>
                    <br>
                    <a href="<?php echo e(route('accreditation', ['role' => $request->role, 'type' => 2])); ?>"
                       class="btn btn-outline-primary btn-lg btn-block rounded-0">
                        Физическое лицо (ФЛ)
                    </a>
                <?php endif; ?>
            <?php else: ?>
                <a href="<?php echo e(route('accreditation', ['role' => 0])); ?>"
                   class="btn btn-outline-primary btn-lg btn-block rounded-0">
                    Организатор торгов
                </a>
                <br>
                <a href="<?php echo e(route('accreditation', ['role' => 1])); ?>"
                   class="btn btn-outline-primary btn-lg btn-block rounded-0">
                    Участник торгов
                </a>
            <?php endif; ?>
        <?php endif; ?>

        <?php if((isset($my_profile) and $my_profile->confirmed == 2) or (isset($request->role) and isset($request->type))): ?>

            <form method="POST" action="<?php echo e(route('accreditation')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php if(isset($request->role) and isset($request->type)): ?>
                    <input name="role" value="<?php echo e($request->role); ?>" hidden>
                    <input name="type" value="<?php echo e($request->type); ?>" hidden>
                <?php endif; ?>

                <?php if((isset($my_profile) and $my_profile->user_type == 0) or (isset($request->type) and $request->type == 0)): ?>

                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->title); ?>"
                                   <?php else: ?> value="<?php echo e(old('title')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required name="title" placeholder="Название">
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->full_title); ?>"
                                   <?php else: ?> value="<?php echo e(old('full_title')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['full_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="full_title" placeholder="Полное наименование">
                            <?php $__errorArgs = ['full_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->ur_address); ?>"
                                   <?php else: ?> value="<?php echo e(old('ur_address')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['ur_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="ur_address" placeholder="Юридический адрес">
                            <?php $__errorArgs = ['ur_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->address); ?>"
                                   <?php else: ?> value="<?php echo e(old('address')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="address" placeholder="Фактический адрес">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->inn); ?>"
                                   <?php else: ?> value="<?php echo e(old('inn')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['inn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="inn" placeholder="ИНН">
                            <?php $__errorArgs = ['inn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-4">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->phone); ?>"
                                   <?php else: ?> value="<?php echo e(old('phone')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="phone" placeholder="Контактный телефон">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-4">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->email); ?>"
                                   <?php else: ?> value="<?php echo e(old('email')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="email" placeholder="E-mail организации">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <hr>
                    <h5>Приложите документы, которые указаны в списке</h5>
                    <br>
                    <strong>
                        <ul>
                            <li>Копия выписки из ЕГРЮЛ, выданной не ранее, чем за 30 дней до даты представления
                                заявления на регистрацию
                            </li>
                            <li>Копии учредительных документов</li>
                            <li>Копия документов, удостоверяющих личность руководителя юридического лица</li>
                            <li>Копии документов, подтверждающих полномочия<br>руководителя или полномочия иного лица на
                                осуществление действий от имени такого заявителя
                            </li>
                            <li>Копия свидетельства ИНН</li>
                            <li>Другие документы</li>
                        </ul>
                    </strong>

                <?php elseif((isset($my_profile) and $my_profile->user_type == 1) or (isset($request->type) and $request->type == 1)): ?>

                    <div class="form-row">
                        <div class="form-group col-md-2">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->surname); ?>"
                                   <?php else: ?> value="<?php echo e(old('surname')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="surname" placeholder="Фамилия">
                            <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-2">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->name); ?>"
                                   <?php else: ?> value="<?php echo e(old('name')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="name" placeholder="Имя">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-2">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->patronymic); ?>"
                                   <?php else: ?> value="<?php echo e(old('patronymic')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['patronymic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="patronymic" placeholder="Отчество">
                            <?php $__errorArgs = ['patronymic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->address); ?>"
                                   <?php else: ?> value="<?php echo e(old('address')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="address" placeholder="Адрес">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->inn); ?>"
                                   <?php else: ?> value="<?php echo e(old('inn')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['inn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="inn" placeholder="ИНН">
                            <?php $__errorArgs = ['inn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-3">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->phone); ?>"
                                   <?php else: ?> value="<?php echo e(old('phone')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="phone" placeholder="Контактный телефон">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->pass); ?>"
                                   <?php else: ?> value="<?php echo e(old('pass')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="pass" placeholder="Серия и номер паспорта">
                            <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->issued); ?>"
                                   <?php else: ?> value="<?php echo e(old('issued')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['issued'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="issued" placeholder="Кем выдан паспорт">
                            <?php $__errorArgs = ['issued'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->when); ?>"
                                   <?php else: ?> value="<?php echo e(old('when')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['when'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="when" placeholder="Когда выдан паспорт">
                            <?php $__errorArgs = ['when'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <hr>
                    <h5>Приложите документы, которые указаны в списке</h5>
                    <br>
                    <strong>
                        <ul>
                            <li>Копия выписки из ЕГРИП</li>
                            <li>Копия документа удостоверяющуго личность</li>
                            <li>Копия свидетельства ИНН</li>
                            <li>Другие документы</li>
                        </ul>
                    </strong>

                <?php elseif((isset($my_profile) and $my_profile->user_type == 2) or (isset($request->type) and $request->type == 2)): ?>

                    <div class="form-row">
                        <div class="form-group col-md-2">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->surname); ?>"
                                   <?php else: ?> value="<?php echo e(old('surname')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="surname" placeholder="Фамилия">
                            <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-2">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->name); ?>"
                                   <?php else: ?> value="<?php echo e(old('name')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="name" placeholder="Имя">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-2">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->patronymic); ?>"
                                   <?php else: ?> value="<?php echo e(old('patronymic')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['patronymic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="patronymic" placeholder="Отчество">
                            <?php $__errorArgs = ['patronymic'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->address); ?>"
                                   <?php else: ?> value="<?php echo e(old('address')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="address" placeholder="Адрес">
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-3">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->inn); ?>"
                                   <?php else: ?> value="<?php echo e(old('inn')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['inn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="inn" placeholder="ИНН">
                            <?php $__errorArgs = ['inn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-3">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->phone); ?>"
                                   <?php else: ?> value="<?php echo e(old('phone')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="phone" placeholder="Контактный телефон">
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->pass); ?>"
                                   <?php else: ?> value="<?php echo e(old('pass')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="pass" placeholder="Серия и номер паспорта">
                            <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->issued); ?>"
                                   <?php else: ?> value="<?php echo e(old('issued')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['issued'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="issued" placeholder="Кем выдан паспорт">
                            <?php $__errorArgs = ['issued'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group col-md-6">
                            <input <?php if(isset($my_profile)): ?> value="<?php echo e($my_profile->when); ?>"
                                   <?php else: ?> value="<?php echo e(old('when')); ?>"
                                   <?php endif; ?> class="form-control form-control-lg rounded-0 <?php $__errorArgs = ['when'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                   type="text" required
                                   name="when" placeholder="Когда выдан паспорт">
                            <?php $__errorArgs = ['when'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <hr>
                    <h5>Приложите документы, которые указаны в списке</h5>
                    <br>
                    <strong>
                        <ul>
                            <li>Копия документа удостоверяющуго личность</li>
                            <li>Копия свидетельства ИНН</li>
                            <li>Другие документы</li>
                        </ul>
                    </strong>
                <?php endif; ?>
                <hr>
                <div class="row">
                    <div class="col-md-7">
                        <strong>
                            <div class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input" id="check">
                                <label class="custom-control-label" for="check">Настоящим подтверждаю своё согласие на
                                    обработку персональных данных</label>
                            </div>
                        </strong>
                    </div>
                    <div class="col">
                        <button id="c_btn" type="button" class="ecp_button btn btn-success btn-lg btn-block rounded-0"
                                hidden="true">
                            Добавить и подписать документы
                        </button>
                    </div>
                </div>
            </form>
        <?php endif; ?>
    </div>

    <?php echo $__env->make('layouts.ecp-modal', ['file' => 'true', 'title' => 'Подтверждаю свое согласие на обработку персональных данных, в том числе прикрепленных документов, согласно установленного регламента ЭТП.', 'submit' => 'Отправить'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function () {
            $('#check').change(function () {
                if ($(this).prop('checked')) $('#c_btn').prop('hidden', false);
                else $('#c_btn').prop('hidden', true);
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\aresttorg\resources\views/auth/accreditation.blade.php ENDPATH**/ ?>