<?php $__currentLoopData = $adverts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $advert): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="shop">
        <div class="name">
            <div style="padding-right: 1rem">
                <?php echo e($advert->name); ?>

            </div>
            <a href="<?php echo e(route('company', ['id' => $advert->id])); ?>">
                <div class="avatar"
                    style="width: 4rem; height: 4rem; <?php if(isset($advert->image)): ?> background-image: url(<?php echo e(asset('storage/' . $advert->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                </div>
            </a>
        </div>
        <p class="ellipsis"><?php echo e($advert->description); ?></p>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="shops-link">
    <a href="#"><?php echo e(__('app.recom1')); ?></a>
</div>
<div class="name">
    <?php echo e(__('app.recom2')); ?>

</div>
<div class="material">
    <img src="img/material.png">
    <a href="#"><?php echo e(__('app.recom3')); ?></a>
</div>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/layouts/recomended.blade.php ENDPATH**/ ?>