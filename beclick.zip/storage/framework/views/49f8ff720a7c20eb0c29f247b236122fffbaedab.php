<?php if(isset($companies)): ?>
    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="item">
            <input type="checkbox" class="checkbox" id="item<?php echo e($company->id); ?>" name="company[]"
                   value="<?php echo e($company->id); ?>"><label
                for="item<?php echo e($company->id); ?>"><?php echo e(__('app.items1')); ?></label>
            <div class="name">
                <a href="<?php echo e(route('company', ['id' => $company->id])); ?>">
                    <div class="avatar"
                        style="width: 3rem; height: 3rem; <?php if(isset($company->image)): ?> background-image: url(<?php echo e(asset('storage/' . $company->image)); ?>); <?php endif; ?> background-size: contain; background-repeat: no-repeat; background-position: center;">
                    </div>
                </a>
                <div style="padding-right: 1rem">
                    <?php echo e($company->name); ?>

                    <br/>
                    <a href="<?php echo e(route('company', ['id' => $company->id])); ?>"><?php echo e(__('app.items2')); ?></a>
                </div>
            </div>
            <p class="ellipsis"><?php echo e($company->description); ?></p>
            <div class="counts">
                <?php if($company->resp_time / $company->resp_num < 60): ?>
                    <span>~<?php echo e(round($company->resp_time / $company->resp_num)); ?> <?php echo e(__('app.items3')); ?></span>
                <?php elseif($company->resp_time / $company->resp_num < 1440): ?>
                    <span>~<?php echo e(round($company->resp_time / $company->resp_num / 60)); ?> <?php echo e(__('app.items4')); ?></span>
                <?php elseif($company->resp_time / $company->resp_num < 10080): ?>
                    <span>~<?php echo e(round($company->resp_time / $company->resp_num / 1440)); ?> <?php echo e(__('app.items5')); ?></span>
                <?php endif; ?>
                <span><?php echo e($company->num_proj); ?></span>
            </div>
            <div class="links">
                <?php if(isset($company->contact_phone)): ?>
                    <a href="tel:<?php echo e($company->contact_phone); ?>"> <?php echo e($company->contact_phone); ?> <?php if(isset($company->contact_phone_d)): ?>
                            <?php echo e(__('app.items6')); ?> <?php echo e($company->contact_phone_d); ?> <?php endif; ?></a>
                <?php else: ?>
                    <a> ------------- </a>
                <?php endif; ?>
                <?php if(isset($company->email)): ?>
                    <a href="mailto:<?php echo e($company->email); ?>"><?php echo e($company->email); ?></a>
                <?php else: ?>
                    <a> ------------- </a>
                <?php endif; ?>
            </div>
            <button class="only_send" type="button"><span></span> <?php echo e(__('app.items7')); ?></button>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/layouts/items.blade.php ENDPATH**/ ?>