<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="js/common.js"></script>
</head>
<body class="lp">
<div class="login-page">
    <div class="content">
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="logo">
                <img src="img/logo.svg">
            </div>
            <div class="top-text">
                Создайте аккаунт, это займет меньше минуты
            </div>
            <div class="field-name">
                Имя пользователя
            </div>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="Введите ваш никнейм"
                   autofocus>
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="field-name">
                E-mail
            </div>
            <input type="text" placeholder="Введите ваш e-mail" name="email"
                   value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="field-name">
                Пароль
            </div>
            <div class="pass">
                <a class="show-pass"></a>
                <input type="password" placeholder="Введите ваш пароль" name="password" required
                       autocomplete="current-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="agree">
                <input type="checkbox" class="checkbox" id="agree"><label for="agree">Я соглашаюсь с <a href="#">Правилами
                        сервиса и Политикой конфиденциальности</a></label>
            </div>
            <button type="submit">Зарегистрироваться</button>
            <div class="or">
                или
            </div>
            <a href="#" class="google-login">
                <img src="img/google.png"> Войти через Google
            </a>
        </form>
    </div>
    <div class="bottom-block">
        Уже зарегистрированы? <a href="#">Войти</a>
    </div>
    <div class="copy">
        <p>beclick.co.il. All rights reserved © 2021</p>
        <a href="#">Политика конфиденциальности</a>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\OpenServer\domains\beclick\resources\views/auth/register.blade.php ENDPATH**/ ?>