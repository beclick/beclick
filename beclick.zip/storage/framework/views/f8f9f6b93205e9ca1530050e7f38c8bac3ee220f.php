<?php if(isset($project)): ?>
    <?php $__env->startSection('title', __('app.new_project1')); ?>
<?php else: ?>
    <?php $__env->startSection('title', __('app.new_project_title')); ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
    <div class="flex">
        <div class="page-name">
            <div class="navi">
                <?php if(isset($project)): ?> <?php echo e(__('app.new_project1')); ?> <?php else: ?> <?php echo e(__('app.new_project_title')); ?> <?php endif; ?> <i
                    class="fa fa-angle-left"></i> <a
                    href=""><?php echo e(__('app.new_project2')); ?></a>
            </div>
            <h1> <?php if(isset($project)): ?> <?php echo e(__('app.new_project1')); ?> <?php else: ?> <?php echo e(__('app.new_project_title')); ?> <?php endif; ?></h1>
        </div>
    </div>
    <div class="profile-page">
        <div class="steps">
            <ul>
                <li>
                    <a class="s1 active"><?php echo e(__('app.new_project3')); ?> <?php if(isset($project)): ?> <?php echo e(__('app.new_project1')); ?> <?php else: ?> <?php echo e(__('app.new_project_title')); ?> <?php endif; ?></a>
                </li>
                <li>
                    <a class="s2"><?php echo e(__('app.new_project4')); ?></a>
                </li>
                <li>
                    <a class="s3"><?php echo e(__('app.new_project5')); ?></a>
                </li>
            </ul>
        </div>
        <form id="proj_form">
            <input class="project" name="project[]" value="<?php if(isset($project)): ?> <?php echo e($project->id); ?> <?php endif; ?>" hidden>
            <div class="content c1 other active">
                <div class="flex">
                    <div class="fields big">
                        <div class="fields-name">
                            <img src="img/name10.svg"> <?php echo e(__('app.new_project6')); ?>

                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.new_project7')); ?>

                        </div>
                        <div class="field">
                            <input class="inp" id="title" name="title" type="text"
                                   value="<?php if(isset($project)): ?> <?php echo e($project->title); ?> <?php endif; ?>" autocomplete="off">
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.new_project8')); ?>

                        </div>
                        <div class="field">
                            <select class="inp" id="type" name="type" autocomplete="off">
                                <?php if(!isset($project->type_id)): ?>
                                    <option value="">-------</option>
                                <?php endif; ?>
                                <?php if(isset($types)): ?>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type->id); ?>"
                                                <?php if(isset($project->type_id) and $project->type_id == $type->id): ?> selected <?php endif; ?>><?php echo e($type->title); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.new_project9')); ?>

                        </div>
                        <div class="field">
                            <textarea class="inp" id="text" name="text"
                                      autocomplete="off"><?php if(isset($project)): ?> <?php echo e($project->text); ?> <?php endif; ?></textarea>
                        </div>
                        <div class="line"></div>
                        <div class="fields-name">
                            <img src="img/name3.svg"> <?php echo e(__('app.new_project10')); ?>

                        </div>
                        <div class="field-name">
                            <?php echo e(__('app.new_project11')); ?>

                        </div>
                        <div class="regions">
                            <div class="item">
                                <input name="regions[]" type="checkbox" class="checkbox reg" value="<?php echo e(__('app.all_israile')); ?>"
                                       id="chf"
                                       <?php if(isset($project->regions) and isset(explode('|', $project->regions)[1]) and explode('|', $project->regions)[1] == __('app.all_israile')): ?> checked
                                       <?php endif; ?> autocomplete="off">
                                <label for="chf"><?php echo e(__('app.all_israile')); ?></label>
                            </div>
                            <?php $__currentLoopData = $regions[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <a class="link"><i class="fa fa-angle-left"></i></a>
                                    <input type="checkbox" class="checkbox" id="ch<?php echo e($region->id); ?>" autocomplete="off">
                                    <label for="ch<?php echo e($region->id); ?>"><?php echo e($region->title); ?></label>
                                    <div class="list">
                                        <?php if(isset($regions[$region->id])): ?>
                                            <?php $__currentLoopData = $regions[$region->id]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <input name="regions[]" type="checkbox" class="checkbox"
                                                       id="ch<?php echo e($reg->id); ?>" value="<?php echo e($reg->title); ?>"
                                                       <?php if(isset($project->regions) and in_array($reg->title, explode('|', $project->regions))): ?> checked
                                                       <?php endif; ?> autocomplete="off">
                                                <label for="ch<?php echo e($reg->id); ?>"><?php echo e($reg->title); ?></label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="line"></div>
                        <div class="fields-name">
                            <img src="<?php echo e(asset('img/name11.svg')); ?>"> <?php echo e(__('app.new_project12')); ?>

                        </div>
                        <div class="attach">
                            <?php echo __('app.new_project13'); ?>

                            <input id="docs_url" name="docs_url" type="text"
                                   value="<?php if(isset($project)): ?> <?php echo e($project->docs_url); ?> <?php endif; ?>" autocomplete="off">
                        </div>
                        <div class="line"></div>
                        <div class="button flex">
                            <button type="button" id="next" class="big"><?php echo e(__('app.new_project14')); ?> <span></span>
                            </button>
                            <input name="contact_hide" type="checkbox" class="checkbox" id="ccc" value="check"
                                   <?php if(isset($project->contact_hide) and $project->contact_hide == 1): ?> checked <?php endif; ?>>
                            <label for="ccc">
                                <?php echo __('app.new_project15'); ?>

                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="content c2 other">
                <div class="flex">
                    <div class="fields big">
                        <div id="quest">
                            <?php if(isset($project->questions)): ?>
                                <div class="fields-name">
                                    <img src="<?php echo e(asset('img/name10.svg')); ?>"> <?php echo e(__('app.new_project16')); ?>

                                </div>
                                <div class="field-name">
                                    <?php echo $project->questions; ?>

                                </div>
                                <div class="button flex">
                                    <button type="button" id="new_quest"><?php echo e(__('app.new_project17')); ?>

                                    </button>
                                </div>
                            <?php else: ?>
                                <div class="fields-name">
                                    <?php echo e(__('app.new_project18')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="line"></div>
                        <div class="button flex">
                            <button type="button" id="save" class="big"><?php echo e(__('app.new_project19')); ?> <span></span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </form>
        <div class="content c3 other2">
            <div class="flex">
                <div class="list">
                    <div class="flex">
                        <button type="button" class="send-btn top-button big send_btn"><span></span> <?php echo e(__('app.find4')); ?>

                        </button>
                        <div class="selected">
                            <?php echo e(__('app.find5')); ?> <span></span>
                            <a id="all_check"><?php echo e(__('app.find6')); ?></a>
                        </div>
                    </div>
                    <div class="search">
                        <div class="flex">
                            <p><?php echo e(__('app.find7')); ?></p>
                        </div>
                        <input type="text" name="mails" placeholder="<?php echo e(__('app.find8')); ?>">
                        <button type="button" id="mails"></button>
                    </div>
                    <form id="send_form">
                        <input class="project" name="project[]" value="<?php if(isset($project)): ?><?php echo e($project->id); ?><?php endif; ?>"
                               hidden>
                        <div id="result" class="flex2 comp">
                            <?php echo $__env->make('layouts.items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </form>
                </div>
                <div class="filter">
                    <div class="name main">
                        <img src="<?php echo e(asset('img/name12.svg')); ?>"> <?php echo e(__('app.find9')); ?>

                    </div>
                    <div class="block">
                        <select id="category" name="category" autocomplete="off">
                            <?php if(!isset($profile->category_id)): ?>
                                <option value="null">-------</option>
                            <?php endif; ?>
                            <?php if(isset($categories)): ?>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->id); ?>"
                                            <?php if(isset($request->category) and $request->category == $category->id): ?> selected <?php endif; ?>><?php echo e($category->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <select id="subcategory" name="subcategory" autocomplete="off">
                            <option value="null">-------</option>
                        </select>
                        <select id="specialization" name="specialization" autocomplete="off">
                            <?php if(!isset($profile->specialization_id)): ?>
                                <option value="null">-------</option>
                            <?php endif; ?>
                            <?php if(isset($specializations)): ?>
                                <?php $__currentLoopData = $specializations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($specialization->id); ?>"
                                            <?php if(isset($request->specialization) and $request->specialization == $specialization->id): ?> selected <?php endif; ?>><?php echo e($specialization->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>
                        <div class="result">
                            <p><?php echo e(__('app.find10')); ?> <span id="count"></span></p>
                            <a id="clear"><?php echo e(__('app.find11')); ?></a>
                        </div>
                        <div class="no_mob" style="direction: ltr">
                            <div class="name" style="direction: rtl">
                                <?php echo e(__('app.find12')); ?>

                            </div>
                            <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </div>
                <div class="filter mob">
                    <button class="top-button big send_btn"><span></span> <?php echo e(__('app.find4')); ?></button>
                    <div class="line"></div>
                    <div class="name">
                        <?php echo e(__('app.find12')); ?>

                    </div>
                    <?php echo $__env->make('layouts.recomended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function () {
            $('.list').each(function () {
                if ($(this).children('input:checked').length > 0) {
                    $(this).siblings('input').prop('checked', true);
                } else {
                    $(this).siblings('input').prop('checked', false);
                }
            });

            $('.list').children('input').change(function () {
                if ($(this).parent().children('input:checked').length > 0) {
                    $(this).parent().siblings('input').prop('checked', true);
                    $('#chf').prop('checked', false);
                } else {
                    $(this).parent().siblings('input').prop('checked', false);
                }
            });

            $('.list').prev().prev('input').change(function () {
                if ($(this).is(':checked')) {
                    $(this).next().next('.list').children('input').prop('checked', true);
                    $('#chf').prop('checked', false);
                } else {
                    $(this).next().next('.list').children('input').prop('checked', false);
                }
            });

            $('#chf').change(function () {
                if ($(this).is(':checked')) {
                    $(this).parent().parent().find('input').not(this).prop('checked', false);
                }
            });

            $('#next').click(function () {
                $('.profile-page .steps ul li a.s2').click();
                $(document).scrollTop(0);
            });

            $('#save').click(function () {
                var new_project19 = '<?php echo e(__('app.new_project19')); ?>',
                    new_project20 = '<?php echo e(__('app.new_project20')); ?>';
                $.ajax({
                    url: "<?php echo e(route('new_project')); ?>",
                    type: 'POST',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    data: $('#proj_form').serialize(),
                }).done(function (data) {
                    show_alert(data[1]);
                    if (data[0] === 1) {
                        $('.project').val(data[2]);
                        $('.profile-page .steps ul li a.s2').removeClass('active');
                        $('.profile-page .steps ul li a.s3').addClass('active');
                        $('.profile-page .content.c2').removeClass('active');
                        $('.profile-page .content.c3').addClass('active');
                        $(document).scrollTop(0);
                        $('#quest').empty().append(`<div class="fields-name">
                            <img src="img/name10.svg"> ${new_project19}
                        </div>
                        <div class="field-name">
                            ${data[3]}
                        </div>
                        <div class="button flex">
                        <button type="button" id="new_quest"> ${new_project20}
                    </button>
                    </div>`);
                    } else {
                        $('.profile-page .steps ul li a.s2').removeClass('active');
                        $('.profile-page .steps ul li a.s1').addClass('active');
                        $('.profile-page .content.c2').removeClass('active');
                        $('.profile-page .content.c1').addClass('active');
                        $('.inp').each(function (index) {
                            if ($(this).val() > '') {
                                $(this).parent('div').removeClass('bad').addClass('ok');
                            } else {
                                $(this).parent('div').removeClass('ok').addClass('bad');
                            }
                        });

                        $(document).scrollTop(0);
                    }
                });
            });

            $('#mails').click(function () {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?mails=" + $(this).prev('input').val(),
                }).done(function (data) {
                    show_alert(data);
                });
            });

            function get_sub(val) {
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?get_sub=" + val,
                }).done(function (data) {
                    $('#subcategory').html(data);
                    $('#subcategory').children('option').prop('selected', false);
                    $('#subcategory').children('option').first().prop('selected', true);
                    get_count();
                });
            }

            <?php if(isset($request->category)): ?>
            get_sub(<?php echo e($request->category); ?>);
            <?php endif; ?>
            $('#category').change(function () {
                get_sub($(this).val());
            });

            var res;

            function get_count(clear) {
                var cat = $('#category').val(),
                    subcat = $('#subcategory').val(),
                    spec = $('#specialization').val(),
                    find13 = '<?php echo e(__('app.find13')); ?>';
                if (clear == 'clear') {
                    cat = 'null';
                    subcat = 'null';
                    spec = 'null';
                }
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?cat=" + cat + "&subcat=" + subcat + "&spec=" + spec,
                }).done(function (data) {
                    $('#count').html(`
                        ${data[0]}<a id="view"> ${find13}</a>
                    `);
                    res = data[1];
                });
            }

            function get_quest(type) {
                var new_project18 = '<?php echo e(__('app.new_project19')); ?>';
                $.ajax({
                    url: "<?php echo e(route('resource')); ?>?type=" + type,
                }).done(function (data) {
                    if (data[0] > 0) {
                        $('#quest').empty().append(data[1]);
                    } else {
                        $('#quest').empty().append(`<div class="fields-name">
                                                        ${new_project18}
                                                    </div>`);
                    }
                });
            }

            $('#type').change(function () {
                get_quest($(this).val());
            });
            $('#quest').on('click', '#new_quest', function () {
                get_quest($('#type').val());
            });
            <?php if(empty($project->questions)): ?>
            get_quest($('#type').val());
            <?php endif; ?>

            $('#count').on('click', '#view', function () {
                $('#result').empty().append(res);
            });

            $('.filter').find('select').change(function () {
                get_count();
            });

            $('#clear').click(function () {
                $('.filter').find('select').children('option').prop('selected', false);
                get_count('clear');
            });

            $('.inp').on('input', function () {
                if ($(this).val() > '') {
                    $(this).parent('div').removeClass('bad').addClass('ok');
                } else {
                    $(this).parent('div').removeClass('ok').addClass('bad');
                }
            });

            $('.send_btn').click(function () {
                var new_project21 = '<?php echo e(__('app.new_project21')); ?>';
                $.ajax({
                    url: "<?php echo e(route('requested')); ?>",
                    type: 'POST',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    data: $('#send_form').serialize(),
                }).done(function (data) {
                    show_alert(data[1]);
                    $('#send_form').find('.checkbox:checked').siblings('.only_send').addClass('active').html(`<span></span>${new_project21}`);
                });
            });

            $('#result').on('click', '.only_send', function () {
                var data = 'company[]=' + $(this).siblings('.checkbox').val() + '&project[]=' + $('.project').val(),
                    th = $(this),
                    new_project21 = '<?php echo e(__('app.new_project21')); ?>';
                $.ajax({
                    url: "<?php echo e(route('requested')); ?>",
                    type: 'POST',
                    headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
                    data: data,
                }).done(function (data) {
                    show_alert(data[1]);
                    if (data[0] === 1) {
                        th.addClass('active').html(`<span></span>${new_project21}`);
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/new_project.blade.php ENDPATH**/ ?>