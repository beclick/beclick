<!DOCTYPE html>
<html dir="rtl">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no">
    <link href="<?php echo e(asset('style.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo e(asset('js/common.js')); ?>"></script>
</head>
<body class="lp">
<div class="login-page">
    <div class="content">
        <form method="POST" action="<?php echo e(route('password.update')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">
            <div class="logo">
                <img src="<?php echo e(asset('img/logo.svg')); ?>">
            </div>
            <div class="top-text">
                <?php echo e(__('passwords.new_password')); ?>

            </div>
            <div class="field-name">
                <?php echo e(__('app.email')); ?>

            </div>
            <input type="text" placeholder="<?php echo e(__('auth.enter_email')); ?>" name="email"
                   value="<?php echo e($email ?? old('email')); ?>" required autocomplete="email" autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <strong><?php echo e($message); ?></strong>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="field-name">
                <?php echo e(__('auth.password')); ?>

            </div>
            <div class="pass">
                <a class="show-pass"></a>
                <input type="password" placeholder="<?php echo e(__('auth.enter_password')); ?>" name="password" required
                       autocomplete="new-password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <strong><?php echo e($message); ?></strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="pass">
                <a class="show-pass"></a>
                <input type="password" placeholder="<?php echo e(__('auth.confirm_password')); ?>" name="password_confirmation" required autocomplete="new-password">
            </div>
            <button type="submit"><?php echo e(__('passwords.set_new_password')); ?></button>
        </form>
    </div>
    <div class="bottom-block">
    </div>
    <div class="copy">
        <p><?php echo e(__('app.all_rights_reserved')); ?></p>
        <a href="#"><?php echo e(__('app.privacy_policy')); ?></a>
    </div>
</div>
</body>
</html>
<?php /**PATH /home/h910232860/beclick.irris.ru/docs/resources/views/auth/passwords/reset.blade.php ENDPATH**/ ?>